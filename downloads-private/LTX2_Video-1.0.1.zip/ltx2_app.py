"""
LTX-2 Video Generation Studio — Native Desktop Application.

Full-featured native GUI with ALL pipelines from the original Gradio app:
  Tab 1: Fast Generation   (Distilled, 8-step)
  Tab 2: Production Quality (Two-Stage, CFG/STG guidance)
  Tab 3: IC-LoRA           (Video-to-Video structural control)
  Tab 4: Keyframe          (Two-image interpolation)
  Tab 5: Gallery           (Browse outputs)
  Tab 6: Status            (GPU info, model downloads, logs)

Communicates with the runner backend (port 38000) via HTTP.

Usage:  python ltx2_app.py [--runner-url http://127.0.0.1:38000]
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import json
import logging
import random
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

import machine_lock
from launch_app import check_models_present, download_models, DOWNLOAD_STATUS_FILE

# ---------------------------------------------------------------------------
# Paths & constants
# ---------------------------------------------------------------------------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
RUNNER_SCRIPT = os.path.join(SCRIPT_DIR, "runner.py")
OUTPUT_DIR = os.path.join(SCRIPT_DIR, "outputs")
LOG_DIR = os.path.join(SCRIPT_DIR, "logs")

RUNNER_BASE = os.environ.get("LTX_RUNNER_URL", "http://127.0.0.1:38000")
POLL_MS = 1200
TASK_REFRESH_MS = 4000
LOG_REFRESH_MS = 5000

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
os.makedirs(LOG_DIR, exist_ok=True)
_fl = logging.getLogger("ltx2_app")
_fl.setLevel(logging.DEBUG)
_fh = logging.FileHandler(os.path.join(LOG_DIR, "ltx2_app.log"), encoding="utf-8")
_fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S"))
_fl.addHandler(_fh)


def flog(msg, level="INFO"):
    getattr(_fl, level.lower(), _fl.info)(msg)


# ---------------------------------------------------------------------------
# Runner HTTP
# ---------------------------------------------------------------------------
def call_runner(method, path, json_data=None, timeout=300):
    url = RUNNER_BASE.rstrip("/") + path
    body = json.dumps(json_data).encode("utf-8") if json_data else None
    req = Request(url, data=body, headers={"Content-Type": "application/json"}, method=method)
    try:
        with urlopen(req, timeout=timeout) as r:
            return r.getcode(), json.loads(r.read().decode("utf-8"))
    except HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode("utf-8"))
        except Exception:
            return e.code, {"error": str(e)}
    except Exception as e:
        return 0, {"error": str(e)}


def runner_healthy():
    try:
        code, _ = call_runner("GET", "/healthz", timeout=5)
        return code == 200
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Content data (from Gradio app.py)
# ---------------------------------------------------------------------------
ASPECT_PRESETS = {
    "Custom": None,
    "16:9 Cinematic (1536x896)": (1536, 896),
    "16:9 HD (1280x704)": (1280, 704),
    "9:16 Portrait (896x1536)": (896, 1536),
    "9:16 Mobile (704x1280)": (704, 1280),
    "1:1 Square (1024x1024)": (1024, 1024),
    "4:3 Classic (1024x768)": (1024, 768),
    "3:2 Photo (1536x1024)": (1536, 1024),
    "21:9 Ultrawide (1536x640)": (1536, 640),
}

PROMPT_TEMPLATES = {
    "(Select a template)": "",
    "--- Nature ---": "",
    "Golden Hour Mountains": "A cinematic shot of a vast mountain landscape at golden hour, the camera slowly panning across snow-capped peaks, warm light casting long shadows across alpine meadows, wisps of clouds drifting between the summits, 4K, photorealistic.",
    "Ocean Waves": "Aerial drone shot of turquoise ocean waves crashing on a pristine white sand beach, crystal clear water, golden sunlight reflecting off the surface, seabirds gliding overhead, serene atmosphere.",
    "Forest Rain": "A serene forest scene during gentle rain, raindrops falling on emerald leaves, misty atmosphere, soft diffused lighting filtering through the canopy, peaceful ambient mood, slow camera dolly forward.",
    "--- People ---": "",
    "Portrait Closeup": "A cinematic close-up portrait of a person looking directly at the camera, soft studio lighting, shallow depth of field, neutral background with subtle bokeh, natural skin tones, photorealistic detail.",
    "Street Scene": "A person walking through a neon-lit city street at night, rain-slicked pavement reflecting colorful signs, cinematic shallow depth of field, moody atmosphere.",
    "--- Animals ---": "",
    "Dog on Beach": "A golden retriever playing fetch on a sunny beach, waves crashing in the background, bright blue sky with fluffy white clouds, the dog runs joyfully across the sand, its fur gleaming in the sunlight.",
    "--- Sci-Fi ---": "",
    "Space Station": "A massive space station orbiting Earth, sunlight glinting off solar panels, stars twinkling in the background, Earth's curvature visible below with city lights, cinematic wide shot.",
    "Fantasy Castle": "An enchanted castle on a floating island above the clouds, waterfalls cascading into the mist below, golden sunset light, dragons circling distant peaks, epic fantasy atmosphere.",
    "--- Abstract ---": "",
    "Ink in Water": "Macro shot of vibrant colored inks swirling and mixing in crystal clear water, deep blues merging with rich golds, abstract fluid dynamics, mesmerizing patterns, studio lighting, slow motion.",
}

DEFAULT_NEG = (
    "blurry, out of focus, overexposed, underexposed, low contrast, washed out colors, excessive noise, "
    "grainy texture, poor lighting, flickering, motion blur, distorted proportions, unnatural skin tones, "
    "deformed facial features, extra limbs, disfigured hands, artifacts, inconsistent perspective"
)

CAMERA_LORAS = ["None", "Dolly In", "Dolly Out", "Dolly Left", "Dolly Right", "Jib Up", "Jib Down", "Static"]
IC_LORA_TYPES = ["Canny Control", "Depth Control", "Detailer", "Pose Control"]
FRAME_PRESETS = [9, 17, 25, 33, 41, 49, 57, 65, 81, 97, 121]

# ---------------------------------------------------------------------------
# Color palette (dark theme)
# ---------------------------------------------------------------------------
C = {
    "bg": "#0f0f1a", "bg2": "#1a1b2e", "bg3": "#12121e",
    "fg": "#a9b1d6", "fg_bright": "#c0caf5",
    "accent": "#7aa2f7", "accent_hover": "#89b4fa",
    "green": "#9ece6a", "red": "#f7768e", "orange": "#e0af68",
    "purple": "#bb9af7", "muted": "#565f89", "border": "#3b4261",
}


# ---------------------------------------------------------------------------
# Application
# ---------------------------------------------------------------------------
class LTX2App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("LTX-2 Video Generation Studio")
        self.geometry("1080x960")
        self.minsize(820, 700)
        self.configure(bg=C["bg"])

        self._runner_proc = None
        self._runner_stderr_fh = None
        self._runner_stderr_path = None
        self._active_task_id = None
        self._poll_gen = 0
        self._shutting_down = False

        os.makedirs(OUTPUT_DIR, exist_ok=True)

        if not self._check_activation():
            self.destroy()
            return

        if not self._check_and_download_models():
            self.destroy()
            return

        self._build_styles()
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        flog("App started")
        self.after(300, self._init_runner)

    # ── License activation ────────────────────────────────────────────
    def _check_activation(self) -> bool:
        check = machine_lock.activate_or_verify()
        if check["ok"]:
            return True
        if check.get("needs_activation"):
            return self._show_activation_dialog()
        messagebox.showerror("License Error",
                             check.get("error", "Unknown license error."))
        return False

    def _show_activation_dialog(self) -> bool:
        win = tk.Toplevel(self)
        win.title("Activate LTX-2 Video Studio")
        win.minsize(460, 230)
        win.resizable(True, True)
        try:
            win.configure(bg=C["bg"])
        except Exception:
            pass

        style = ttk.Style()
        try:
            style.configure("Act.TLabel", background=C["bg"],
                            foreground=C["fg_bright"], font=("Segoe UI", 10))
            style.configure("Act.TButton", font=("Segoe UI", 10))
        except Exception:
            pass

        activated = [False]

        ttk.Label(win, text="Enter your license key to activate:",
                  style="Act.TLabel", padding=(10, 15, 10, 5)).pack(fill=tk.X)

        key_var = tk.StringVar()
        entry = ttk.Entry(win, textvariable=key_var, font=("Consolas", 13),
                          justify="center")
        entry.pack(padx=20, pady=5, fill=tk.X)
        entry.focus_set()

        status_lbl = ttk.Label(win, text="", style="Act.TLabel", padding=5,
                               wraplength=400)
        status_lbl.pack(fill=tk.X)

        btn_frame = ttk.Frame(win)
        btn_frame.pack(pady=10)
        btn_activate = ttk.Button(btn_frame, text="Activate",
                                  style="Act.TButton")
        btn_activate.pack(side=tk.LEFT, padx=5)

        def do_skip():
            activated[0] = True
            win.destroy()

        btn_skip = ttk.Button(btn_frame, text="Skip (Trial Mode)",
                              style="Act.TButton", command=do_skip)
        btn_skip.pack(side=tk.LEFT, padx=5)
        btn_quit = ttk.Button(btn_frame, text="Quit", style="Act.TButton",
                              command=lambda: win.destroy())
        btn_quit.pack(side=tk.LEFT, padx=5)

        def do_activate():
            key = key_var.get().strip()
            if not key:
                status_lbl.config(text="Please enter a license key.")
                return
            btn_activate.state(["disabled"])
            status_lbl.config(text="Contacting activation server...")
            win.update()

            result = machine_lock.activate_online(key)

            if result["ok"]:
                activated[0] = True
                status_lbl.config(text="Activated successfully!")
                win.update()
                time.sleep(1)
                win.destroy()
                return

            if result.get("error") == "activation_limit_reached":
                answer = messagebox.askyesno(
                    "Activation Limit",
                    f"{result['message']}\n\nDeactivate all other machines "
                    "and bind this license to this computer?",
                    parent=win,
                )
                if answer:
                    status_lbl.config(text="Force takeover in progress...")
                    win.update()
                    r2 = machine_lock.activate_online(key, force_takeover=True)
                    if r2["ok"]:
                        activated[0] = True
                        status_lbl.config(
                            text="Activated (previous machines deactivated).")
                        win.update()
                        time.sleep(1)
                        win.destroy()
                        return
                    status_lbl.config(
                        text=r2.get("message", "Force takeover failed."))
                else:
                    status_lbl.config(text="Activation cancelled.")
            else:
                status_lbl.config(
                    text=result.get("message", "Activation failed."))

            btn_activate.state(["!disabled"])

        btn_activate.config(command=do_activate)
        entry.bind("<Return>", lambda _e: do_activate())

        win.protocol("WM_DELETE_WINDOW", win.destroy)
        win.transient(self)
        win.grab_set()
        self.wait_window(win)

        return activated[0]

    # ── Model download check ──────────────────────────────────────────
    def _check_and_download_models(self) -> bool:
        missing = check_models_present()
        if not missing:
            flog("All models present.")
            return True

        flog(f"{len(missing)} model file(s) missing — starting download.")
        return self._show_download_dialog(missing)

    def _show_download_dialog(self, missing: list) -> bool:
        win = tk.Toplevel(self)
        win.title("LTX-2 — Downloading Models")
        win.minsize(540, 200)
        win.resizable(True, True)
        try:
            win.configure(bg=C["bg"])
        except Exception:
            pass

        style = ttk.Style()
        try:
            style.configure("Dl.TLabel", background=C["bg"],
                            foreground=C["fg_bright"], font=("Segoe UI", 10))
            style.configure("Dl.TButton", font=("Segoe UI", 10))
        except Exception:
            pass

        finished = [False]
        success = [False]
        cancelled = [False]

        n = len(missing)
        ttk.Label(win, text=f"First-run setup: downloading {n} model file(s)",
                  style="Dl.TLabel", padding=(12, 12, 12, 2)).pack(fill=tk.X)

        detail_lbl = ttk.Label(win, text="This is a one-time download (~80 GB). "
                               "Please be patient.",
                               style="Dl.TLabel", padding=(12, 2, 12, 5),
                               wraplength=500)
        detail_lbl.pack(fill=tk.X)

        pbar = ttk.Progressbar(win, mode="determinate", maximum=100,
                               style="Horizontal.TProgressbar")
        pbar.pack(fill=tk.X, padx=18, pady=6)

        status_lbl = ttk.Label(win, text="Starting...", style="Dl.TLabel",
                               padding=(12, 2, 12, 2), wraplength=500)
        status_lbl.pack(fill=tk.X)

        btn_frame = ttk.Frame(win)
        btn_frame.pack(pady=8)
        btn_cancel = ttk.Button(btn_frame, text="Cancel", style="Dl.TButton",
                                command=lambda: _do_cancel())
        btn_cancel.pack(side=tk.LEFT, padx=5)

        def _do_cancel():
            cancelled[0] = True
            btn_cancel.state(["disabled"])
            status_lbl.config(text="Cancelling after current file...")

        def _update_ui(msg):
            if cancelled[0]:
                return
            try:
                status_lbl.config(text=msg)
            except Exception:
                pass

        def _poll_status():
            if finished[0]:
                return
            try:
                raw = DOWNLOAD_STATUS_FILE.read_text(encoding="utf-8")
                blob = json.loads(raw)
                pct = blob.get("progress", 0) * 100
                pbar["value"] = pct
                msg = blob.get("message", "")
                if msg:
                    status_lbl.config(text=msg)
            except Exception:
                pass
            if not finished[0]:
                win.after(800, _poll_status)

        def _run_download():
            ok = download_models(callback=lambda m: win.after(0, _update_ui, m))
            finished[0] = True
            success[0] = ok
            if ok:
                win.after(0, lambda: status_lbl.config(
                    text="All models downloaded successfully!"))
                win.after(0, lambda: pbar.configure(value=100))
            elif cancelled[0]:
                win.after(0, lambda: status_lbl.config(
                    text="Download cancelled. Some models may be missing."))
            else:
                win.after(0, lambda: status_lbl.config(
                    text="Some downloads failed. Check your internet."))
            win.after(1500, lambda: win.destroy())

        win.after(200, _poll_status)
        threading.Thread(target=_run_download, daemon=True).start()

        win.protocol("WM_DELETE_WINDOW", lambda: None)
        win.transient(self)
        win.grab_set()
        self.wait_window(win)

        if cancelled[0]:
            remaining = check_models_present()
            if remaining:
                return messagebox.askyesno(
                    "Missing Models",
                    f"{len(remaining)} model file(s) still missing.\n\n"
                    "Continue anyway? Some pipelines may not work.",
                    parent=self)
            return True
        return success[0] or messagebox.askyesno(
            "Download Incomplete",
            "Some model downloads failed.\n\n"
            "Continue anyway? Some pipelines may not work.",
            parent=self)

    # ── Styles ────────────────────────────────────────────────────────
    def _build_styles(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure(".", background=C["bg"], foreground=C["fg"], fieldbackground=C["bg2"], borderwidth=0)
        s.configure("TFrame", background=C["bg"])
        s.configure("Card.TFrame", background=C["bg2"])
        s.configure("TLabel", background=C["bg"], foreground=C["fg"], font=("Segoe UI", 10))
        s.configure("Title.TLabel", foreground=C["fg_bright"], font=("Segoe UI", 16, "bold"), background=C["bg"])
        s.configure("Sub.TLabel", foreground=C["muted"], font=("Segoe UI", 9), background=C["bg"])
        s.configure("Card.TLabel", foreground=C["accent"], font=("Segoe UI", 9, "bold"), background=C["bg2"])
        s.configure("Status.TLabel", foreground=C["green"], font=("Segoe UI", 9), background=C["bg"])
        s.configure("Err.TLabel", foreground=C["red"], font=("Segoe UI", 9), background=C["bg"])
        s.configure("Warn.TLabel", foreground=C["orange"], font=("Segoe UI", 9), background=C["bg"])
        s.configure("GPU.TLabel", foreground=C["accent"], font=("Segoe UI", 8), background=C["bg"])
        s.configure("Muted.TLabel", foreground=C["muted"], font=("Segoe UI", 8), background=C["bg2"])

        s.configure("Accent.TButton", background=C["accent"], foreground=C["bg"],
                     font=("Segoe UI", 10, "bold"), padding=(12, 6))
        s.map("Accent.TButton", background=[("disabled", C["muted"]), ("active", C["accent_hover"])])
        s.configure("Green.TButton", background=C["green"], foreground=C["bg"],
                     font=("Segoe UI", 9, "bold"), padding=(8, 4))
        s.configure("Red.TButton", background=C["red"], foreground="#fff",
                     font=("Segoe UI", 8, "bold"), padding=(6, 2))
        s.configure("Sm.TButton", background=C["border"], foreground=C["muted"],
                     font=("Segoe UI", 8), padding=(6, 2))
        s.map("Sm.TButton", background=[("active", C["muted"])])
        s.configure("Link.TButton", background=C["bg2"], foreground=C["accent"],
                     font=("Segoe UI", 8), padding=(6, 2))
        s.configure("TNotebook", background=C["bg"])
        s.configure("TNotebook.Tab", background=C["bg3"], foreground=C["muted"],
                     font=("Segoe UI", 9, "bold"), padding=(10, 5))
        s.map("TNotebook.Tab",
              background=[("selected", C["bg2"])],
              foreground=[("selected", C["accent"])])
        s.configure("Horizontal.TProgressbar", troughcolor=C["bg3"], background=C["purple"], thickness=8)

    # ── Main UI ───────────────────────────────────────────────────────
    def _build_ui(self):
        top = ttk.Frame(self, padding=12)
        top.pack(fill=tk.X)
        ttk.Label(top, text="LTX-2 Video Studio", style="Title.TLabel").pack(side=tk.LEFT)
        self._gpu_label = ttk.Label(top, text="", style="GPU.TLabel")
        self._gpu_label.pack(side=tk.LEFT, padx=(12, 0))

        # Status + progress
        sf = ttk.Frame(self, padding=(12, 0))
        sf.pack(fill=tk.X)
        self._status_lbl = ttk.Label(sf, text="", style="Status.TLabel")
        self._status_lbl.pack(fill=tk.X)
        self._pbar_frame = ttk.Frame(sf)
        self._pbar_var = tk.DoubleVar(value=0)
        self._pbar = ttk.Progressbar(self._pbar_frame, variable=self._pbar_var, maximum=100)
        self._pbar.pack(fill=tk.X, pady=(2, 0))
        self._pbar_text = ttk.Label(self._pbar_frame, text="", style="Muted.TLabel")
        self._pbar_text.pack(fill=tk.X)

        # Result preview panel (hidden until a task completes)
        self._result_frame = ttk.Frame(self, style="Card.TFrame", padding=10)
        # not packed yet — shown by _show_result()
        self._result_title = ttk.Label(self._result_frame, text="RESULT", style="Card.TLabel")
        self._result_title.pack(anchor=tk.W)
        self._result_file_lbl = ttk.Label(self._result_frame, text="", style="Muted.TLabel")
        self._result_file_lbl.pack(fill=tk.X, pady=(4, 6))
        rbf = ttk.Frame(self._result_frame, style="Card.TFrame")
        rbf.pack(fill=tk.X)
        ttk.Button(rbf, text="Play Video", style="Green.TButton",
                   command=self._play_result).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(rbf, text="Open Folder", style="Sm.TButton",
                   command=self._open_result_folder).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(rbf, text="Dismiss", style="Sm.TButton",
                   command=self._hide_result).pack(side=tk.LEFT)
        self._last_result_path = ""

        # Tabs
        nb = ttk.Notebook(self)
        nb.pack(fill=tk.BOTH, expand=True, padx=12, pady=(6, 12))

        self._build_tab_distilled(nb)
        self._build_tab_twostage(nb)
        self._build_tab_iclora(nb)
        self._build_tab_keyframe(nb)
        self._build_tab_gallery(nb)
        self._build_tab_status(nb)

    # ── helpers ─────────────────────────────────────────────────
    def _card(self, parent, title=""):
        outer = ttk.Frame(parent, style="Card.TFrame", padding=10)
        outer.pack(fill=tk.X, pady=(0, 6))
        if title:
            ttk.Label(outer, text=title, style="Card.TLabel").pack(anchor=tk.W, pady=(0, 6))
        return outer

    def _prompt_box(self, parent, default=""):
        t = tk.Text(parent, bg=C["bg3"], fg=C["fg_bright"], font=("Segoe UI", 10),
                    wrap=tk.WORD, relief="flat", insertbackground=C["fg_bright"],
                    selectbackground=C["accent"], height=3, bd=0, padx=8, pady=6)
        t.pack(fill=tk.X, pady=(0, 4))
        if default:
            t.insert("1.0", default)
        return t

    def _labeled_combo(self, parent, label, values, default, width=20):
        f = ttk.Frame(parent, style="Card.TFrame")
        f.pack(fill=tk.X, pady=(0, 4))
        ttk.Label(f, text=label, style="Muted.TLabel").pack(side=tk.LEFT, padx=(0, 6))
        var = tk.StringVar(value=default)
        cb = ttk.Combobox(f, textvariable=var, values=values, state="readonly",
                          width=width, font=("Segoe UI", 9))
        cb.pack(side=tk.LEFT)
        return var, cb

    def _param_row(self, parent, items):
        """items: list of (label, var, width)"""
        f = ttk.Frame(parent, style="Card.TFrame")
        f.pack(fill=tk.X, pady=(0, 4))
        for label, var, w in items:
            ttk.Label(f, text=label, style="Muted.TLabel").pack(side=tk.LEFT, padx=(0, 4))
            ttk.Entry(f, textvariable=var, width=w, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=(0, 10))
        return f

    def _check(self, parent, text, default=False):
        var = tk.BooleanVar(value=default)
        ttk.Checkbutton(parent, text=text, variable=var).pack(side=tk.LEFT, padx=(8, 0))
        return var

    def _resolution_block(self, card):
        self._aspect_var, _ = self._labeled_combo(card, "Aspect:", list(ASPECT_PRESETS.keys()), "16:9 HD (1280x704)", 28)
        rf = ttk.Frame(card, style="Card.TFrame")
        rf.pack(fill=tk.X, pady=(0, 4))
        ttk.Label(rf, text="W:", style="Muted.TLabel").pack(side=tk.LEFT)
        wvar = tk.StringVar(value="1280")
        ttk.Entry(rf, textvariable=wvar, width=6, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=(2, 8))
        ttk.Label(rf, text="H:", style="Muted.TLabel").pack(side=tk.LEFT)
        hvar = tk.StringVar(value="704")
        ttk.Entry(rf, textvariable=hvar, width=6, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=(2, 8))
        ttk.Label(rf, text="Frames:", style="Muted.TLabel").pack(side=tk.LEFT)
        fvar = tk.StringVar(value="41")
        ttk.Combobox(rf, textvariable=fvar, values=[str(x) for x in FRAME_PRESETS],
                      state="readonly", width=5, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=(2, 8))
        ttk.Label(rf, text="FPS:", style="Muted.TLabel").pack(side=tk.LEFT)
        fps_var = tk.StringVar(value="25")
        ttk.Entry(rf, textvariable=fps_var, width=4, font=("Segoe UI", 9)).pack(side=tk.LEFT)
        return wvar, hvar, fvar, fps_var

    def _seed_row(self, card):
        f = ttk.Frame(card, style="Card.TFrame")
        f.pack(fill=tk.X, pady=(0, 4))
        ttk.Label(f, text="Seed:", style="Muted.TLabel").pack(side=tk.LEFT, padx=(0, 4))
        svar = tk.StringVar(value="42")
        ttk.Entry(f, textvariable=svar, width=10, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=(0, 4))
        ttk.Button(f, text="Dice", style="Sm.TButton",
                   command=lambda: svar.set(str(random.randint(0, 2**31-1)))).pack(side=tk.LEFT, padx=(0, 8))
        return svar, f

    def _template_combo(self, card, prompt_widget):
        var, cb = self._labeled_combo(card, "Template:", list(PROMPT_TEMPLATES.keys()),
                                       "(Select a template)", 28)
        def _apply(*_):
            txt = PROMPT_TEMPLATES.get(var.get(), "")
            if txt:
                prompt_widget.delete("1.0", tk.END)
                prompt_widget.insert("1.0", txt)
        cb.bind("<<ComboboxSelected>>", _apply)
        return var

    def _camera_lora_row(self, card):
        f = ttk.Frame(card, style="Card.TFrame")
        f.pack(fill=tk.X, pady=(0, 4))
        ttk.Label(f, text="Camera LoRA:", style="Muted.TLabel").pack(side=tk.LEFT, padx=(0, 4))
        cvar = tk.StringVar(value="None")
        ttk.Combobox(f, textvariable=cvar, values=CAMERA_LORAS, state="readonly",
                      width=14, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=(0, 8))
        ttk.Label(f, text="Strength:", style="Muted.TLabel").pack(side=tk.LEFT, padx=(0, 4))
        svar = tk.StringVar(value="1.0")
        ttk.Entry(f, textvariable=svar, width=5, font=("Segoe UI", 9)).pack(side=tk.LEFT)
        return cvar, svar

    def _image_row(self, card, label="Reference Image:"):
        f = ttk.Frame(card, style="Card.TFrame")
        f.pack(fill=tk.X, pady=(0, 4))
        ttk.Label(f, text=label, style="Muted.TLabel").pack(side=tk.LEFT, padx=(0, 4))
        pvar = tk.StringVar(value="")
        ttk.Entry(f, textvariable=pvar, width=34, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=(0, 4))
        ttk.Button(f, text="Browse", style="Sm.TButton",
                   command=lambda: pvar.set(filedialog.askopenfilename(
                       filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp *.webp")]))).pack(side=tk.LEFT, padx=(0, 4))
        ttk.Button(f, text="Clear", style="Sm.TButton",
                   command=lambda: pvar.set("")).pack(side=tk.LEFT)
        f2 = ttk.Frame(card, style="Card.TFrame")
        f2.pack(fill=tk.X, pady=(0, 4))
        ttk.Label(f2, text="Frame idx:", style="Muted.TLabel").pack(side=tk.LEFT, padx=(0, 4))
        fi_var = tk.StringVar(value="0")
        ttk.Entry(f2, textvariable=fi_var, width=5, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=(0, 8))
        ttk.Label(f2, text="Strength:", style="Muted.TLabel").pack(side=tk.LEFT, padx=(0, 4))
        st_var = tk.StringVar(value="1.0")
        ttk.Entry(f2, textvariable=st_var, width=5, font=("Segoe UI", 9)).pack(side=tk.LEFT)
        return pvar, fi_var, st_var

    def _checks_row(self, card):
        f = ttk.Frame(card, style="Card.TFrame")
        f.pack(fill=tk.X, pady=(0, 4))
        enh = self._check(f, "Enhance Prompt", False)
        da = self._check(f, "Disable Audio", True)
        return enh, da

    # ── Tab 1: Fast Generation (Distilled) ────────────────────────────
    def _build_tab_distilled(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text=" Fast Generation ")
        canvas = self._scrollable(tab)
        c = self._card(canvas, "FAST GENERATION (Distilled, ~8 steps)")

        self._d_prompt = self._prompt_box(c, "A golden retriever playing fetch on a sunny beach, waves crashing, bright blue sky, the dog runs joyfully, fur gleaming in sunlight.")
        self._d_template = self._template_combo(c, self._d_prompt)
        self._d_seed, seed_f = self._seed_row(c)
        self._d_enhance, self._d_disable_audio = self._checks_row(c)
        self._d_w, self._d_h, self._d_f, self._d_fps = self._resolution_block(c)
        self._d_cam, self._d_cam_str = self._camera_lora_row(c)
        self._d_img, self._d_img_fi, self._d_img_str = self._image_row(c)

        ttk.Button(c, text="Generate Video", style="Accent.TButton",
                   command=lambda: self._submit("distilled", self._gather_distilled())).pack(fill=tk.X, pady=(6, 0))

    def _gather_distilled(self):
        return {
            "task_type": "distilled", "action": "create",
            "prompt": self._d_prompt.get("1.0", tk.END).strip(),
            "seed": self._d_seed.get(), "width": self._d_w.get(), "height": self._d_h.get(),
            "num_frames": self._d_f.get(), "frame_rate": self._d_fps.get(),
            "camera_lora": self._d_cam.get(), "camera_lora_strength": self._d_cam_str.get(),
            "image_path": self._d_img.get() or None,
            "image_frame_idx": self._d_img_fi.get(), "image_strength": self._d_img_str.get(),
            "enhance_prompt": self._d_enhance.get(), "disable_audio": self._d_disable_audio.get(),
        }

    # ── Tab 2: Production Quality (Two-Stage) ────────────────────────
    def _build_tab_twostage(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text=" Production Quality ")
        canvas = self._scrollable(tab)
        c = self._card(canvas, "TWO-STAGE PIPELINE (CFG + STG guidance, ~40 steps)")

        self._ts_prompt = self._prompt_box(c, "A cinematic shot of a vast mountain landscape at golden hour, camera slowly panning across snow-capped peaks, warm light casting long shadows.")
        self._ts_template = self._template_combo(c, self._ts_prompt)

        # Negative prompt
        ttk.Label(c, text="Negative Prompt:", style="Muted.TLabel").pack(anchor=tk.W)
        self._ts_neg = self._prompt_box(c, DEFAULT_NEG)

        self._ts_seed, _ = self._seed_row(c)
        sf = ttk.Frame(c, style="Card.TFrame")
        sf.pack(fill=tk.X, pady=(0, 4))
        ttk.Label(sf, text="Inference Steps:", style="Muted.TLabel").pack(side=tk.LEFT, padx=(0, 4))
        self._ts_steps = tk.StringVar(value="40")
        ttk.Entry(sf, textvariable=self._ts_steps, width=5, font=("Segoe UI", 9)).pack(side=tk.LEFT)
        self._ts_enhance, self._ts_disable_audio = self._checks_row(c)
        self._ts_w, self._ts_h, self._ts_f, self._ts_fps = self._resolution_block(c)
        self._ts_cam, self._ts_cam_str = self._camera_lora_row(c)
        self._ts_img, self._ts_img_fi, self._ts_img_str = self._image_row(c)

        # Guidance
        gc = self._card(canvas, "GUIDANCE PARAMETERS")
        ttk.Label(gc, text="Video:", style="Muted.TLabel").pack(anchor=tk.W)
        self._ts_vcfg = tk.StringVar(value="3.0")
        self._ts_vstg = tk.StringVar(value="1.0")
        self._ts_vresc = tk.StringVar(value="0.7")
        self._param_row(gc, [("CFG:", self._ts_vcfg, 5), ("STG:", self._ts_vstg, 5), ("Rescale:", self._ts_vresc, 5)])
        ttk.Label(gc, text="Audio:", style="Muted.TLabel").pack(anchor=tk.W)
        self._ts_acfg = tk.StringVar(value="7.0")
        self._ts_astg = tk.StringVar(value="1.0")
        self._ts_aresc = tk.StringVar(value="0.7")
        self._param_row(gc, [("CFG:", self._ts_acfg, 5), ("STG:", self._ts_astg, 5), ("Rescale:", self._ts_aresc, 5)])
        self._ts_mod = tk.StringVar(value="3.0")
        self._param_row(gc, [("Modality Scale:", self._ts_mod, 5)])

        ttk.Button(canvas, text="Generate Video (Two-Stage)", style="Accent.TButton",
                   command=lambda: self._submit("two_stage", self._gather_twostage())).pack(fill=tk.X, padx=10, pady=6)

    def _gather_twostage(self):
        return {
            "task_type": "two_stage", "action": "create",
            "prompt": self._ts_prompt.get("1.0", tk.END).strip(),
            "negative_prompt": self._ts_neg.get("1.0", tk.END).strip(),
            "seed": self._ts_seed.get(), "num_inference_steps": self._ts_steps.get(),
            "width": self._ts_w.get(), "height": self._ts_h.get(),
            "num_frames": self._ts_f.get(), "frame_rate": self._ts_fps.get(),
            "camera_lora": self._ts_cam.get(), "camera_lora_strength": self._ts_cam_str.get(),
            "image_path": self._ts_img.get() or None,
            "image_frame_idx": self._ts_img_fi.get(), "image_strength": self._ts_img_str.get(),
            "video_cfg_scale": self._ts_vcfg.get(), "video_stg_scale": self._ts_vstg.get(),
            "video_rescale_scale": self._ts_vresc.get(),
            "audio_cfg_scale": self._ts_acfg.get(), "audio_stg_scale": self._ts_astg.get(),
            "audio_rescale_scale": self._ts_aresc.get(),
            "modality_scale": self._ts_mod.get(),
            "enhance_prompt": self._ts_enhance.get(), "disable_audio": self._ts_disable_audio.get(),
        }

    # ── Tab 3: IC-LoRA ────────────────────────────────────────────────
    def _build_tab_iclora(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text=" IC-LoRA (V2V) ")
        canvas = self._scrollable(tab)
        c = self._card(canvas, "IC-LoRA — VIDEO-TO-VIDEO STRUCTURAL CONTROL")

        ttk.Label(c, text="Canny=edges, Depth=3D structure, Pose=body motion, Detailer=enhance",
                  style="Muted.TLabel").pack(anchor=tk.W, pady=(0, 6))

        self._ic_prompt = self._prompt_box(c, "A cinematic scene with dramatic lighting, smooth camera motion, photorealistic quality, detailed textures.")
        self._ic_seed, _ = self._seed_row(c)
        self._ic_enhance, self._ic_disable_audio = self._checks_row(c)
        self._ic_w, self._ic_h, self._ic_f, self._ic_fps = self._resolution_block(c)

        # IC-LoRA type
        self._ic_type, _ = self._labeled_combo(c, "Control Mode:", IC_LORA_TYPES, "Canny Control", 18)
        f = ttk.Frame(c, style="Card.TFrame")
        f.pack(fill=tk.X, pady=(0, 4))
        ttk.Label(f, text="LoRA Strength:", style="Muted.TLabel").pack(side=tk.LEFT, padx=(0, 4))
        self._ic_lstr = tk.StringVar(value="1.0")
        ttk.Entry(f, textvariable=self._ic_lstr, width=5, font=("Segoe UI", 9)).pack(side=tk.LEFT)

        # Video upload
        vc = self._card(canvas, "INPUT VIDEO")
        ttk.Label(vc, text="Upload a regular video — control signal extracted automatically.", style="Muted.TLabel").pack(anchor=tk.W)
        vf = ttk.Frame(vc, style="Card.TFrame")
        vf.pack(fill=tk.X, pady=(4, 4))
        self._ic_vid = tk.StringVar(value="")
        ttk.Entry(vf, textvariable=self._ic_vid, width=40, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=(0, 4))
        ttk.Button(vf, text="Browse", style="Sm.TButton",
                   command=lambda: self._ic_vid.set(filedialog.askopenfilename(
                       filetypes=[("Video", "*.mp4 *.avi *.mov *.mkv")]))).pack(side=tk.LEFT, padx=(0, 4))
        ttk.Label(vc, text="Conditioning Strength:", style="Muted.TLabel").pack(anchor=tk.W)
        self._ic_vstr = tk.StringVar(value="1.0")
        ttk.Entry(vc, textvariable=self._ic_vstr, width=5, font=("Segoe UI", 9)).pack(anchor=tk.W)
        self._ic_autopp = tk.BooleanVar(value=True)
        ttk.Checkbutton(vc, text="Auto-preprocess (extract control signal)", variable=self._ic_autopp).pack(anchor=tk.W)

        self._ic_img, self._ic_img_fi, self._ic_img_str = self._image_row(canvas, "Image Conditioning (optional):")

        ttk.Button(canvas, text="Generate Video (IC-LoRA)", style="Accent.TButton",
                   command=lambda: self._submit("ic_lora", self._gather_iclora())).pack(fill=tk.X, padx=10, pady=6)

    def _gather_iclora(self):
        return {
            "task_type": "ic_lora", "action": "create",
            "prompt": self._ic_prompt.get("1.0", tk.END).strip(),
            "seed": self._ic_seed.get(),
            "width": self._ic_w.get(), "height": self._ic_h.get(),
            "num_frames": self._ic_f.get(), "frame_rate": self._ic_fps.get(),
            "ic_lora_type": self._ic_type.get(), "ic_lora_strength": self._ic_lstr.get(),
            "video_conditioning_path": self._ic_vid.get() or None,
            "video_conditioning_strength": self._ic_vstr.get(),
            "auto_preprocess": self._ic_autopp.get(),
            "image_path": self._ic_img.get() or None,
            "image_frame_idx": self._ic_img_fi.get(), "image_strength": self._ic_img_str.get(),
            "enhance_prompt": self._ic_enhance.get(), "disable_audio": self._ic_disable_audio.get(),
        }

    # ── Tab 4: Keyframe Interpolation ─────────────────────────────────
    def _build_tab_keyframe(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text=" Keyframe Interpolation ")
        canvas = self._scrollable(tab)
        c = self._card(canvas, "KEYFRAME INTERPOLATION — Two-image morphing")

        self._kf_prompt = self._prompt_box(c, "A smooth cinematic transition between the two scenes, natural motion, consistent lighting and style.")
        self._kf_template = self._template_combo(c, self._kf_prompt)
        ttk.Label(c, text="Negative Prompt:", style="Muted.TLabel").pack(anchor=tk.W)
        self._kf_neg = self._prompt_box(c, DEFAULT_NEG)
        self._kf_seed, _ = self._seed_row(c)
        sf = ttk.Frame(c, style="Card.TFrame")
        sf.pack(fill=tk.X, pady=(0, 4))
        ttk.Label(sf, text="Inference Steps:", style="Muted.TLabel").pack(side=tk.LEFT, padx=(0, 4))
        self._kf_steps = tk.StringVar(value="40")
        ttk.Entry(sf, textvariable=self._kf_steps, width=5, font=("Segoe UI", 9)).pack(side=tk.LEFT)
        self._kf_enhance, self._kf_disable_audio = self._checks_row(c)
        self._kf_w, self._kf_h, self._kf_f, self._kf_fps = self._resolution_block(c)
        self._kf_cam, self._kf_cam_str = self._camera_lora_row(c)

        kc1 = self._card(canvas, "KEYFRAME 1 (Start)")
        self._kf1_img, self._kf1_fi, self._kf1_str = self._image_row(kc1, "Start Image:")
        kc2 = self._card(canvas, "KEYFRAME 2 (End)")
        self._kf2_img, self._kf2_fi, self._kf2_str = self._image_row(kc2, "End Image:")
        self._kf2_fi.set("56")

        gc = self._card(canvas, "GUIDANCE PARAMETERS")
        self._kf_vcfg = tk.StringVar(value="3.0")
        self._kf_vstg = tk.StringVar(value="1.0")
        self._kf_vresc = tk.StringVar(value="0.7")
        self._param_row(gc, [("V-CFG:", self._kf_vcfg, 5), ("V-STG:", self._kf_vstg, 5), ("V-Resc:", self._kf_vresc, 5)])
        self._kf_acfg = tk.StringVar(value="7.0")
        self._kf_astg = tk.StringVar(value="1.0")
        self._kf_aresc = tk.StringVar(value="0.7")
        self._param_row(gc, [("A-CFG:", self._kf_acfg, 5), ("A-STG:", self._kf_astg, 5), ("A-Resc:", self._kf_aresc, 5)])
        self._kf_mod = tk.StringVar(value="3.0")
        self._param_row(gc, [("Modality Scale:", self._kf_mod, 5)])

        ttk.Button(canvas, text="Generate Interpolation", style="Accent.TButton",
                   command=lambda: self._submit("keyframe", self._gather_keyframe())).pack(fill=tk.X, padx=10, pady=6)

    def _gather_keyframe(self):
        return {
            "task_type": "keyframe", "action": "create",
            "prompt": self._kf_prompt.get("1.0", tk.END).strip(),
            "negative_prompt": self._kf_neg.get("1.0", tk.END).strip(),
            "seed": self._kf_seed.get(), "num_inference_steps": self._kf_steps.get(),
            "width": self._kf_w.get(), "height": self._kf_h.get(),
            "num_frames": self._kf_f.get(), "frame_rate": self._kf_fps.get(),
            "camera_lora": self._kf_cam.get(), "camera_lora_strength": self._kf_cam_str.get(),
            "keyframe1_path": self._kf1_img.get() or None,
            "keyframe1_frame_idx": self._kf1_fi.get(), "keyframe1_strength": self._kf1_str.get(),
            "keyframe2_path": self._kf2_img.get() or None,
            "keyframe2_frame_idx": self._kf2_fi.get(), "keyframe2_strength": self._kf2_str.get(),
            "video_cfg_scale": self._kf_vcfg.get(), "video_stg_scale": self._kf_vstg.get(),
            "video_rescale_scale": self._kf_vresc.get(),
            "audio_cfg_scale": self._kf_acfg.get(), "audio_stg_scale": self._kf_astg.get(),
            "audio_rescale_scale": self._kf_aresc.get(),
            "modality_scale": self._kf_mod.get(),
            "enhance_prompt": self._kf_enhance.get(), "disable_audio": self._kf_disable_audio.get(),
        }

    # ── Tab 5: Gallery ────────────────────────────────────────────────
    def _build_tab_gallery(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text=" Gallery ")
        bf = ttk.Frame(tab, style="TFrame", padding=8)
        bf.pack(fill=tk.X)
        ttk.Button(bf, text="Refresh", style="Sm.TButton", command=self._refresh_gallery).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(bf, text="Open Output Folder", style="Green.TButton", command=self._open_output_folder).pack(side=tk.LEFT)
        self._gallery_summary = ttk.Label(bf, text="", style="Muted.TLabel")
        self._gallery_summary.pack(side=tk.LEFT, padx=(12, 0))
        self._gallery_list = tk.Listbox(tab, bg=C["bg3"], fg=C["fg"], font=("Consolas", 9),
                                        selectbackground=C["accent"], relief="flat", height=22)
        self._gallery_list.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))

    def _refresh_gallery(self):
        self._gallery_list.delete(0, tk.END)
        outdir = Path(OUTPUT_DIR)
        if not outdir.exists():
            self._gallery_summary.configure(text="No output directory")
            return
        videos = sorted(outdir.glob("*.mp4"), key=os.path.getmtime, reverse=True)
        total_mb = sum(v.stat().st_size for v in videos) / (1024**2)
        self._gallery_summary.configure(text=f"{len(videos)} videos, {total_mb:.0f} MB total")
        for v in videos[:100]:
            size_mb = v.stat().st_size / (1024**2)
            ts = time.strftime("%Y-%m-%d %H:%M", time.localtime(v.stat().st_mtime))
            self._gallery_list.insert(tk.END, f"{ts}  {v.name}  ({size_mb:.1f} MB)")

    def _open_output_folder(self):
        if os.path.isdir(OUTPUT_DIR):
            if sys.platform == "win32":
                os.startfile(OUTPUT_DIR)
            else:
                subprocess.Popen(["xdg-open", OUTPUT_DIR])

    # ── Tab 6: Status ─────────────────────────────────────────────────
    def _build_tab_status(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text=" Status & Logs ")
        bf = ttk.Frame(tab, padding=8)
        bf.pack(fill=tk.X)
        ttk.Button(bf, text="Refresh Logs", style="Sm.TButton",
                   command=self._refresh_status_logs).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(bf, text="Refresh Tasks", style="Sm.TButton",
                   command=self._refresh_tasks).pack(side=tk.LEFT, padx=(0, 6))
        self._status_info = ttk.Label(bf, text="", style="Muted.TLabel")
        self._status_info.pack(side=tk.LEFT, padx=(12, 0))

        # Task queue
        ttk.Label(tab, text="TASK QUEUE", style="Card.TLabel", padding=(8, 4)).pack(anchor=tk.W)
        self._task_list = tk.Listbox(tab, bg=C["bg3"], fg=C["fg"], font=("Consolas", 9),
                                     selectbackground=C["accent"], relief="flat", height=6)
        self._task_list.pack(fill=tk.X, padx=8, pady=(0, 4))

        # Log viewer
        ttk.Label(tab, text="SERVER LOGS", style="Card.TLabel", padding=(8, 4)).pack(anchor=tk.W)
        self._log_text = tk.Text(tab, bg="#0a0a0f", fg=C["muted"], font=("Consolas", 8),
                                 wrap=tk.WORD, relief="flat", height=16, bd=0, padx=6, pady=6,
                                 insertbackground=C["muted"])
        self._log_text.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))
        self._log_text.tag_configure("INFO", foreground=C["fg"])
        self._log_text.tag_configure("WARN", foreground=C["orange"])
        self._log_text.tag_configure("ERROR", foreground=C["red"])

    def _refresh_status_logs(self):
        def fetch():
            try:
                code, data = call_runner("GET", "/api/logs", timeout=5)
                if code == 200:
                    self.after(0, lambda: self._render_logs(data.get("logs", [])))
            except Exception:
                pass
        threading.Thread(target=fetch, daemon=True).start()

    def _render_logs(self, logs):
        self._log_text.configure(state=tk.NORMAL)
        self._log_text.delete("1.0", tk.END)
        for e in logs:
            lvl = e.get("level", "INFO")
            self._log_text.insert(tk.END, f"{e.get('ts','')} {e.get('msg','')}\n", lvl)
        self._log_text.see(tk.END)
        self._log_text.configure(state=tk.DISABLED)

    def _refresh_tasks(self):
        if self._shutting_down:
            return
        def fetch():
            try:
                code, data = call_runner("GET", "/api/tasks", timeout=5)
                if code == 200:
                    self.after(0, lambda: self._render_tasks(data.get("tasks", [])))
            except Exception:
                pass
        threading.Thread(target=fetch, daemon=True).start()

    def _render_tasks(self, items):
        self._task_list.delete(0, tk.END)
        if not items:
            self._task_list.insert(tk.END, "  (no tasks)")
            self._status_info.configure(text="0 tasks")
            return
        active = sum(1 for t in items if t.get("status") in ("QUEUED", "PROCESSING"))
        self._status_info.configure(text=f"{len(items)} tasks ({active} active)")
        for t in items:
            st = t.get("status", "?")
            label = t.get("task_label") or t.get("task_type", "?")
            pct = int((t.get("progress") or 0) * 100)
            msg = t.get("message", "")[:60]
            self._task_list.insert(tk.END, f"  [{st:10}] {label:24} {pct:3d}%  {msg}")

    # ── Scrollable helper ─────────────────────────────────────────────
    def _scrollable(self, parent):
        canvas = tk.Canvas(parent, bg=C["bg"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(parent, orient=tk.VERTICAL, command=canvas.yview)
        frame = ttk.Frame(canvas)
        frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=frame, anchor=tk.NW)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.bind_all("<MouseWheel>",
                        lambda e: canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))
        return frame

    # ── Submit / Poll ─────────────────────────────────────────────────
    def _submit(self, task_type, data):
        prompt = data.get("prompt", "")
        if not prompt:
            self._set_status("Enter a prompt first.", "err")
            return
        self._set_status("Submitting...", "warn")
        self._show_progress(0, "Queued...")

        def do():
            code, resp = call_runner("POST", "/api/generate", json_data=data)
            if code == 200 and resp.get("task_id"):
                tid = resp["task_id"]
                self._active_task_id = tid
                self.after(0, lambda: self._set_status(f"Task queued.", "ok"))
                self.after(0, lambda: self._start_poll(tid))
                self.after(0, self._refresh_tasks)
            else:
                err = resp.get("error", "Unknown error")
                self.after(0, lambda: self._set_status(f"Error: {err}", "err"))
                self.after(0, self._hide_progress)
        threading.Thread(target=do, daemon=True).start()

    def _start_poll(self, task_id):
        self._poll_gen += 1
        gen = self._poll_gen

        def tick():
            if gen != self._poll_gen or self._shutting_down:
                return
            code, d = call_runner("POST", "/api/generate",
                                  json_data={"action": "check", "task_id": task_id})
            if gen != self._poll_gen:
                return
            st = (d.get("status") or "").upper()
            pct = (d.get("progress") or 0) * 100
            msg = d.get("message") or st
            self.after(0, lambda: self._show_progress(pct, f"{msg}  ({pct:.0f}%)"))
            if st == "DONE":
                result = d.get("result", "")
                self.after(0, lambda: self._on_done(result, msg))
            elif st in ("ERROR", "CANCELLED", "TIMEOUT"):
                kind = "err" if st == "ERROR" else "warn"
                self.after(0, lambda: self._set_status(d.get("error") or msg, kind))
                self.after(0, self._hide_progress)
                self.after(0, self._refresh_tasks)
            else:
                self.after(POLL_MS, tick)
        self.after(POLL_MS, tick)

    def _on_done(self, result_path, msg):
        self._hide_progress()
        self._set_status(msg or "Done.", "ok")
        self._refresh_tasks()
        if result_path and os.path.isfile(result_path):
            self._show_result(result_path)

    def _show_result(self, path):
        self._last_result_path = path
        fname = os.path.basename(path)
        size_mb = os.path.getsize(path) / (1024 ** 2)
        self._result_file_lbl.configure(
            text=f"{fname}  ({size_mb:.1f} MB)\n{path}")
        self._result_frame.pack(fill=tk.X, padx=12, pady=(0, 4), before=self._result_frame.master.winfo_children()[-1])
        # repack to ensure it's between progress and tabs
        self._result_frame.pack_forget()
        self._result_frame.pack(fill=tk.X, padx=12, pady=(4, 4), after=self._status_lbl.master)

    def _hide_result(self):
        self._result_frame.pack_forget()

    def _play_result(self):
        path = self._last_result_path
        if not path or not os.path.isfile(path):
            self._set_status("No result file to play.", "err")
            return
        flog(f"Playing: {path}")
        try:
            if sys.platform == "win32":
                os.startfile(path)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception as e:
            self._set_status(f"Cannot open: {e}", "err")

    def _open_result_folder(self):
        path = self._last_result_path
        if path and os.path.isfile(path):
            folder = os.path.dirname(path)
        else:
            folder = OUTPUT_DIR
        try:
            if sys.platform == "win32":
                subprocess.Popen(["explorer", "/select,", path] if path and os.path.isfile(path)
                                 else ["explorer", folder])
            elif sys.platform == "darwin":
                subprocess.Popen(["open", folder])
            else:
                subprocess.Popen(["xdg-open", folder])
        except Exception as e:
            self._set_status(f"Cannot open folder: {e}", "err")

    # ── Status helpers ────────────────────────────────────────────────
    def _set_status(self, msg, kind=""):
        style_map = {"ok": "Status.TLabel", "err": "Err.TLabel", "warn": "Warn.TLabel"}
        self._status_lbl.configure(text=msg, style=style_map.get(kind, "Status.TLabel"))

    def _show_progress(self, pct, msg=""):
        self._pbar_frame.pack(fill=tk.X, pady=(2, 0))
        self._pbar_var.set(min(pct, 100))
        self._pbar_text.configure(text=msg)

    def _hide_progress(self):
        self._pbar_frame.pack_forget()

    # ── Runner management ─────────────────────────────────────────────
    def _init_runner(self):
        self._set_status("Checking runner...", "warn")

        def check():
            if runner_healthy():
                self.after(0, self._on_runner_ready)
            else:
                self.after(0, lambda: self._set_status("Starting runner (loading models, 60-180s)...", "warn"))
                self._start_runner()
                self._wait_for_runner()
        threading.Thread(target=check, daemon=True).start()

    def _start_runner(self):
        flog(f"Starting runner: {sys.executable} {RUNNER_SCRIPT}")
        try:
            kw = {}
            if sys.platform == "win32":
                kw["creationflags"] = subprocess.CREATE_NO_WINDOW
            self._runner_stderr_path = os.path.join(LOG_DIR, "runner_stderr.log")
            self._runner_stderr_fh = open(self._runner_stderr_path, "w", encoding="utf-8")
            self._runner_proc = subprocess.Popen(
                [sys.executable, RUNNER_SCRIPT], cwd=SCRIPT_DIR,
                stdout=subprocess.DEVNULL, stderr=self._runner_stderr_fh,
                **kw)
        except Exception as e:
            flog(f"Failed: {e}", "ERROR")
            self.after(0, lambda: self._set_status(f"Runner failed: {e}", "err"))

    def _wait_for_runner(self):
        def wait():
            start = time.monotonic()
            while time.monotonic() - start < 600:
                if self._runner_proc and self._runner_proc.poll() is not None:
                    rc = self._runner_proc.returncode
                    stderr_out = ""
                    try:
                        self._runner_stderr_fh.flush()
                        with open(self._runner_stderr_path, "r", encoding="utf-8", errors="replace") as f:
                            stderr_out = f.read()[-500:]
                    except Exception:
                        pass
                    flog(f"Runner crashed (code {rc}): {stderr_out}", "ERROR")
                    self.after(0, lambda: self._set_status(
                        f"Runner crashed (code {rc}). Check logs/runner.log", "err"))
                    return
                elapsed = int(time.monotonic() - start)
                dots = "." * ((elapsed // 2) % 4)
                self.after(0, lambda d=dots, e=elapsed:
                           self._set_status(f"Loading models{d} ({e}s)", "warn"))
                if runner_healthy():
                    self.after(0, self._on_runner_ready)
                    return
                time.sleep(2)
            self.after(0, lambda: self._set_status("Runner startup timed out.", "err"))
        threading.Thread(target=wait, daemon=True).start()

    def _on_runner_ready(self):
        flog("Runner ready")
        self._set_status("Ready. Select a tab and generate.", "ok")
        code, data = call_runner("GET", "/healthz", timeout=5)
        if code == 200:
            gpu = data.get("gpu", "")
            mode = "Streaming" if data.get("streaming") else "Standard"
            self._gpu_label.configure(text=f"GPU: {gpu} [{mode}]" if gpu else "CPU mode")
        self._auto_refresh()

    def _auto_refresh(self):
        if self._shutting_down:
            return
        self._refresh_tasks()
        self.after(TASK_REFRESH_MS, self._auto_refresh)

    # ── Cleanup ───────────────────────────────────────────────────────
    def _on_close(self):
        self._shutting_down = True
        flog("Closing")
        if self._runner_proc and self._runner_proc.poll() is None:
            self._runner_proc.terminate()
            try:
                self._runner_proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self._runner_proc.kill()
        try:
            if hasattr(self, "_runner_stderr_fh") and self._runner_stderr_fh:
                self._runner_stderr_fh.close()
        except Exception:
            pass
        self.destroy()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--runner-url", default=None)
    args = parser.parse_args()
    if args.runner_url:
        global RUNNER_BASE
        RUNNER_BASE = args.runner_url
    flog("=" * 50)
    flog("LTX-2 Video Studio starting")
    app = LTX2App()
    app.mainloop()


if __name__ == "__main__":
    main()
