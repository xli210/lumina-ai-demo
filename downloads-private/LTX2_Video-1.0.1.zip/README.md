# LTX-2 Video Generation Studio

A comprehensive Gradio-based UI for video generation using [Lightricks' LTX-2](https://github.com/Lightricks/LTX-2) model. Supports all official pipelines with LoRA control, optimized for NVIDIA RTX 5090 (32GB VRAM).

## Features

- **Fast Generation** — DistilledPipeline with 8 predefined sigmas (~40s)
- **Production Quality** — TI2VidTwoStagesPipeline with CFG/STG guidance + 2x upsampling
- **IC-LoRA** — Video-to-video transformations (Canny, Depth, Detailer, Pose control)
- **Keyframe Interpolation** — Smooth transitions between keyframe images
- **Camera Control** — 7 camera LoRAs (Dolly In/Out/Left/Right, Jib Up/Down, Static)
- **FP8 Native Quantization** — Custom mixed-precision loading preserving original checkpoint quality
- **One-Click Launch** — Self-contained portable environment (no Python install needed)

## Requirements

- NVIDIA GPU with 24GB+ VRAM (tested on RTX 5090 32GB)
- Windows 10/11 (64-bit)
- ~90GB disk space (models downloaded automatically on first run)
- Internet connection for first-time model download

## Quick Start (Product Mode)

The easiest way to get started — no Python installation required:

1. **Build the environment** (one-time):
   ```
   Double-click BUILD.bat
   ```
   This downloads a portable Python + all dependencies (~6 GB).

2. **Launch the studio**:
   ```
   Double-click "Launch LTX-2 Studio.bat"
   ```
   On first launch, models are downloaded automatically from HuggingFace (~80 GB).
   Subsequent launches start in seconds.

3. **Use the UI** — Your browser opens to `http://localhost:7860` with 4 generation tabs.

> **Note:** The Gemma text encoder may require a HuggingFace account with accepted terms.
> If prompted, visit https://huggingface.co/google/gemma-3-12b-it-qat-q4_0-unquantized to accept,
> then run `LTX2_env\python.exe -m huggingface_hub.cli login` to set your token.

## Developer Setup

For development with the full LTX-2 repository:

```bash
# Clone with submodule
git clone --recursive <this-repo-url>
cd LTX

# Set up LTX-2 environment
cd LTX-2
uv sync --frozen
cd ..

# Install PyTorch nightly (CUDA 12.8)
LTX-2\.venv\Scripts\python -m pip install -U --pre torch torchaudio torchvision --index-url https://download.pytorch.org/whl/nightly/cu128

# Install triton for FP8 support
LTX-2\.venv\Scripts\python -m pip install triton-windows

# Install Gradio
LTX-2\.venv\Scripts\python -m pip install gradio
```

### Download Models

Place all models in the `models/` directory:

```bash
# Run the download script for LoRAs
python download_loras.py

# Or manually download from HuggingFace:
# https://huggingface.co/Lightricks/ltx-2-19b
```

Required models:
- `ltx-2-19b-distilled-fp8.safetensors`
- `ltx-2-19b-dev-fp8.safetensors`
- `ltx-2-spatial-upscaler-x2-1.0.safetensors`
- `ltx-2-19b-distilled-lora-384.safetensors`
- Gemma 3 text encoder (in `models/gemma/`)
- All camera control and IC-LoRA weights (in `models/loras/`)

## Usage

### Gradio UI (Development Mode)

```bash
LTX-2\.venv\Scripts\python app.py
# Opens at http://localhost:7860
```

### Run Tests

```bash
LTX-2\.venv\Scripts\python test_pipelines.py
```

Tests all 7 pipeline configurations:
1. Distilled Pipeline (basic)
2. Distilled + Camera LoRA
3. Two-Stage Pipeline
4. Two-Stage + Camera LoRA
5. IC-LoRA Pipeline (Detailer)
6. All 7 Camera LoRAs
7. All 4 IC-LoRAs

## Project Structure

```
LTX-2-Studio/
├── LTX2_env/              # Portable Python environment (created by BUILD.bat)
├── LTX-2/                 # LTX-2 source (git submodule, dev mode only)
├── models/                # Model checkpoints (auto-downloaded)
│   ├── gemma/             # Gemma text encoder
│   ├── loras/             # Camera & IC-LoRA weights
│   └── *.safetensors      # Base model checkpoints
├── outputs/               # Generated videos
├── app.py                 # Gradio UI application
├── launch_app.py          # Launcher (model download + server start)
├── BUILD.bat              # Environment builder (one-time)
├── Launch LTX-2 Studio.bat    # User launcher
├── Launch LTX-2 Studio.vbs    # Silent launcher (no console)
└── test_pipelines.py      # Pipeline test suite
```

## Technical Notes

### FP8 Native Quantization

The FP8 checkpoints use a mixed-precision format:
- Blocks 1–42: `float8_e4m3fn` (quantized by model authors)
- Blocks 0, 43–47: `bfloat16` (full precision boundary blocks)

Our custom `get_fp8_native_quant()` policy preserves this native format instead of naively downcasting all blocks to FP8 (which causes noisy output). Weight scale keys are dropped since they're all 1.0, and `UPCAST_DURING_INFERENCE` handles FP8→BF16 conversion on-the-fly.

Peak VRAM: ~28.7GB for the mixed-format transformer model.

### Portable Environment

The product build uses Python's embeddable distribution — a minimal, self-contained Python runtime that requires no system-wide installation. The `BUILD.bat` script:
1. Downloads Python 3.12 embeddable from python.org
2. Configures it for site-packages support
3. Installs all dependencies (PyTorch CUDA, Gradio, etc.)
4. Copies LTX-2 core packages into the environment

The result is a fully portable folder that can be zipped and distributed.

## License

This project uses the [LTX-2 model](https://github.com/Lightricks/LTX-2) by Lightricks. See their repository for model licensing terms.
