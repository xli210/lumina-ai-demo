"""
VRAM Management for LTX-2 Video Generation Studio.

Provides automatic GPU detection, VRAM tier classification, and per-model
offload configurations that enable running on GPUs from 16GB to 32GB+.

The key insight: LTX-2 loads models *sequentially* (text encoder → transformer → VAE),
so peak VRAM = one large model + working memory. By controlling how much of each
model lives on GPU vs CPU RAM, we can fit on any GPU tier.

Memory budget per component (approximate, FP8 checkpoint):
  - Gemma 3 12B text encoder : ~12 GB (BF16 weights, FP8 not available for this)
  - Transformer (19B, FP8)   : ~10 GB (FP8 blocks) + ~2 GB (BF16 boundary blocks)
  - VAE decoder              : ~1.5 GB
  - VAE encoder              : ~1.5 GB
  - Audio decoder + Vocoder  : ~1.5 GB
  - Spatial upsampler        : ~1 GB
  - Working memory (latents) : 2-8 GB (depends on resolution/frames)
"""

import logging
import re
from dataclasses import dataclass

import torch

logger = logging.getLogger(__name__)


# ============================================================================
# VRAM Tier Detection
# ============================================================================

@dataclass
class VRAMProfile:
    """Configuration for a specific VRAM tier."""
    name: str
    total_vram_gb: float
    # max_memory dicts for accelerate's dispatch_model (None = all on GPU)
    transformer_max_memory: dict | None
    text_encoder_max_memory: dict | None
    upsampler_max_memory: dict | None
    # Resolution/frame limits for 1080p target
    max_frames_1080p: int      # 1920x1088
    max_frames_720p: int       # 1280x704
    max_frames_1536x1024: int  # 1536x1024
    # Whether to default to audio disabled (saves ~2GB working memory)
    default_disable_audio: bool
    # Safe mode description for UI
    description: str
    # Streaming DiT: stream transformer blocks through GPU via CUDA streams
    # instead of loading the full model.  Reduces peak VRAM from ~12 GB to ~3-5 GB.
    use_streaming: bool = False


def _gb(n: float) -> str:
    """Format GB for max_memory dict."""
    return f"{n:.1f}GiB"


# ============================================================================
# Known GPU database  (name substring → VRAM in GB)
# If the detected VRAM is unreliable (e.g. shared memory), this lookup takes
# precedence.  Entries are matched case-insensitively via substring search.
# ============================================================================
_KNOWN_GPUS: dict[str, float] = {
    # --- NVIDIA GeForce RTX 50-series ---
    "RTX 5090":  32.0,
    "RTX 5080":  16.0,
    "RTX 5070 Ti": 16.0,
    "RTX 5070":  12.0,
    "RTX 5060 Ti": 16.0,
    "RTX 5060":   8.0,
    # --- NVIDIA GeForce RTX 40-series ---
    "RTX 4090":  24.0,
    "RTX 4080 SUPER": 16.0,
    "RTX 4080":  16.0,
    "RTX 4070 Ti SUPER": 16.0,
    "RTX 4070 Ti": 12.0,
    "RTX 4070 SUPER": 12.0,
    "RTX 4070":  12.0,
    "RTX 4060 Ti": 16.0,   # 16 GB variant; 8 GB also exists
    "RTX 4060":   8.0,
    # --- NVIDIA GeForce RTX 30-series ---
    "RTX 3090 Ti": 24.0,
    "RTX 3090":  24.0,
    "RTX 3080 Ti": 12.0,
    "RTX 3080":  12.0,     # 12 GB variant; 10 GB also exists
    "RTX 3070 Ti":  8.0,
    "RTX 3070":   8.0,
    "RTX 3060 Ti":  8.0,
    "RTX 3060":  12.0,
    # --- NVIDIA Professional / Data-center ---
    "RTX PRO 6000": 96.0,
    "RTX 6000 Ada": 48.0,
    "RTX A6000":  48.0,
    "RTX A5000":  24.0,
    "RTX A4000":  16.0,
    "A100":       80.0,    # could be 40 GB variant too – VRAM check will fix
    "H100":       80.0,
    "H200":      141.0,
    "L40":        48.0,
    "L4":         24.0,
}


def _match_gpu_name(gpu_name: str) -> float | None:
    """Return the known VRAM (GB) for a GPU name, or None if not in the DB.

    Searches longest-match-first so "RTX 4080 SUPER" matches before "RTX 4080".
    """
    upper = gpu_name.upper()
    # Sort by key length descending so more-specific names match first
    for key in sorted(_KNOWN_GPUS, key=len, reverse=True):
        if key.upper() in upper:
            return _KNOWN_GPUS[key]
    return None


# ============================================================================
# Profile builder — creates a VRAMProfile for any VRAM amount
# ============================================================================

def _build_profile(gpu_name: str, vram_gb: float) -> VRAMProfile:
    """Build an optimised VRAMProfile for the given GPU and VRAM amount.

    Instead of hard-coding three buckets we compute the offload budgets and
    frame limits *continuously* from the actual VRAM figure so that e.g. a
    20 GB GPU gets different limits from a 24 GB one.
    """

    # --- offload logic ---
    # Transformer (FP8)    weights ≈ 12 GB, peak activations ≈ 6-8 GB
    # Text encoder (BF16)  weights ≈ 12 GB, peak activations ≈ 2-4 GB
    # Upsampler             weights ≈  1 GB
    # CUDA context / kernel overhead ≈ 1.5 GB
    #
    # A model needs its weights + activation headroom to run without OOM.
    # We compute: does (model_weights + activation_headroom) fit in VRAM?
    cuda_overhead  = 1.5   # GB — driver / kernel / allocator overhead
    available      = vram_gb - cuda_overhead

    # Transformer: weights ~12 GB + activations ~8 GB = ~20 GB total
    xformer_weights   = 12.0
    xformer_headroom  =  8.0   # attention activations during denoising
    xformer_total     = xformer_weights + xformer_headroom
    if available >= xformer_total:
        transformer_mm = None  # fits entirely with room for activations
    else:
        # Give the GPU as much as possible, leave activation room
        gpu_budget = max(available - xformer_headroom, 2.0)
        transformer_mm = {0: _gb(gpu_budget), "cpu": "64GiB"}

    # Text encoder: weights ~12 GB + activations ~3 GB = ~15 GB total
    text_enc_weights  = 12.0
    text_enc_headroom =  3.0
    text_enc_total    = text_enc_weights + text_enc_headroom
    if available >= text_enc_total:
        text_encoder_mm = None
    else:
        gpu_budget = max(available - text_enc_headroom, 2.0)
        text_encoder_mm = {0: _gb(gpu_budget), "cpu": "64GiB"}

    # Upsampler: weights ~1 GB + activations ~2 GB = ~3 GB total
    upsampler_total = 3.0
    if available >= upsampler_total:
        upsampler_mm = None
    else:
        upsampler_mm = {0: _gb(max(available - 1.0, 1.0)), "cpu": "64GiB"}

    # --- frame limits ---
    # When using CPU offloading (transformer_mm is not None), model weights
    # live on CPU and VRAM only holds activations (~2-4 GB) plus the latent
    # tensor (tiny).  In that regime the frame limit is almost the same as a
    # large GPU — proven by nalexand/LTX-2-OPTIMIZED running 121 frames
    # @1080p on 8 GB.  We only scale down slightly for the smallest GPUs
    # where even activations are tight.
    if transformer_mm is None:
        # Full GPU — latent + model weights compete for VRAM
        ref_available = 30.5
        scale = min(available / ref_available, 1.0)
    else:
        # CPU offload — VRAM only holds one layer's activations + latent.
        # Activations are bounded per-layer (~2-3 GB) and the latent tensor
        # is tiny (~10 MB even at 1080p/121 frames).  Proven by
        # nalexand/LTX-2-OPTIMIZED: 8 GB GPUs achieve 121 frames @1080p.
        #
        # Scale slightly by available VRAM for very small GPUs where even
        # per-layer activations are tight, but keep a high floor.
        if available >= 6.0:     # 8+ GB GPUs
            scale = 1.0          # same limits as full-GPU cards
        elif available >= 4.0:   # ~6 GB GPUs
            scale = 0.85
        else:                    # < 6 GB — very constrained
            scale = 0.65

    max_1080p     = max(9, int(121 * scale)  // 8 * 8 + 1)
    max_720p      = max(9, int(257 * scale)  // 8 * 8 + 1)
    max_1536x1024 = max(9, int(121 * scale)  // 8 * 8 + 1)

    # --- audio default ---
    # Disable audio for GPUs under 20 GB — saves ~2 GB working memory
    disable_audio = vram_gb < 20.0

    # --- streaming DiT ---
    # When VRAM < 20 GB, use CUDA-stream block streaming instead of keeping
    # the full transformer on GPU.  Cuts peak VRAM from ~12 GB to ~3-5 GB
    # at the cost of ~30-50% slower denoising (CPU<->GPU DMA per block).
    # GPUs >= 20 GB have enough headroom for the full model + activations.
    STREAMING_THRESHOLD_GB = 20.0
    use_streaming = vram_gb < STREAMING_THRESHOLD_GB

    # --- description ---
    if transformer_mm is None and text_encoder_mm is None:
        desc = "Full GPU acceleration. All models fit in VRAM."
    elif use_streaming:
        desc = "Streaming DiT: blocks streamed through GPU (low VRAM, slower)."
    elif transformer_mm is None:
        desc = "Text encoder partially offloaded to CPU."
    else:
        desc = "Models partially offloaded to CPU RAM (slower, saves VRAM)."

    name = f"{gpu_name}  ({vram_gb:.0f} GB)"

    return VRAMProfile(
        name=name,
        total_vram_gb=vram_gb,
        transformer_max_memory=transformer_mm,
        text_encoder_max_memory=text_encoder_mm,
        upsampler_max_memory=upsampler_mm,
        max_frames_1080p=max_1080p,
        max_frames_720p=max_720p,
        max_frames_1536x1024=max_1536x1024,
        default_disable_audio=disable_audio,
        description=desc,
        use_streaming=use_streaming,
    )


# ============================================================================
# Public API
# ============================================================================

# Cached so we only probe the GPU once
_cached_profile: VRAMProfile | None = None


def detect_vram_profile() -> VRAMProfile:
    """Auto-detect GPU model and build the best VRAMProfile.

    Detection order:
      1. Match the GPU name against the known-GPU database for the *canonical*
         VRAM figure (avoids shared-memory / driver reporting quirks).
      2. Fall back to ``torch.cuda.get_device_properties().total_memory``.
      3. Build a profile with continuous offload budgets tuned to the exact
         VRAM amount.
    """
    global _cached_profile
    if _cached_profile is not None:
        return _cached_profile

    if not torch.cuda.is_available():
        logger.warning("No CUDA GPU detected — using conservative 8 GB profile.")
        _cached_profile = _build_profile("CPU-only", 8.0)
        return _cached_profile

    gpu_name = torch.cuda.get_device_name(0)
    props    = torch.cuda.get_device_properties(0)
    reported = (getattr(props, "total_memory", 0)
                or getattr(props, "total_mem", 0)) / (1024 ** 3)

    # 1) Try the known-GPU database first
    known_vram = _match_gpu_name(gpu_name)

    if known_vram is not None:
        # Use the canonical figure but cross-check with the driver
        vram_gb = known_vram
        if abs(reported - known_vram) > 4.0:
            # Big discrepancy — trust the driver (e.g. A100 40GB variant)
            vram_gb = reported
            logger.info(
                f"GPU '{gpu_name}' is in DB as {known_vram:.0f} GB but driver "
                f"reports {reported:.1f} GB — using driver value."
            )
    else:
        # Unknown GPU — trust the driver
        vram_gb = reported
        logger.info(f"GPU '{gpu_name}' not in known-GPU database — using "
                     f"driver-reported {reported:.1f} GB.")

    logger.info(f"Detected GPU: {gpu_name} | VRAM: {vram_gb:.1f} GB")

    _cached_profile = _build_profile(gpu_name, vram_gb)

    logger.info(f"VRAM profile: {_cached_profile.name}")
    logger.info(f"  Transformer offload : {'None (full GPU)' if _cached_profile.transformer_max_memory is None else _cached_profile.transformer_max_memory}")
    logger.info(f"  Text-encoder offload: {'None (full GPU)' if _cached_profile.text_encoder_max_memory is None else _cached_profile.text_encoder_max_memory}")
    logger.info(f"  Max frames @1080p   : {_cached_profile.max_frames_1080p}")
    logger.info(f"  Max frames @720p    : {_cached_profile.max_frames_720p}")
    logger.info(f"  Disable audio       : {_cached_profile.default_disable_audio}")
    logger.info(f"  Streaming DiT       : {_cached_profile.use_streaming}")

    return _cached_profile


# Pre-built quick-reference profiles for the UI dropdown.
# These are regenerated after detection so the auto-detected one is always first.
ALL_PROFILES: list[VRAMProfile] = []


def _ensure_profiles():
    """Populate ALL_PROFILES if not yet done."""
    if ALL_PROFILES:
        return
    detected = detect_vram_profile()
    ALL_PROFILES.append(detected)
    # Add the three canonical tiers if they don't duplicate the detected one
    for vram in (32, 24, 16, 12, 8):
        label = f"Generic {vram} GB"
        if abs(detected.total_vram_gb - vram) < 2.0:
            continue  # skip if the detected GPU is already this tier
        ALL_PROFILES.append(_build_profile(label, float(vram)))


def get_profile_by_name(name: str) -> VRAMProfile:
    """Get a VRAM profile by its display name."""
    _ensure_profiles()
    for p in ALL_PROFILES:
        if p.name == name:
            return p
    # Fallback — auto-detect
    return detect_vram_profile()


# ============================================================================
# Resolution / Frame Limit Calculator
# ============================================================================

# Resolution presets with pixel counts for budget calculation.
# Format: (label, width, height)
RESOLUTION_PRESETS = [
    ("1920x1088 (1080p)", 1920, 1088),
    ("1536x1024", 1536, 1024),
    ("1280x704 (720p)", 1280, 704),
    ("1024x1536 (Portrait)", 1024, 1536),
    ("1088x1920 (Portrait 1080p)", 1088, 1920),
    ("768x512 (SD)", 768, 512),
    ("512x768 (Portrait SD)", 512, 768),
]


def max_frames_for_resolution(
    width: int, height: int, profile: VRAMProfile,
) -> int:
    """Estimate the maximum safe frame count for a given resolution and VRAM tier.

    The latent memory scales roughly as: (width/32) * (height/32) * (frames/8) * channels * bytes.
    We use the 1080p/720p limits from the profile and interpolate for other resolutions.
    """
    pixels_1080p = 1920 * 1088
    pixels_720p = 1280 * 704
    pixels = width * height

    if pixels >= pixels_1080p:
        # Scale down from 1080p limit
        scale = pixels_1080p / pixels
        return max(9, int(profile.max_frames_1080p * scale) // 8 * 8 + 1)
    elif pixels <= pixels_720p:
        # Scale up from 720p limit
        scale = pixels_720p / pixels
        return min(257, int(profile.max_frames_720p * scale) // 8 * 8 + 1)
    else:
        # Interpolate between 720p and 1080p
        t = (pixels - pixels_720p) / (pixels_1080p - pixels_720p)
        frames = profile.max_frames_720p + t * (profile.max_frames_1080p - profile.max_frames_720p)
        return max(9, int(frames) // 8 * 8 + 1)


# ============================================================================
# Prompt Embedding Cache
# ============================================================================

import hashlib
import os

PROMPT_CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "prompt_cache")


def get_prompt_cache_path(prompt: str, enhance: bool) -> str:
    """Get the cache file path for a prompt embedding."""
    os.makedirs(PROMPT_CACHE_DIR, exist_ok=True)
    key = f"prompt:{prompt}|enhance:{enhance}"
    filename = hashlib.md5(key.encode("utf-8")).hexdigest() + ".pt"
    return os.path.join(PROMPT_CACHE_DIR, filename)


def load_cached_prompt(cache_path: str, device: torch.device):
    """Load cached prompt embeddings if available."""
    if os.path.exists(cache_path):
        try:
            return torch.load(cache_path, map_location=device, weights_only=False)
        except Exception as e:
            logger.warning(f"Failed to load prompt cache: {e}")
    return None


def save_prompt_cache(cache_path: str, embeddings):
    """Save prompt embeddings to cache."""
    try:
        os.makedirs(os.path.dirname(cache_path), exist_ok=True)
        torch.save(embeddings, cache_path)
    except Exception as e:
        logger.warning(f"Failed to save prompt cache: {e}")


# ============================================================================
# GPU Memory Info
# ============================================================================

def get_gpu_info_str() -> str:
    """Get formatted GPU information string."""
    if not torch.cuda.is_available():
        return "No CUDA GPU available"
    gpu_name = torch.cuda.get_device_name(0)
    props = torch.cuda.get_device_properties(0)
    total = (getattr(props, "total_memory", 0) or getattr(props, "total_mem", 0)) / (1024 ** 3)
    allocated = torch.cuda.memory_allocated(0) / (1024 ** 3)
    reserved = torch.cuda.memory_reserved(0) / (1024 ** 3)
    return (
        f"GPU: {gpu_name}\n"
        f"Total VRAM: {total:.1f} GB\n"
        f"Allocated: {allocated:.1f} GB\n"
        f"Reserved: {reserved:.1f} GB\n"
        f"Free: {total - reserved:.1f} GB"
    )
