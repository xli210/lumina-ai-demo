"""
Streaming DiT for LTX-2 — VRAM-efficient inference via CUDA stream block streaming.

Applies the BloomPrecision / FLUX Klein streaming pattern to the LTX-2 19B transformer.

Standard mode:  accelerate dispatch_model → peak VRAM = full transformer (~12 GB FP8)
Streaming mode: 2-block GPU pool + CUDA stream ping-pong → peak VRAM ~3-5 GB

The LTX-2 transformer (LTXModel) has 48 BasicAVTransformerBlock layers.
Small components (patchify, adaln, caption proj, output layers) stay on GPU (~1-2 GB).
All 48 blocks live in CPU pinned memory and are streamed through GPU two at a time.

Usage (standalone):
    python streaming_dit.py                      # quick self-test

Usage (integration):
    from streaming_dit import StreamingLTX2Transformer, clear_memory

    wrapper = StreamingLTX2Transformer(model.velocity_model, device, dtype)
    wrapper.prepare_streaming()
    # model is now in streaming mode — forward calls will auto-stream
"""

from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import gc
import logging
import time
from typing import Any

import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Memory utilities
# ---------------------------------------------------------------------------

def get_cuda_memory_info(device: torch.device) -> dict[str, float]:
    if torch.cuda.is_available():
        allocated = torch.cuda.memory_allocated(device) / (1024**3)
        reserved = torch.cuda.memory_reserved(device) / (1024**3)
        peak = torch.cuda.max_memory_allocated(device) / (1024**3)
        total = torch.cuda.get_device_properties(device).total_memory / (1024**3)
        return {
            "allocated_gb": round(allocated, 3),
            "reserved_gb": round(reserved, 3),
            "peak_gb": round(peak, 3),
            "total_gb": round(total, 1),
            "free_gb": round(total - reserved, 3),
        }
    return {"allocated_gb": 0, "reserved_gb": 0, "peak_gb": 0, "total_gb": 0, "free_gb": 0}


def log_cuda_memory(label: str, device: torch.device):
    info = get_cuda_memory_info(device)
    logger.info(
        "[%s] VRAM: %.2f GB alloc, %.2f GB peak, %.2f GB free / %.1f GB total",
        label, info["allocated_gb"], info["peak_gb"], info["free_gb"], info["total_gb"],
    )


def clear_memory(device: torch.device):
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()
        if hasattr(torch._C, "_cuda_clearCublasWorkspaces"):
            torch._C._cuda_clearCublasWorkspaces()


def reset_peak_memory(device: torch.device):
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats(device)


# ---------------------------------------------------------------------------
# Streaming DiT for LTX-2
# ---------------------------------------------------------------------------

class StreamingLTX2Transformer:
    """
    Streaming wrapper for LTXModel (the 48-block transformer inside LTX-2).

    Following the BloomPrecision / FLUX Klein CUDAStreamingNaDiT pattern:
      - Small components (embeddings, projections, norms, output layers) stay on GPU
      - All 48 BasicAVTransformerBlock blocks are held in CPU pinned memory
      - During forward, blocks are streamed through GPU using CUDA streams:
          * A copy_stream pre-loads the next block from CPU -> GPU (async DMA)
          * The default stream computes the current block
          * wait_stream() synchronizes before compute starts
      - After processing, each block is moved back to CPU

    VRAM usage: ~1-2 GB (small components) + 2 x block_size (~0.5 GB) ≈ 2-3 GB
    vs ~12 GB for full transformer on GPU (FP8).
    """

    def __init__(self, transformer: nn.Module, device: torch.device, dtype: torch.dtype):
        self.device = device
        self.dtype = dtype
        self.transformer = transformer
        self.copy_stream = torch.cuda.Stream(device=device)
        self._step_block_times: list[float] = []
        self._total_steps = 0
        self._original_process_fn = None

    def prepare_streaming(self):
        """
        Move transformer blocks to CPU pinned memory, keep small components on GPU.

        GPU-resident (small, ~1-2 GB total):
          - patchify_proj, adaln_single, caption_projection
          - scale_shift_table, norm_out, proj_out
          - audio equivalents of the above
          - av_ca_*_adaln_single components
          - video_args_preprocessor, audio_args_preprocessor (reference wrappers)

        CPU pinned memory (large, ~10+ GB):
          - 48 BasicAVTransformerBlock instances
        """
        model = self.transformer
        logger.info("Preparing streaming: moving small components to GPU...")

        small_components = [
            "patchify_proj", "adaln_single", "caption_projection",
            "scale_shift_table", "norm_out", "proj_out",
            "audio_patchify_proj", "audio_adaln_single", "audio_caption_projection",
            "audio_scale_shift_table", "audio_norm_out", "audio_proj_out",
            "av_ca_video_scale_shift_adaln_single", "av_ca_audio_scale_shift_adaln_single",
            "av_ca_a2v_gate_adaln_single", "av_ca_v2a_gate_adaln_single",
        ]
        for name in small_components:
            component = getattr(model, name, None)
            if component is None:
                continue
            if isinstance(component, nn.Module):
                component.to(device=self.device, dtype=self.dtype)
            elif isinstance(component, nn.Parameter):
                component.data = component.data.to(device=self.device, dtype=self.dtype)

        num_blocks = len(model.transformer_blocks)
        logger.info("Moving %d transformer blocks to CPU pinned memory...", num_blocks)
        for block in model.transformer_blocks:
            self._move_to_pinned_cpu(block)

        self._original_process_fn = model._process_transformer_blocks
        model._process_transformer_blocks = self._streaming_process_transformer_blocks

        logger.info("Streaming ready: %d blocks on CPU pinned, small components on GPU", num_blocks)
        clear_memory(self.device)
        log_cuda_memory("After streaming setup", self.device)

    def restore(self):
        """Undo the streaming monkey-patch."""
        if self._original_process_fn is not None:
            self.transformer._process_transformer_blocks = self._original_process_fn
            self._original_process_fn = None

    @staticmethod
    def _move_to_pinned_cpu(module: nn.Module):
        module.to("cpu")
        for param in module.parameters():
            if not param.data.is_pinned():
                param.data = param.data.pin_memory()
        for buf in module.buffers():
            if not buf.is_pinned():
                buf.data = buf.data.pin_memory()

    def _prefetch_block(self, block: nn.Module):
        with torch.cuda.stream(self.copy_stream):
            block.to(device=self.device, dtype=self.dtype, non_blocking=True)

    def _offload_block(self, block: nn.Module):
        block.to("cpu")
        for param in block.parameters():
            if not param.data.is_pinned():
                param.data = param.data.pin_memory()
        for buf in block.buffers():
            if not buf.is_pinned():
                buf.data = buf.data.pin_memory()

    def _stream_blocks(self, blocks: nn.ModuleList, forward_fn):
        """
        Stream blocks through GPU with CUDA stream overlap (ping-pong pattern):
          1. Pre-load block[0] to GPU
          2. For each block[i]:
             a. Start async loading block[i+1] on copy_stream
             b. Compute block[i] on default stream (waits for copy)
             c. Offload block[i] back to CPU
          3. After all blocks: sync
        """
        num_blocks = len(blocks)
        if num_blocks == 0:
            return

        self._prefetch_block(blocks[0])
        self.copy_stream.synchronize()

        for i in range(num_blocks):
            if i + 1 < num_blocks:
                self._prefetch_block(blocks[i + 1])

            torch.cuda.current_stream(self.device).wait_stream(self.copy_stream)

            t0 = time.perf_counter()
            forward_fn(blocks[i], i)
            torch.cuda.synchronize(self.device)
            self._step_block_times.append(time.perf_counter() - t0)

            self._offload_block(blocks[i])

            if i + 1 < num_blocks:
                self.copy_stream.synchronize()

    def _streaming_process_transformer_blocks(self, video, audio, perturbations):
        """
        Drop-in replacement for LTXModel._process_transformer_blocks that
        streams blocks through GPU instead of assuming they are all resident.
        """
        self._step_block_times.clear()
        self._total_steps += 1

        video_container = [video]
        audio_container = [audio]

        def block_fn(block, idx):
            v, a = block(
                video=video_container[0],
                audio=audio_container[0],
                perturbations=perturbations,
            )
            video_container[0] = v
            audio_container[0] = a

        self._stream_blocks(self.transformer.transformer_blocks, block_fn)

        if self._step_block_times:
            n = len(self._step_block_times)
            avg_ms = sum(self._step_block_times) / n * 1000
            total_s = sum(self._step_block_times)
            logger.info(
                "[Step %d] DiT streaming: %d blocks, avg %.1f ms/block, total %.2f s",
                self._total_steps, n, avg_ms, total_s,
            )

        return video_container[0], audio_container[0]

    def cleanup(self):
        self.restore()
        del self.copy_stream
        clear_memory(self.device)


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)-8s %(message)s")
    if not torch.cuda.is_available():
        logger.error("CUDA is not available. Streaming DiT requires an NVIDIA GPU.")
        raise SystemExit(1)

    device = torch.device("cuda")
    logger.info("GPU: %s", torch.cuda.get_device_name(device))
    log_cuda_memory("Before test", device)
    logger.info("streaming_dit.py self-test passed (no model loaded — import-only check).")
