"""
Video preprocessors for IC-LoRA control signal extraction.

Provides automatic extraction of:
  - Canny edges (white edges on black background)
  - Depth maps (grayscale, closer = lighter)
  - Pose skeletons (colored skeleton on black background)

Users can upload a regular video, and these preprocessors convert it
into the control signal format that IC-LoRA models expect.
"""

import gc
import logging
import os
import tempfile
import time
from pathlib import Path

import cv2
import numpy as np
import torch

logger = logging.getLogger(__name__)


def _validate_video_readable(video_path: str) -> None:
    """Verify a video file exists and is readable before processing."""
    if not video_path:
        raise ValueError("No video path provided.")
    p = Path(video_path)
    if not p.exists():
        raise FileNotFoundError(f"Video file not found: {video_path}")
    if p.stat().st_size == 0:
        raise ValueError(f"Video file is empty: {video_path}")
    if p.suffix.lower() not in (".mp4", ".avi", ".mov", ".mkv", ".webm", ".flv", ".wmv"):
        logger.warning(f"Uncommon video extension: {p.suffix}. Proceeding anyway.")

# ============================================================================
# Canny Edge Extraction
# ============================================================================

def extract_canny_video(
    input_video_path: str,
    low_thresh: int = 100,
    high_thresh: int = 200,
    progress_callback=None,
) -> str:
    """Extract Canny edges from a video.

    Returns path to a new MP4 with white edges on black background.
    This is the simplest preprocessor — purely CPU-based, no model needed.
    """
    import av

    _validate_video_readable(input_video_path)
    output_path = os.path.join(tempfile.gettempdir(), f"canny_{int(time.time())}.mp4")

    try:
        container = av.open(input_video_path)
        stream = container.streams.video[0]
        fps = float(stream.average_rate or 24)

        frames = []
        for frame in container.decode(video=0):
            img = frame.to_ndarray(format="bgr24")
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            blurred = cv2.GaussianBlur(gray, (5, 5), 0)
            edges = cv2.Canny(blurred, low_thresh, high_thresh)
            edges_bgr = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)
            frames.append(edges_bgr)
        container.close()
    except Exception as e:
        raise RuntimeError(f"Failed to read video for Canny extraction: {e}") from e

    if not frames:
        raise ValueError("No frames found in input video. Is it a valid video file?")

    _write_video_av(frames, output_path, fps)

    if progress_callback:
        progress_callback(1.0)

    logger.info(f"Canny extraction complete: {len(frames)} frames -> {output_path}")
    return output_path


# ============================================================================
# Depth Map Estimation  (Depth-Anything-V2-Small via transformers)
# ============================================================================

_depth_pipe = None  # lazy-loaded singleton


def _get_depth_pipeline():
    """Load the Depth-Anything-V2-Small model (downloads ~100 MB on first use)."""
    global _depth_pipe
    if _depth_pipe is not None:
        return _depth_pipe

    from transformers import pipeline as hf_pipeline

    logger.info("Loading Depth-Anything-V2-Small model (first time may download ~100 MB)...")
    _depth_pipe = hf_pipeline(
        task="depth-estimation",
        model="depth-anything/Depth-Anything-V2-Small-hf",
        device=0 if torch.cuda.is_available() else -1,
    )
    logger.info("Depth model loaded.")
    return _depth_pipe


def unload_depth_model():
    """Free depth model from GPU memory."""
    global _depth_pipe
    if _depth_pipe is not None:
        del _depth_pipe
        _depth_pipe = None
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()


def extract_depth_video(
    input_video_path: str,
    progress_callback=None,
) -> str:
    """Estimate depth maps for each frame of a video.

    Returns path to a new MP4 with grayscale depth maps
    (closer = lighter / white, farther = darker / black).
    Uses Depth-Anything-V2-Small for fast, high-quality depth estimation.
    """
    import av
    from PIL import Image

    _validate_video_readable(input_video_path)
    output_path = os.path.join(tempfile.gettempdir(), f"depth_{int(time.time())}.mp4")

    pipe = _get_depth_pipeline()

    # Decode all frames
    try:
        container = av.open(input_video_path)
        stream = container.streams.video[0]
        fps = float(stream.average_rate or 24)

        raw_frames = []
        for frame in container.decode(video=0):
            img = frame.to_ndarray(format="rgb24")
            raw_frames.append(img)
        container.close()
    except Exception as e:
        raise RuntimeError(f"Failed to read video for depth extraction: {e}") from e

    if not raw_frames:
        raise ValueError("No frames found in input video. Is it a valid video file?")

    total = len(raw_frames)
    depth_frames = []

    for i, rgb in enumerate(raw_frames):
        pil_img = Image.fromarray(rgb)
        result = pipe(pil_img)
        depth_pil = result["depth"]  # PIL Image, mode "L" (grayscale)

        # Ensure same size as input
        h, w = rgb.shape[:2]
        depth_pil = depth_pil.resize((w, h), Image.BILINEAR)

        # Convert to 3-channel BGR for video writing
        depth_np = np.array(depth_pil)
        # Invert so closer = lighter (depth models usually output closer = smaller value)
        # Actually, Depth-Anything outputs closer = lighter already in the PIL image
        depth_bgr = cv2.cvtColor(depth_np, cv2.COLOR_GRAY2BGR)
        depth_frames.append(depth_bgr)

        if progress_callback and (i + 1) % max(1, total // 20) == 0:
            progress_callback((i + 1) / total)

    _write_video_av(depth_frames, output_path, fps)

    # Free GPU memory — depth model not needed during generation
    unload_depth_model()

    if progress_callback:
        progress_callback(1.0)

    logger.info(f"Depth extraction complete: {total} frames -> {output_path}")
    return output_path


# ============================================================================
# Pose Skeleton Extraction  (MediaPipe Pose)
# ============================================================================

# MediaPipe body pose connections for drawing the skeleton
# These match the standard 33-landmark body model
_POSE_CONNECTIONS = [
    # Torso
    (11, 12), (11, 23), (12, 24), (23, 24),
    # Right arm
    (12, 14), (14, 16),
    # Left arm
    (11, 13), (13, 15),
    # Right leg
    (24, 26), (26, 28),
    # Left leg
    (23, 25), (25, 27),
    # Face (simplified)
    (0, 1), (1, 2), (2, 3), (3, 7),
    (0, 4), (4, 5), (5, 6), (6, 8),
    (9, 10),
    # Shoulders to ears
    (11, 0), (12, 0),
    # Hands
    (16, 18), (16, 20), (16, 22),
    (15, 17), (15, 19), (15, 21),
    # Feet
    (28, 30), (28, 32),
    (27, 29), (27, 31),
]

# Colors for different body parts (BGR)
_LIMB_COLORS = {
    "torso": (0, 255, 255),      # Yellow
    "right_arm": (0, 128, 255),  # Orange
    "left_arm": (255, 128, 0),   # Blue
    "right_leg": (0, 255, 0),    # Green
    "left_leg": (255, 0, 128),   # Purple
    "face": (255, 255, 255),     # White
    "default": (200, 200, 200),  # Light gray
}


def _get_limb_color(i1, i2):
    """Return a BGR color for a limb connection based on landmark indices."""
    if i1 in (11, 12, 23, 24) and i2 in (11, 12, 23, 24):
        return _LIMB_COLORS["torso"]
    if i1 in (12, 14, 16, 18, 20, 22) or i2 in (12, 14, 16, 18, 20, 22):
        if i1 not in (11, 23, 24) and i2 not in (11, 23, 24):
            return _LIMB_COLORS["right_arm"]
    if i1 in (11, 13, 15, 17, 19, 21) or i2 in (11, 13, 15, 17, 19, 21):
        if i1 not in (12, 23, 24) and i2 not in (12, 23, 24):
            return _LIMB_COLORS["left_arm"]
    if i1 in (24, 26, 28, 30, 32) or i2 in (24, 26, 28, 30, 32):
        return _LIMB_COLORS["right_leg"]
    if i1 in (23, 25, 27, 29, 31) or i2 in (23, 25, 27, 29, 31):
        return _LIMB_COLORS["left_leg"]
    if max(i1, i2) <= 10:
        return _LIMB_COLORS["face"]
    return _LIMB_COLORS["default"]


_POSE_MODEL_URL = "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_heavy/float16/1/pose_landmarker_heavy.task"
_POSE_MODEL_PATH = None  # set lazily


def _get_pose_model_path() -> str:
    """Download the MediaPipe pose model if needed and return the local path."""
    global _POSE_MODEL_PATH
    if _POSE_MODEL_PATH is not None and Path(_POSE_MODEL_PATH).exists():
        return _POSE_MODEL_PATH

    cache_dir = Path(__file__).parent / "models" / ".cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    model_path = cache_dir / "pose_landmarker_heavy.task"

    if not model_path.exists():
        logger.info("Downloading MediaPipe Pose model (~30 MB, first time only)...")
        import urllib.request
        urllib.request.urlretrieve(_POSE_MODEL_URL, str(model_path))
        logger.info(f"Pose model saved to {model_path}")

    _POSE_MODEL_PATH = str(model_path)
    return _POSE_MODEL_PATH


def extract_pose_video(
    input_video_path: str,
    progress_callback=None,
) -> str:
    """Extract pose skeletons from each frame of a video using MediaPipe.

    Returns path to a new MP4 with colored skeleton overlays on a black background.
    This format is compatible with the LTX-2 Pose Control IC-LoRA.
    Uses MediaPipe Tasks API (0.10+).
    """
    import av
    import mediapipe as mp
    from mediapipe.tasks.python import vision as mp_vision
    from mediapipe.tasks.python.core.base_options import BaseOptions

    _validate_video_readable(input_video_path)
    output_path = os.path.join(tempfile.gettempdir(), f"pose_{int(time.time())}.mp4")

    # Ensure pose model is downloaded
    model_path = _get_pose_model_path()

    # Decode all frames
    try:
        container = av.open(input_video_path)
        stream = container.streams.video[0]
        fps = float(stream.average_rate or 24)

        raw_frames = []
        for frame in container.decode(video=0):
            img = frame.to_ndarray(format="rgb24")
            raw_frames.append(img)
        container.close()
    except Exception as e:
        raise RuntimeError(f"Failed to read video for pose extraction: {e}") from e

    if not raw_frames:
        raise ValueError("No frames found in input video. Is it a valid video file?")

    total = len(raw_frames)
    pose_frames = []

    # Create PoseLandmarker using the Tasks API
    options = mp_vision.PoseLandmarkerOptions(
        base_options=BaseOptions(model_asset_path=model_path),
        num_poses=4,
        min_pose_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    )
    detector = mp_vision.PoseLandmarker.create_from_options(options)

    for i, rgb in enumerate(raw_frames):
        h, w = rgb.shape[:2]
        canvas = np.zeros((h, w, 3), dtype=np.uint8)  # Black background

        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
        result = detector.detect(mp_image)

        if result.pose_landmarks:
            for person_landmarks in result.pose_landmarks:
                # Draw connections (limbs)
                for i1, i2 in _POSE_CONNECTIONS:
                    if i1 < len(person_landmarks) and i2 < len(person_landmarks):
                        lm1, lm2 = person_landmarks[i1], person_landmarks[i2]
                        if lm1.visibility > 0.3 and lm2.visibility > 0.3:
                            x1, y1 = int(lm1.x * w), int(lm1.y * h)
                            x2, y2 = int(lm2.x * w), int(lm2.y * h)
                            color = _get_limb_color(i1, i2)
                            cv2.line(canvas, (x1, y1), (x2, y2), color, 3)

                # Draw keypoints
                for lm in person_landmarks:
                    if lm.visibility > 0.3:
                        x, y = int(lm.x * w), int(lm.y * h)
                        cv2.circle(canvas, (x, y), 4, (255, 255, 255), -1)

        pose_frames.append(canvas)

        if progress_callback and (i + 1) % max(1, total // 20) == 0:
            progress_callback((i + 1) / total)

    detector.close()
    _write_video_av(pose_frames, output_path, fps)

    if progress_callback:
        progress_callback(1.0)

    logger.info(f"Pose extraction complete: {total} frames -> {output_path}")
    return output_path


# ============================================================================
# Helper: Write video using PyAV
# ============================================================================

def _write_video_av(frames_bgr: list[np.ndarray], output_path: str, fps: float):
    """Write a list of BGR numpy frames to an MP4 file using PyAV."""
    import av

    if not frames_bgr:
        raise ValueError("No frames to write.")

    h, w = frames_bgr[0].shape[:2]
    # Ensure dimensions are even (required by H.264 yuv420p)
    w = w if w % 2 == 0 else w - 1
    h = h if h % 2 == 0 else h - 1

    container = av.open(output_path, mode="w")
    stream = container.add_stream("h264", rate=int(fps))
    stream.width = w
    stream.height = h
    stream.pix_fmt = "yuv420p"

    for frame_bgr in frames_bgr:
        # Resize if dimensions don't match (safety)
        fh, fw = frame_bgr.shape[:2]
        if fh != h or fw != w:
            frame_bgr = cv2.resize(frame_bgr, (w, h))
        frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        av_frame = av.VideoFrame.from_ndarray(frame_rgb, format="rgb24")
        for packet in stream.encode(av_frame):
            container.mux(packet)

    for packet in stream.encode():
        container.mux(packet)
    container.close()
    logger.info(f"Wrote {len(frames_bgr)} frames ({w}x{h} @ {fps:.0f}fps) -> {output_path}")


# ============================================================================
# Main dispatcher: preprocess video based on control type
# ============================================================================

def preprocess_for_control(
    video_path: str,
    control_type: str,
    progress_callback=None,
) -> str:
    """Automatically preprocess a video for the given IC-LoRA control type.

    Args:
        video_path: Path to the user's raw video.
        control_type: One of "Canny Control", "Depth Control", "Pose Control", "Detailer".
        progress_callback: Optional function(float) to report progress [0..1].

    Returns:
        Path to the preprocessed control-signal video.
        For "Detailer", returns the original video unchanged.

    Raises:
        RuntimeError: If preprocessing fails with a user-readable message.
    """
    start = time.time()
    logger.info(f"Preprocessing video for {control_type}: {video_path}")

    try:
        if control_type == "Canny Control":
            result = extract_canny_video(video_path, progress_callback=progress_callback)
        elif control_type == "Depth Control":
            result = extract_depth_video(video_path, progress_callback=progress_callback)
        elif control_type == "Pose Control":
            result = extract_pose_video(video_path, progress_callback=progress_callback)
        elif control_type == "Detailer":
            return video_path  # Detailer uses the raw video directly
        else:
            logger.warning(f"Unknown control type '{control_type}', returning raw video.")
            return video_path
    except (FileNotFoundError, ValueError) as e:
        raise  # Already user-friendly
    except torch.cuda.OutOfMemoryError:
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        raise RuntimeError(
            f"Ran out of GPU memory during {control_type} preprocessing. "
            f"Try a shorter or lower-resolution video."
        )
    except Exception as e:
        raise RuntimeError(
            f"Failed to preprocess video for {control_type}: {e}\n"
            f"Check the Logs tab for details."
        ) from e

    elapsed = time.time() - start
    logger.info(f"Preprocessing complete in {elapsed:.1f}s: {result}")
    return result
