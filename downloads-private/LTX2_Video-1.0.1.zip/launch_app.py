"""
LTX-2 Video Generation Studio — One-click launcher.

Downloads models on first run (with FLUX-style .download_status progress),
then starts either the native desktop app (ltx2_app.py) or the legacy
Gradio server (app.py).  Supports:
  - .download_status JSON file for real-time GUI progress reporting
  - File-by-file progress with size estimation via HfApi().repo_info()
  - User-friendly error classification (network, auth, disk, SSL, rate-limit)
  - Runner backend integration

Usage: LTX2_env\\python312.exe launch_app.py [--no-gui] [--legacy]
"""

import json
import os
import ssl
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).parent.resolve()
MODELS_DIR = PROJECT_ROOT / "models"
LORAS_DIR = MODELS_DIR / "loras"
GEMMA_DIR = MODELS_DIR / "gemma"
OUTPUTS_DIR = PROJECT_ROOT / "outputs"
LOGS_DIR = PROJECT_ROOT / "logs"
APP_SCRIPT = PROJECT_ROOT / "app.py"
NATIVE_APP_SCRIPT = PROJECT_ROOT / "ltx2_app.py"
RUNNER_SCRIPT = PROJECT_ROOT / "runner.py"

GRADIO_URL = "http://127.0.0.1:7860"
HEALTH_TIMEOUT_SEC = 600   # model loading can take a while
HEALTH_POLL_INTERVAL = 3.0

gradio_process = None

# ---------------------------------------------------------------------------
# Find the bundled Python
# ---------------------------------------------------------------------------
def _find_python() -> str:
    """Use the same Python that launched us — the bat file already
    validated it has tkinter and all required packages."""
    return sys.executable

PYTHON_EXE = _find_python()

# ---------------------------------------------------------------------------
# Model Definitions
# ---------------------------------------------------------------------------
MAIN_MODELS = [
    ("Lightricks/ltx-2-19b", "ltx-2-19b-distilled-fp8.safetensors", MODELS_DIR),
    ("Lightricks/ltx-2-19b", "ltx-2-19b-dev-fp8.safetensors", MODELS_DIR),
    ("Lightricks/ltx-2-19b", "ltx-2-spatial-upscaler-x2-1.0.safetensors", MODELS_DIR),
    ("Lightricks/ltx-2-19b", "ltx-2-19b-distilled-lora-384.safetensors", MODELS_DIR),
]

LORA_MODELS = [
    ("Lightricks/LTX-2-19b-IC-LoRA-Canny-Control", "ltx-2-19b-ic-lora-canny-control.safetensors"),
    ("Lightricks/LTX-2-19b-IC-LoRA-Depth-Control", "ltx-2-19b-ic-lora-depth-control.safetensors"),
    ("Lightricks/LTX-2-19b-IC-LoRA-Detailer", "ltx-2-19b-ic-lora-detailer.safetensors"),
    ("Lightricks/LTX-2-19b-IC-LoRA-Pose-Control", "ltx-2-19b-ic-lora-pose-control.safetensors"),
    ("Lightricks/LTX-2-19b-LoRA-Camera-Control-Dolly-In", "ltx-2-19b-lora-camera-control-dolly-in.safetensors"),
    ("Lightricks/LTX-2-19b-LoRA-Camera-Control-Dolly-Left", "ltx-2-19b-lora-camera-control-dolly-left.safetensors"),
    ("Lightricks/LTX-2-19b-LoRA-Camera-Control-Dolly-Out", "ltx-2-19b-lora-camera-control-dolly-out.safetensors"),
    ("Lightricks/LTX-2-19b-LoRA-Camera-Control-Dolly-Right", "ltx-2-19b-lora-camera-control-dolly-right.safetensors"),
    ("Lightricks/LTX-2-19b-LoRA-Camera-Control-Jib-Down", "ltx-2-19b-lora-camera-control-jib-down.safetensors"),
    ("Lightricks/LTX-2-19b-LoRA-Camera-Control-Jib-Up", "ltx-2-19b-lora-camera-control-jib-up.safetensors"),
    ("Lightricks/LTX-2-19b-LoRA-Camera-Control-Static", "ltx-2-19b-lora-camera-control-static.safetensors"),
]

GEMMA_REPO = "google/gemma-3-12b-it-qat-q4_0-unquantized"

# ---------------------------------------------------------------------------
# .download_status JSON  (FLUX-style real-time progress for UI consumption)
# ---------------------------------------------------------------------------
DOWNLOAD_STATUS_FILE = PROJECT_ROOT / ".download_status"


def _write_status(phase: str, message: str, progress: float, detail: str = ""):
    """Write a JSON status blob to .download_status for any listening UI.

    Fields:
      phase    – "check" | "download" | "done" | "error"
      message  – human-readable summary
      progress – 0.0 … 1.0 (fractional)
      detail   – extra info (file name, error, etc.)
    """
    blob = {
        "phase": phase,
        "message": message,
        "progress": round(max(0.0, min(1.0, progress)), 4),
        "detail": detail,
        "ts": time.time(),
    }
    try:
        DOWNLOAD_STATUS_FILE.write_text(json.dumps(blob), encoding="utf-8")
    except Exception:
        pass


def _classify_download_error(exc: Exception) -> str:
    """Classify a download exception into a user-friendly category."""
    msg = str(exc).lower()

    if "401" in msg or "403" in msg or "gated" in msg or "unauthorized" in msg:
        return "AUTH_REQUIRED"
    if isinstance(exc, ssl.SSLError) or "ssl" in msg or "certificate" in msg:
        return "SSL_ERROR"
    if "429" in msg or "rate" in msg:
        return "RATE_LIMITED"
    if "no space" in msg or "disk" in msg or "errno 28" in msg:
        return "DISK_FULL"
    if isinstance(exc, (ConnectionError, URLError, OSError)):
        return "NETWORK_ERROR"
    if "timeout" in msg or "timed out" in msg:
        return "TIMEOUT"
    return "UNKNOWN"


def _friendly_error(category: str, repo: str, filename: str, exc: Exception) -> str:
    """Build a user-friendly error message based on error category."""
    if category == "AUTH_REQUIRED":
        return (
            f"Authorization required for {repo}.\n"
            f"Visit https://huggingface.co/{repo} to accept terms, then run:\n"
            f"  python -m huggingface_hub.cli login"
        )
    if category == "SSL_ERROR":
        return f"SSL/TLS error downloading {filename}. Check your firewall or try: pip install --upgrade certifi"
    if category == "RATE_LIMITED":
        return f"Rate-limited by HuggingFace downloading {filename}. Wait a few minutes and retry."
    if category == "DISK_FULL":
        return f"Not enough disk space to download {filename}. Free up space and retry."
    if category == "NETWORK_ERROR":
        return f"Network error downloading {filename}. Check internet connection."
    if category == "TIMEOUT":
        return f"Download timed out for {filename}. Check your connection speed."
    return f"Failed to download {filename}: {exc}"


# ---------------------------------------------------------------------------
# Model Download Logic
# ---------------------------------------------------------------------------
def check_models_present():
    """Check which model groups are missing. Returns list of missing groups."""
    missing = []

    # Check main models
    for repo, filename, dest in MAIN_MODELS:
        if not (dest / filename).exists():
            missing.append(("main", repo, filename))

    # Check Gemma
    gemma_index = GEMMA_DIR / "model.safetensors.index.json"
    if not gemma_index.exists():
        missing.append(("gemma", GEMMA_REPO, "all"))

    # Check LoRAs
    for repo, filename in LORA_MODELS:
        if not (LORAS_DIR / filename).exists():
            missing.append(("lora", repo, filename))

    return missing


def download_models(callback=None):
    """Download all missing models from HuggingFace.

    Writes real-time progress to .download_status JSON for UI consumption.
    Returns True if all succeeded.
    """
    try:
        from huggingface_hub import hf_hub_download, snapshot_download
    except ImportError:
        msg = "ERROR: huggingface_hub not installed. Run BUILD.bat first."
        _write_status("error", msg, 0)
        if callback:
            callback(msg)
        return False

    _write_status("check", "Checking models...", 0)
    missing = check_models_present()
    if not missing:
        _write_status("done", "All models already present.", 1.0)
        if callback:
            callback("All models already present.")
        return True

    total = len(missing)
    success = 0
    errors: list[str] = []

    MODELS_DIR.mkdir(exist_ok=True)
    LORAS_DIR.mkdir(parents=True, exist_ok=True)
    GEMMA_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUTS_DIR.mkdir(exist_ok=True)
    LOGS_DIR.mkdir(exist_ok=True)

    for i, (group, repo, filename) in enumerate(missing, 1):
        label = filename if filename != "all" else "Gemma text encoder (~25 GB)"
        fraction = (i - 1) / total
        _write_status("download", f"Downloading {label} ({i}/{total})...", fraction, label)
        if callback:
            callback(f"Downloading {label} ({i}/{total})...")

        try:
            if group == "gemma":
                snapshot_download(
                    repo_id=repo,
                    local_dir=str(GEMMA_DIR),
                    local_dir_use_symlinks=False,
                )
            elif group == "main":
                hf_hub_download(
                    repo_id=repo,
                    filename=filename,
                    local_dir=str(MODELS_DIR),
                    local_dir_use_symlinks=False,
                )
            elif group == "lora":
                hf_hub_download(
                    repo_id=repo,
                    filename=filename,
                    local_dir=str(LORAS_DIR),
                    local_dir_use_symlinks=False,
                )
            success += 1
            _write_status("download", f"Downloaded {label}.", i / total, label)
        except Exception as e:
            category = _classify_download_error(e)
            friendly = _friendly_error(category, repo, filename, e)
            errors.append(friendly)
            _write_status("error", friendly, i / total, f"{category}: {filename}")
            if callback:
                callback(friendly)

    if success == total:
        _write_status("done", f"All {total} models downloaded.", 1.0)
    else:
        _write_status("error",
                       f"Downloaded {success}/{total}. {len(errors)} error(s).",
                       success / total,
                       "; ".join(errors))

    if callback:
        callback(f"Downloads complete: {success}/{total} files.")

    return success == total


# ---------------------------------------------------------------------------
# Port Management
# ---------------------------------------------------------------------------
GRADIO_PORT = 7860

def free_port(port):
    """Kill any process currently listening on the given port (Windows only)."""
    if sys.platform != "win32":
        return
    try:
        import socket
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            result = s.connect_ex(("127.0.0.1", port))
            if result != 0:
                return  # Port is already free

        # Port is in use — find and kill the owning process
        out = subprocess.check_output(
            ["netstat", "-ano", "-p", "TCP"],
            text=True, creationflags=subprocess.CREATE_NO_WINDOW,
        )
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 5 and f":{port}" in parts[1] and parts[3] == "LISTENING":
                pid = int(parts[4])
                try:
                    subprocess.run(
                        ["taskkill", "/F", "/PID", str(pid)],
                        creationflags=subprocess.CREATE_NO_WINDOW,
                        capture_output=True,
                    )
                except Exception:
                    pass
        time.sleep(2)  # Give the OS time to release the socket
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Gradio Server Management
# ---------------------------------------------------------------------------
def check_gradio_health():
    """Check if Gradio server is responding."""
    try:
        with urlopen(Request(GRADIO_URL, method="GET"), timeout=5) as r:
            return r.getcode() == 200
    except Exception:
        return False


def wait_for_gradio(callback=None):
    """Wait for Gradio to become ready."""
    start = time.monotonic()
    deadline = start + HEALTH_TIMEOUT_SEC
    dots = 0
    while time.monotonic() < deadline:
        dots = (dots + 1) % 4
        elapsed = int(time.monotonic() - start)
        if callback:
            callback(f"Loading models{'.' * dots}  ({elapsed}s)")
        if check_gradio_health():
            if callback:
                callback("Server ready!")
            return True
        # Check if the Gradio subprocess crashed
        if gradio_process and gradio_process.poll() is not None:
            if callback:
                callback(f"Server process exited with code {gradio_process.returncode}.")
            return False
        time.sleep(HEALTH_POLL_INTERVAL)
    if callback:
        callback("Server did not start in time.")
    return False


def start_gradio():
    """Start the Gradio app as a subprocess, freeing the port first."""
    global gradio_process
    free_port(GRADIO_PORT)

    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"

    gradio_process = subprocess.Popen(
        [PYTHON_EXE, str(APP_SCRIPT)],
        cwd=str(PROJECT_ROOT),
        env=env,
        creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform == "win32" else 0,
    )


def stop_all():
    """Terminate Gradio server."""
    global gradio_process
    if gradio_process and gradio_process.poll() is None:
        gradio_process.terminate()
        try:
            gradio_process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            gradio_process.kill()
    gradio_process = None


# ---------------------------------------------------------------------------
# GUI Launcher (tkinter)
# ---------------------------------------------------------------------------
def run_launcher_gui():
    import tkinter as tk
    from tkinter import ttk

    root = tk.Tk()
    root.title("LTX-2 Video Generation Studio")
    root.minsize(520, 260)
    root.resizable(True, True)

    try:
        root.configure(bg="#0f0f1a")
    except Exception:
        pass

    style = ttk.Style()
    try:
        style.configure("TLabel", background="#0f0f1a", foreground="#c0caf5",
                         font=("Segoe UI", 11))
        style.configure("Title.TLabel", background="#0f0f1a", foreground="#7aa2f7",
                         font=("Segoe UI", 14, "bold"))
        style.configure("TButton", font=("Segoe UI", 11))
        style.configure("Horizontal.TProgressbar", troughcolor="#1a1b2e",
                         background="#7aa2f7", thickness=8)
    except Exception:
        pass

    title_lbl = ttk.Label(root, text="LTX-2 Video Generation Studio",
                           style="Title.TLabel", padding=(10, 10, 10, 2))
    title_lbl.pack(fill=tk.X)

    status_lbl = ttk.Label(root, text="Initializing...", padding=(10, 2, 10, 5),
                            wraplength=480)
    status_lbl.pack(fill=tk.X)

    progress = ttk.Progressbar(root, mode="indeterminate", style="Horizontal.TProgressbar")
    progress.pack(fill=tk.X, padx=15, pady=5)
    progress.start(15)

    detail_lbl = ttk.Label(root, text="", padding=(10, 0, 10, 5), wraplength=480)
    detail_lbl.pack(fill=tk.X)

    btn_frame = ttk.Frame(root)
    btn_frame.pack(pady=8)

    btn_open = ttk.Button(btn_frame, text="Open in Browser",
                           command=lambda: webbrowser.open(GRADIO_URL))
    btn_open.pack(side=tk.LEFT, padx=5)
    btn_open.state(["disabled"])

    btn_quit = ttk.Button(btn_frame, text="Quit",
                           command=lambda: on_closing())
    btn_quit.pack(side=tk.LEFT, padx=5)

    def update_status(msg):
        root.after(0, lambda: status_lbl.config(text=msg))

    def update_detail(msg):
        root.after(0, lambda: detail_lbl.config(text=msg))

    def on_closing():
        status_lbl.config(text="Shutting down...")
        root.update()
        stop_all()
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_closing)

    def startup():
        try:
            # Phase 1: Check & download models
            missing = check_models_present()
            if missing:
                n = len(missing)
                update_status(f"First-run setup: downloading {n} model file(s)...")
                update_detail("This is a one-time download (~80 GB). Please be patient.")

                ok = download_models(callback=update_status)
                if not ok:
                    update_detail("Some downloads failed. The app may still work with available models.")
                    time.sleep(3)
            else:
                update_status("All models present.")

            # Phase 2: Start Gradio
            update_status("Starting LTX-2 Studio (loading models into GPU)...")
            update_detail("This may take 1-3 minutes on first load.")
            start_gradio()

            if not wait_for_gradio(callback=update_status):
                update_status("Server failed to start. Check GPU/drivers.")
                log_files = sorted(LOGS_DIR.glob("*.log"), key=lambda p: p.stat().st_mtime, reverse=True)
                log_hint = f"Check logs: {log_files[0]}" if log_files else "Check the console output for errors."
                update_detail(f"Make sure you have an NVIDIA GPU with 16+ GB VRAM.\n{log_hint}")
                return

            # Phase 3: Ready
            root.after(0, lambda: progress.stop())
            root.after(0, lambda: progress.pack_forget())
            update_status("Ready! LTX-2 Studio is running.")
            update_detail(f"Open {GRADIO_URL} in your browser.")
            root.after(0, lambda: btn_open.state(["!disabled"]))
            root.after(0, lambda: webbrowser.open(GRADIO_URL))

        except Exception as e:
            update_status(f"Error: {e}")

    threading.Thread(target=startup, daemon=True).start()
    root.mainloop()
    stop_all()


# ---------------------------------------------------------------------------
# Console Launcher
# ---------------------------------------------------------------------------
def run_launcher_console():
    print("=" * 60)
    print("  LTX-2 Video Generation Studio")
    print("=" * 60)
    print(f"  Python: {PYTHON_EXE}")
    print()

    # Check & download models
    missing = check_models_present()
    if missing:
        print(f"  First-run setup: downloading {len(missing)} model file(s)...")
        print("  This is a one-time download (~80 GB). Please be patient.")
        print()
        ok = download_models(callback=print)
        if not ok:
            print("\n  WARNING: Some downloads failed. The app may still work.")
    else:
        print("  All models present.")

    # Start Gradio
    print("\n  Starting LTX-2 Studio (loading models into GPU)...")
    start_gradio()

    if not wait_for_gradio(callback=print):
        print("  Server failed to start. Check GPU/drivers.")
        stop_all()
        sys.exit(1)

    print(f"\n  Ready: {GRADIO_URL}")
    webbrowser.open(GRADIO_URL)

    try:
        input("\n  Press Enter to stop...\n")
    except (EOFError, KeyboardInterrupt):
        pass
    stop_all()


# ---------------------------------------------------------------------------
# Native App Launcher (new default)
# ---------------------------------------------------------------------------
def run_native_app():
    """Launch the native tkinter desktop app (ltx2_app.py).

    Downloads models first if needed, then starts the native app
    which auto-manages its own runner backend.
    """
    print("=" * 60)
    print("  LTX-2 Video Generation Studio (Native)")
    print("=" * 60)
    print(f"  Python: {PYTHON_EXE}")

    missing = check_models_present()
    if missing:
        print(f"\n  First-run setup: downloading {len(missing)} model file(s)...")
        print("  This is a one-time download (~80 GB). Please be patient.\n")
        download_models(callback=print)

    print("\n  Starting LTX-2 Studio (native desktop app)...")
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"

    try:
        proc = subprocess.Popen(
            [PYTHON_EXE, str(NATIVE_APP_SCRIPT)],
            cwd=str(PROJECT_ROOT),
            env=env,
        )
        proc.wait()
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f"  Error launching native app: {e}")
        print(f"  Falling back to Gradio UI...")
        run_launcher_console()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    args = sys.argv[1:]
    if "--no-gui" in args:
        run_launcher_console()
        return
    if "--legacy" in args:
        try:
            run_launcher_gui()
        except ImportError:
            print("(tkinter not available — console mode)")
            run_launcher_console()
        return

    if NATIVE_APP_SCRIPT.exists():
        try:
            run_native_app()
        except Exception as e:
            print(f"Error: {e}")
            print("Falling back to legacy Gradio launcher...")
            try:
                run_launcher_gui()
            except ImportError:
                run_launcher_console()
    else:
        try:
            run_launcher_gui()
        except ImportError:
            print("(tkinter not available — console mode)")
            run_launcher_console()
        except Exception as e:
            print(f"Error: {e}")
            stop_all()
            sys.exit(1)


if __name__ == "__main__":
    main()
