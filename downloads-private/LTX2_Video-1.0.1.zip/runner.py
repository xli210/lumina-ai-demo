"""
LTX-2 Video Generation — Inference backend server.

Loads models, serves HTTP API on port 38000.
Supports ALL four pipelines from the Gradio app:
  1. Distilled (fast, 8-step)
  2. Two-Stage (production quality, CFG/STG guidance)
  3. IC-LoRA  (video-to-video with structural control)
  4. Keyframe Interpolation (two-image morphing)

Endpoints:
    GET  /healthz                 -> 200 when ready
    POST /api/generate            -> action: create | check | cancel
    GET  /api/tasks               -> list all tasks
    GET  /api/status/<id>         -> single task status
    GET  /api/logs                -> recent log entries
    DELETE /api/tasks/<id>        -> remove finished task

Usage:  python runner.py
"""
from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
os.environ["TQDM_DISABLE"] = "1"

import collections
import gc
import io
import json
import queue
import sys
import threading
import time
import traceback
import uuid
import logging
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from pathlib import Path
from urllib.parse import urlparse

# ---------------------------------------------------------------------------
# Paths & config
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).parent.resolve()
MODELS_DIR = SCRIPT_DIR / "models"
LORAS_DIR = MODELS_DIR / "loras"
GEMMA_DIR = MODELS_DIR / "gemma"
OUTPUT_DIR = SCRIPT_DIR / "outputs"
LOG_DIR = SCRIPT_DIR / "logs"
OUTPUT_DIR.mkdir(exist_ok=True)
LOG_DIR.mkdir(exist_ok=True)

# ---------------------------------------------------------------------------
# Safe stdio for subprocess mode (prevents pipe deadlocks on Windows)
# ---------------------------------------------------------------------------
def _safe_stdio():
    """Replace broken/piped stdio with safe alternatives to prevent deadlocks."""
    _logfile = LOG_DIR / "runner_stderr.log"
    try:
        _f = open(_logfile, "w", encoding="utf-8", buffering=1)
    except OSError:
        _f = open(os.devnull, "w")
    sys.stderr = _f
    if sys.stdout is None or (hasattr(sys.stdout, 'fileno') and _is_broken_fd(sys.stdout)):
        sys.stdout = _f


def _is_broken_fd(stream) -> bool:
    try:
        stream.fileno()
        stream.write("")
        return False
    except (OSError, ValueError, AttributeError):
        return True


_safe_stdio()

_LTX2_ROOT = SCRIPT_DIR / "LTX-2"
for _pkg in ("ltx-core", "ltx-pipelines"):
    _src = _LTX2_ROOT / "packages" / _pkg / "src"
    if _src.is_dir() and str(_src) not in sys.path:
        sys.path.insert(0, str(_src))
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

PORT = int(os.environ.get("LTX_RUNNER_PORT", "38000"))
MAX_TASK_HISTORY = 100
TASK_TTL_SECONDS = 3600
TASK_TIMEOUT_SECONDS = 1800

DISTILLED_FP8_CHECKPOINT = str(MODELS_DIR / "ltx-2-19b-distilled-fp8.safetensors")
DEV_FP8_CHECKPOINT = str(MODELS_DIR / "ltx-2-19b-dev-fp8.safetensors")
SPATIAL_UPSAMPLER = str(MODELS_DIR / "ltx-2-spatial-upscaler-x2-1.0.safetensors")
DISTILLED_LORA = str(MODELS_DIR / "ltx-2-19b-distilled-lora-384.safetensors")
GEMMA_ROOT = str(GEMMA_DIR)

CAMERA_LORAS = {
    "None": None,
    "Dolly In": "ltx-2-19b-lora-camera-control-dolly-in.safetensors",
    "Dolly Out": "ltx-2-19b-lora-camera-control-dolly-out.safetensors",
    "Dolly Left": "ltx-2-19b-lora-camera-control-dolly-left.safetensors",
    "Dolly Right": "ltx-2-19b-lora-camera-control-dolly-right.safetensors",
    "Jib Up": "ltx-2-19b-lora-camera-control-jib-up.safetensors",
    "Jib Down": "ltx-2-19b-lora-camera-control-jib-down.safetensors",
    "Static": "ltx-2-19b-lora-camera-control-static.safetensors",
}

IC_LORAS = {
    "Canny Control": "ltx-2-19b-ic-lora-canny-control.safetensors",
    "Depth Control": "ltx-2-19b-ic-lora-depth-control.safetensors",
    "Detailer": "ltx-2-19b-ic-lora-detailer.safetensors",
    "Pose Control": "ltx-2-19b-ic-lora-pose-control.safetensors",
}

# ---------------------------------------------------------------------------
# Logging (file-only — stderr may not be a real terminal)
# ---------------------------------------------------------------------------
_log_buffer: collections.deque = collections.deque(maxlen=500)
_log_lock = threading.Lock()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
    handlers=[
        logging.FileHandler(str(LOG_DIR / "runner.log"), encoding="utf-8"),
    ],
)
_logger = logging.getLogger("ltx2_runner")


def log(msg: str, level: str = "INFO"):
    ts = time.strftime("%H:%M:%S")
    entry = {"ts": ts, "level": level, "msg": msg}
    with _log_lock:
        _log_buffer.append(entry)
    getattr(_logger, level.lower(), _logger.info)(msg)


# ---------------------------------------------------------------------------
# Model state
# ---------------------------------------------------------------------------
MODEL_READY = False
DEVICE = "cpu"
DTYPE = None
GPU_NAME = "CPU"
USE_STREAMING = False
_active_profile = None

try:
    import torch
    _TORCH_AVAILABLE = True
except ImportError:
    _TORCH_AVAILABLE = False
    log("PyTorch not found. Install it first.", "ERROR")


def _get_fp8_native_quant():
    from ltx_core.quantization import QuantizationPolicy
    from ltx_core.quantization.fp8_cast import UPCAST_DURING_INFERENCE
    from ltx_core.loader.sd_ops import SDOps

    def _drop_key(key, value):
        return []

    drop_scales_ops = (
        SDOps("DROP_FP8_SCALE_KEYS")
        .with_kv_operation(operation=_drop_key, key_suffix=".weight_scale")
        .with_kv_operation(operation=_drop_key, key_suffix=".input_scale")
    )
    return QuantizationPolicy(sd_ops=drop_scales_ops, module_ops=(UPCAST_DURING_INFERENCE,))


def load_model():
    global MODEL_READY, DEVICE, DTYPE, GPU_NAME, USE_STREAMING, _active_profile

    if not _TORCH_AVAILABLE:
        log("Cannot load model — PyTorch not available", "ERROR")
        MODEL_READY = True  # let runner serve healthz at least
        return

    try:
        from vram_management import detect_vram_profile
    except ImportError as e:
        log(f"Failed to import vram_management: {e}", "ERROR")
        MODEL_READY = True
        return

    log("Detecting GPU and VRAM profile...")
    profile = detect_vram_profile()
    _active_profile = profile

    if torch.cuda.is_available():
        DEVICE = "cuda"
        GPU_NAME = torch.cuda.get_device_name(0)
        cap = torch.cuda.get_device_capability(0)
        DTYPE = torch.bfloat16 if cap[0] >= 8 else torch.float16
        USE_STREAMING = profile.use_streaming
        log(f"GPU: {GPU_NAME} ({profile.total_vram_gb:.0f} GB, compute {cap[0]}.{cap[1]})")
        log(f"Streaming DiT: {'enabled' if USE_STREAMING else 'disabled'}")
    else:
        DTYPE = torch.float32
        log("No GPU detected — CPU mode", "WARN")

    log(f"VRAM Profile: {profile.description}")

    if not Path(DISTILLED_FP8_CHECKPOINT).exists():
        log("Model checkpoint not found — download required", "WARN")

    MODEL_READY = True
    log(f"Runner ready ({DEVICE.upper()}: {GPU_NAME})")


# ---------------------------------------------------------------------------
# Task infrastructure
# ---------------------------------------------------------------------------
TASK_LABELS = {
    "distilled": "Fast (Distilled)",
    "two_stage": "Production (Two-Stage)",
    "ic_lora": "IC-LoRA (V2V)",
    "keyframe": "Keyframe Interpolation",
    "text2vid": "Fast (Distilled)",
}


class TaskCancelled(Exception):
    pass


tasks: dict[str, dict] = {}
tasks_lock = threading.Lock()
task_queue: queue.Queue = queue.Queue()


def _update_task(task_id: str, **kwargs):
    with tasks_lock:
        t = tasks.get(task_id)
        if t:
            t.update(kwargs)


def _should_stop(task_id: str) -> bool:
    with tasks_lock:
        t = tasks.get(task_id)
        if not t:
            return True
        if t.get("cancel_requested"):
            return True
        if t.get("started_at") and time.time() - t["started_at"] > TASK_TIMEOUT_SECONDS:
            t["cancel_requested"] = True
            return True
    return False


def _purge_old_tasks():
    now = time.time()
    with tasks_lock:
        to_remove = []
        terminal = ("DONE", "ERROR", "CANCELLED", "TIMEOUT")
        for tid, t in tasks.items():
            if t["status"] in terminal and now - t.get("created_at", now) > TASK_TTL_SECONDS:
                to_remove.append(tid)
        if len(tasks) > MAX_TASK_HISTORY:
            sorted_ids = sorted(tasks.keys(), key=lambda k: tasks[k].get("created_at", 0))
            for tid in sorted_ids[: len(tasks) - MAX_TASK_HISTORY]:
                if tasks[tid]["status"] in terminal:
                    to_remove.append(tid)
        for tid in set(to_remove):
            tasks.pop(tid, None)


def _cleanup_vram():
    gc.collect()
    gc.collect()
    if _TORCH_AVAILABLE and DEVICE == "cuda":
        try:
            torch.cuda.synchronize()
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()
        except Exception:
            pass


def _get_output_path(prefix: str) -> str:
    ts = time.strftime("%Y%m%d_%H%M%S")
    return str(OUTPUT_DIR / f"{prefix}_{ts}_{uuid.uuid4().hex[:6]}.mp4")


def _build_camera_loras(camera_lora: str, strength: float):
    from ltx_core.loader import LTXV_LORA_COMFY_RENAMING_MAP, LoraPathStrengthAndSDOps
    loras = []
    if camera_lora != "None" and CAMERA_LORAS.get(camera_lora):
        lora_path = str(LORAS_DIR / CAMERA_LORAS[camera_lora])
        if Path(lora_path).exists():
            loras.append(LoraPathStrengthAndSDOps(lora_path, strength, LTXV_LORA_COMFY_RENAMING_MAP))
    return loras


def _apply_vram_profile(pipeline, two_stage=False):
    if not _active_profile:
        return
    if two_stage:
        for ledger in (pipeline.stage_1_model_ledger, pipeline.stage_2_model_ledger):
            ledger.transformer_max_memory = _active_profile.transformer_max_memory
            ledger.text_encoder_max_memory = _active_profile.text_encoder_max_memory
            ledger.upsampler_max_memory = _active_profile.upsampler_max_memory
    else:
        pipeline.model_ledger.transformer_max_memory = _active_profile.transformer_max_memory
        pipeline.model_ledger.text_encoder_max_memory = _active_profile.text_encoder_max_memory
        pipeline.model_ledger.upsampler_max_memory = _active_profile.upsampler_max_memory


# ---------------------------------------------------------------------------
# Progress-reporting denoising loop (monkey-patches euler_denoising_loop)
# ---------------------------------------------------------------------------
_progress_ctx = threading.local()


def _progress_denoising_loop(sigmas, video_state, audio_state, stepper, denoise_fn):
    """Drop-in replacement for euler_denoising_loop that reports per-step progress."""
    from dataclasses import replace as _replace

    ctx = getattr(_progress_ctx, "current", None)
    total_steps = len(sigmas) - 1

    for step_idx in range(total_steps):
        if ctx:
            frac = (step_idx + 1) / total_steps
            p_lo, p_hi = ctx["range"]
            progress = p_lo + frac * (p_hi - p_lo)
            _update_task(ctx["task_id"], progress=round(progress, 3),
                         message=f"{ctx['phase']} step {step_idx + 1}/{total_steps}")
            if _should_stop(ctx["task_id"]):
                raise TaskCancelled()

        denoised_video, denoised_audio = denoise_fn(video_state, audio_state, sigmas, step_idx)

        from ltx_pipelines.utils.helpers import post_process_latent
        denoised_video = post_process_latent(denoised_video, video_state.denoise_mask, video_state.clean_latent)
        denoised_audio = post_process_latent(denoised_audio, audio_state.denoise_mask, audio_state.clean_latent)

        video_state = _replace(video_state, latent=stepper.step(video_state.latent, denoised_video, sigmas, step_idx))
        audio_state = _replace(audio_state, latent=stepper.step(audio_state.latent, denoised_audio, sigmas, step_idx))

    return (video_state, audio_state)


_PATCH_MODULES = [
    "ltx_pipelines.utils.helpers",
    "ltx_pipelines.distilled",
    "ltx_pipelines.ic_lora",
    "ltx_pipelines.keyframe_interpolation",
    "ltx_pipelines.ti2vid_two_stages",
    "ltx_pipelines.ti2vid_one_stage",
]


class _ProgressScope:
    """Context manager that patches euler_denoising_loop with progress reporting."""

    def __init__(self, task_id: str, phase: str, progress_range: tuple[float, float]):
        self._task_id = task_id
        self._phase = phase
        self._range = progress_range
        self._saved: list[tuple] = []

    def __enter__(self):
        self._saved.clear()
        for mod_name in _PATCH_MODULES:
            mod = sys.modules.get(mod_name)
            if mod and hasattr(mod, "euler_denoising_loop"):
                self._saved.append((mod, mod.euler_denoising_loop))
                mod.euler_denoising_loop = _progress_denoising_loop
        _progress_ctx.current = {
            "task_id": self._task_id,
            "phase": self._phase,
            "range": self._range,
        }
        return self

    def __exit__(self, *exc):
        for mod, orig_fn in self._saved:
            mod.euler_denoising_loop = orig_fn
        self._saved.clear()
        _progress_ctx.current = None


def _phase(task_id, progress, message):
    """Log + update task for a named inference phase."""
    _update_task(task_id, progress=progress, message=message)
    log(f"  [{task_id[:8]}] {message}")


# ---------------------------------------------------------------------------
# Inference: Distilled Pipeline
# ---------------------------------------------------------------------------
def _infer_distilled(task_id: str, p: dict) -> str:
    from ltx_core.model.video_vae import TilingConfig, get_video_chunks_number
    from ltx_pipelines.distilled import DistilledPipeline
    from ltx_pipelines.utils.constants import AUDIO_SAMPLE_RATE
    from ltx_pipelines.utils.media_io import encode_video

    loras = _build_camera_loras(p.get("camera_lora", "None"),
                                float(p.get("camera_lora_strength", 1.0)))
    ckpt = DEV_FP8_CHECKPOINT if (loras and Path(DEV_FP8_CHECKPOINT).exists()) else DISTILLED_FP8_CHECKPOINT

    _phase(task_id, 0.05, "Building distilled pipeline...")
    pipeline = DistilledPipeline(
        checkpoint_path=ckpt, gemma_root=GEMMA_ROOT,
        spatial_upsampler_path=SPATIAL_UPSAMPLER,
        loras=loras, quantization=_get_fp8_native_quant(),
    )
    _apply_vram_profile(pipeline)

    if _should_stop(task_id):
        raise TaskCancelled()

    images = []
    if p.get("image_path") and os.path.isfile(p["image_path"]):
        images.append((p["image_path"], int(p.get("image_frame_idx", 0)),
                        float(p.get("image_strength", 0.3))))

    h, w = int(p.get("height", 704)), int(p.get("width", 1280))
    nf = int(p.get("num_frames", 41))
    tiling = TilingConfig.default()
    chunks = get_video_chunks_number(nf, tiling)

    _phase(task_id, 0.10, f"Generating {w}x{h}, {nf}f (distilled)...")
    with _ProgressScope(task_id, "Distilled", (0.10, 0.85)):
        with torch.inference_mode():
            video, audio = pipeline(
                prompt=p.get("prompt", ""), seed=int(p.get("seed", 0)),
                height=h, width=w, num_frames=nf,
                frame_rate=float(p.get("frame_rate", 25.0)),
                images=images, tiling_config=tiling,
                enhance_prompt=p.get("enhance_prompt", True),
            )

    _phase(task_id, 0.90, "Encoding video...")
    if p.get("disable_audio", True):
        audio = None
    out = _get_output_path("distilled")
    encode_video(video=video, fps=float(p.get("frame_rate", 25.0)),
                 audio=audio, audio_sample_rate=AUDIO_SAMPLE_RATE,
                 output_path=out, video_chunks_number=chunks)
    del pipeline, video, audio
    _cleanup_vram()
    return out


# ---------------------------------------------------------------------------
# Inference: Two-Stage Pipeline  (fully instrumented)
# ---------------------------------------------------------------------------
def _infer_two_stage(task_id: str, p: dict) -> str:
    from dataclasses import replace as _replace
    from ltx_core.components.diffusion_steps import EulerDiffusionStep
    from ltx_core.components.guiders import MultiModalGuider, MultiModalGuiderParams
    from ltx_core.components.noisers import GaussianNoiser
    from ltx_core.components.schedulers import LTX2Scheduler
    from ltx_core.loader import LTXV_LORA_COMFY_RENAMING_MAP, LoraPathStrengthAndSDOps
    from ltx_core.model.audio_vae import decode_audio as vae_decode_audio
    from ltx_core.model.upsampler import upsample_video
    from ltx_core.model.video_vae import TilingConfig, get_video_chunks_number
    from ltx_core.model.video_vae import decode_video as vae_decode_video
    from ltx_core.quantization import QuantizationPolicy
    from ltx_core.text_encoders.gemma import encode_text
    from ltx_core.types import LatentState, VideoPixelShape
    from ltx_pipelines.utils import ModelLedger
    from ltx_pipelines.utils.constants import AUDIO_SAMPLE_RATE, STAGE_2_DISTILLED_SIGMA_VALUES
    from ltx_pipelines.utils.helpers import (
        assert_resolution, cleanup_memory, denoise_audio_video,
        generate_enhanced_prompt, image_conditionings_by_replacing_latent,
        multi_modal_guider_denoising_func, simple_denoising_func,
    )
    from ltx_pipelines.utils.media_io import encode_video
    from ltx_pipelines.utils.types import PipelineComponents

    h, w = int(p.get("height", 704)), int(p.get("width", 1280))
    nf = int(p.get("num_frames", 41))
    n_steps = int(p.get("num_inference_steps", 40))

    # ---- Phase 1: Build pipeline (lazy, just creates ModelLedger) ----------
    _phase(task_id, 0.02, f"Building two-stage pipeline ({w}x{h}, {nf}f, {n_steps} steps)...")

    distilled_lora_list = [
        LoraPathStrengthAndSDOps(DISTILLED_LORA, 0.8, LTXV_LORA_COMFY_RENAMING_MAP),
    ]
    loras = _build_camera_loras(p.get("camera_lora", "None"),
                                float(p.get("camera_lora_strength", 1.0)))

    ckpt = DEV_FP8_CHECKPOINT if Path(DEV_FP8_CHECKPOINT).exists() else DISTILLED_FP8_CHECKPOINT
    device_str = DEVICE
    dtype = DTYPE or torch.bfloat16

    stage_1_ledger = ModelLedger(
        dtype=dtype, device=device_str, checkpoint_path=ckpt,
        gemma_root_path=GEMMA_ROOT, spatial_upsampler_path=SPATIAL_UPSAMPLER,
        loras=loras, quantization=_get_fp8_native_quant(),
    )
    stage_2_ledger = stage_1_ledger.with_loras(loras=distilled_lora_list)
    components = PipelineComponents(dtype=dtype, device=device_str)

    if _active_profile:
        for ledger in (stage_1_ledger, stage_2_ledger):
            ledger.transformer_max_memory = _active_profile.transformer_max_memory
            ledger.text_encoder_max_memory = _active_profile.text_encoder_max_memory
            ledger.upsampler_max_memory = _active_profile.upsampler_max_memory

    if _should_stop(task_id):
        raise TaskCancelled()

    # ---- Phase 2: Text encoding (Gemma-3 12B) ----------------------------
    _phase(task_id, 0.04, "Loading text encoder (Gemma-3 12B)...")
    prompt_text = p.get("prompt", "")
    neg_prompt = p.get("negative_prompt", "")

    images = []
    if p.get("image_path") and os.path.isfile(p["image_path"]):
        images.append((p["image_path"], int(p.get("image_frame_idx", 0)),
                        float(p.get("image_strength", 0.3))))

    with torch.inference_mode():
        text_encoder = stage_1_ledger.text_encoder()
        if p.get("enhance_prompt", True):
            _phase(task_id, 0.06, "Enhancing prompt with Gemma...")
            prompt_text = generate_enhanced_prompt(
                text_encoder, prompt_text,
                images[0][0] if images else None,
                seed=int(p.get("seed", 0)),
            )
            log(f"  [{task_id[:8]}] Enhanced: {prompt_text[:120]}...")

        _phase(task_id, 0.08, "Encoding text embeddings...")
        context_p, context_n = encode_text(text_encoder, prompts=[prompt_text, neg_prompt])
        v_ctx_p, a_ctx_p = context_p
        v_ctx_n, a_ctx_n = context_n

        torch.cuda.synchronize()
        del text_encoder
        cleanup_memory()

        if _should_stop(task_id):
            raise TaskCancelled()

        # ---- Phase 3: Stage 1 denoising (n_steps steps at half-res) ------
        _phase(task_id, 0.10, f"Stage 1: loading transformer + encoder...")
        assert_resolution(height=h, width=w, is_two_stage=True)
        generator = torch.Generator(device=device_str).manual_seed(int(p.get("seed", 0)))
        noiser = GaussianNoiser(generator=generator)
        stepper = EulerDiffusionStep()

        video_encoder = stage_1_ledger.video_encoder()
        transformer = stage_1_ledger.transformer()
        sigmas = LTX2Scheduler().execute(steps=n_steps).to(dtype=torch.float32, device=device_str)

        video_guider = MultiModalGuiderParams(
            cfg_scale=float(p.get("video_cfg_scale", 3.0)),
            stg_scale=float(p.get("video_stg_scale", 1.0)),
            rescale_scale=float(p.get("video_rescale_scale", 0.7)),
            modality_scale=float(p.get("modality_scale", 3.0)),
            skip_step=0, stg_blocks=[29],
        )
        audio_guider = MultiModalGuiderParams(
            cfg_scale=float(p.get("audio_cfg_scale", 7.0)),
            stg_scale=float(p.get("audio_stg_scale", 1.0)),
            rescale_scale=float(p.get("audio_rescale_scale", 0.7)),
            modality_scale=float(p.get("modality_scale", 3.0)),
            skip_step=0, stg_blocks=[29],
        )

        def s1_denoising_loop(sigs, vs, aus, stp):
            return _progress_denoising_loop(
                sigs, vs, aus, stp,
                denoise_fn=multi_modal_guider_denoising_func(
                    video_guider=MultiModalGuider(params=video_guider, negative_context=v_ctx_n),
                    audio_guider=MultiModalGuider(params=audio_guider, negative_context=a_ctx_n),
                    v_context=v_ctx_p, a_context=a_ctx_p, transformer=transformer,
                ),
            )

        s1_shape = VideoPixelShape(batch=1, frames=nf, width=w // 2, height=h // 2,
                                   fps=float(p.get("frame_rate", 25.0)))
        s1_cond = image_conditionings_by_replacing_latent(
            images=images, height=s1_shape.height, width=s1_shape.width,
            video_encoder=video_encoder, dtype=dtype, device=device_str,
        )

        _phase(task_id, 0.12, f"Stage 1: denoising {n_steps} steps at {w//2}x{h//2}...")
        _progress_ctx.current = {"task_id": task_id, "phase": "Stage 1", "range": (0.12, 0.55)}
        video_state, audio_state = denoise_audio_video(
            output_shape=s1_shape, conditionings=s1_cond, noiser=noiser,
            sigmas=sigmas, stepper=stepper, denoising_loop_fn=s1_denoising_loop,
            components=components, dtype=dtype, device=device_str,
        )
        _progress_ctx.current = None

        torch.cuda.synchronize()
        del transformer
        cleanup_memory()

        if _should_stop(task_id):
            raise TaskCancelled()

        # ---- Phase 4: Spatial upsampling ----------------------------------
        _phase(task_id, 0.58, "Upsampling video 2x...")
        upscaled = upsample_video(
            latent=video_state.latent[:1],
            video_encoder=video_encoder,
            upsampler=stage_2_ledger.spatial_upsampler(),
        )
        torch.cuda.synchronize()
        cleanup_memory()

        # ---- Phase 5: Stage 2 denoising (distilled, 8 steps at full-res) -
        _phase(task_id, 0.62, "Stage 2: loading transformer...")
        transformer = stage_2_ledger.transformer()
        distilled_sigmas = torch.Tensor(STAGE_2_DISTILLED_SIGMA_VALUES).to(device_str)

        def s2_denoising_loop(sigs, vs, aus, stp):
            return _progress_denoising_loop(
                sigs, vs, aus, stp,
                denoise_fn=simple_denoising_func(
                    video_context=v_ctx_p, audio_context=a_ctx_p, transformer=transformer,
                ),
            )

        s2_shape = VideoPixelShape(batch=1, frames=nf, width=w, height=h,
                                   fps=float(p.get("frame_rate", 25.0)))
        s2_cond = image_conditionings_by_replacing_latent(
            images=images, height=s2_shape.height, width=s2_shape.width,
            video_encoder=video_encoder, dtype=dtype, device=device_str,
        )

        n2 = len(STAGE_2_DISTILLED_SIGMA_VALUES) - 1
        _phase(task_id, 0.64, f"Stage 2: denoising {n2} steps at {w}x{h}...")
        _progress_ctx.current = {"task_id": task_id, "phase": "Stage 2", "range": (0.64, 0.82)}
        video_state, audio_state = denoise_audio_video(
            output_shape=s2_shape, conditionings=s2_cond, noiser=noiser,
            sigmas=distilled_sigmas, stepper=stepper, denoising_loop_fn=s2_denoising_loop,
            components=components, dtype=dtype, device=device_str,
            noise_scale=distilled_sigmas[0],
            initial_video_latent=upscaled,
            initial_audio_latent=audio_state.latent,
        )
        _progress_ctx.current = None

        torch.cuda.synchronize()
        del transformer, video_encoder
        cleanup_memory()

        # ---- Phase 6: Decode video + audio --------------------------------
        _phase(task_id, 0.84, "Decoding video...")
        tiling = TilingConfig.default()
        chunks = get_video_chunks_number(nf, tiling)
        video = vae_decode_video(video_state.latent, stage_2_ledger.video_decoder(), tiling, generator)

        _phase(task_id, 0.88, "Decoding audio...")
        audio = vae_decode_audio(audio_state.latent, stage_2_ledger.audio_decoder(), stage_2_ledger.vocoder())

    # ---- Phase 7: Encode to MP4 ------------------------------------------
    _phase(task_id, 0.92, "Encoding MP4...")
    if p.get("disable_audio", True):
        audio = None
    out = _get_output_path("twostage")
    encode_video(video=video, fps=float(p.get("frame_rate", 25.0)),
                 audio=audio, audio_sample_rate=AUDIO_SAMPLE_RATE,
                 output_path=out, video_chunks_number=chunks)
    del video, audio, video_state, audio_state
    del stage_1_ledger, stage_2_ledger, components
    _cleanup_vram()
    return out


# ---------------------------------------------------------------------------
# Inference: IC-LoRA Pipeline
# ---------------------------------------------------------------------------
def _infer_ic_lora(task_id: str, p: dict) -> str:
    from ltx_core.loader import LTXV_LORA_COMFY_RENAMING_MAP, LoraPathStrengthAndSDOps
    from ltx_core.model.video_vae import TilingConfig, get_video_chunks_number
    from ltx_pipelines.ic_lora import ICLoraPipeline
    from ltx_pipelines.utils.constants import AUDIO_SAMPLE_RATE
    from ltx_pipelines.utils.media_io import encode_video

    ic_lora_type = p.get("ic_lora_type", "Canny Control")
    ic_lora_strength = float(p.get("ic_lora_strength", 1.0))
    video_cond_path = p.get("video_conditioning_path")

    if p.get("auto_preprocess", True) and video_cond_path and ic_lora_type != "Detailer":
        _phase(task_id, 0.03, f"Preprocessing ({ic_lora_type})...")
        from video_preprocessors import preprocess_for_control
        video_cond_path = preprocess_for_control(video_cond_path, ic_lora_type)

    loras = []
    if ic_lora_type in IC_LORAS:
        lp = str(LORAS_DIR / IC_LORAS[ic_lora_type])
        if Path(lp).exists():
            loras.append(LoraPathStrengthAndSDOps(lp, ic_lora_strength, LTXV_LORA_COMFY_RENAMING_MAP))

    _phase(task_id, 0.06, "Building IC-LoRA pipeline...")
    ckpt = DEV_FP8_CHECKPOINT if Path(DEV_FP8_CHECKPOINT).exists() else DISTILLED_FP8_CHECKPOINT
    pipeline = ICLoraPipeline(
        checkpoint_path=ckpt, spatial_upsampler_path=SPATIAL_UPSAMPLER,
        gemma_root=GEMMA_ROOT, loras=loras, quantization=_get_fp8_native_quant(),
    )
    _apply_vram_profile(pipeline, two_stage=True)

    if _should_stop(task_id):
        raise TaskCancelled()

    images = []
    if p.get("image_path") and os.path.isfile(p["image_path"]):
        images.append((p["image_path"], int(p.get("image_frame_idx", 0)),
                        float(p.get("image_strength", 0.3))))

    video_conditioning = []
    if video_cond_path and os.path.isfile(video_cond_path):
        video_conditioning.append((video_cond_path,
                                    float(p.get("video_conditioning_strength", 1.0))))

    h, w = int(p.get("height", 704)), int(p.get("width", 1280))
    nf = int(p.get("num_frames", 41))
    tiling = TilingConfig.default()
    chunks = get_video_chunks_number(nf, tiling)

    _phase(task_id, 0.10, f"Generating {w}x{h}, {nf}f (IC-LoRA)...")
    with _ProgressScope(task_id, "IC-LoRA", (0.10, 0.85)):
        with torch.inference_mode():
            video, audio = pipeline(
                prompt=p.get("prompt", ""), seed=int(p.get("seed", 0)),
                height=h, width=w, num_frames=nf,
                frame_rate=float(p.get("frame_rate", 25.0)),
                images=images, video_conditioning=video_conditioning,
                tiling_config=tiling, enhance_prompt=p.get("enhance_prompt", True),
            )

    _phase(task_id, 0.90, "Encoding video...")
    if p.get("disable_audio", True):
        audio = None
    out = _get_output_path("iclora")
    encode_video(video=video, fps=float(p.get("frame_rate", 25.0)),
                 audio=audio, audio_sample_rate=AUDIO_SAMPLE_RATE,
                 output_path=out, video_chunks_number=chunks)
    del pipeline, video, audio
    _cleanup_vram()
    return out


# ---------------------------------------------------------------------------
# Inference: Keyframe Interpolation Pipeline
# ---------------------------------------------------------------------------
def _infer_keyframe(task_id: str, p: dict) -> str:
    from ltx_core.components.guiders import MultiModalGuiderParams
    from ltx_core.loader import LTXV_LORA_COMFY_RENAMING_MAP, LoraPathStrengthAndSDOps
    from ltx_core.model.video_vae import TilingConfig, get_video_chunks_number
    from ltx_pipelines.keyframe_interpolation import KeyframeInterpolationPipeline
    from ltx_pipelines.utils.constants import AUDIO_SAMPLE_RATE
    from ltx_pipelines.utils.media_io import encode_video

    distilled_lora_list = [
        LoraPathStrengthAndSDOps(DISTILLED_LORA, 0.8, LTXV_LORA_COMFY_RENAMING_MAP),
    ]
    loras = _build_camera_loras(p.get("camera_lora", "None"),
                                float(p.get("camera_lora_strength", 1.0)))

    _phase(task_id, 0.06, "Building keyframe pipeline...")
    ckpt = DEV_FP8_CHECKPOINT if Path(DEV_FP8_CHECKPOINT).exists() else DISTILLED_FP8_CHECKPOINT
    pipeline = KeyframeInterpolationPipeline(
        checkpoint_path=ckpt, distilled_lora=distilled_lora_list,
        spatial_upsampler_path=SPATIAL_UPSAMPLER, gemma_root=GEMMA_ROOT,
        loras=loras, quantization=_get_fp8_native_quant(),
    )
    _apply_vram_profile(pipeline, two_stage=True)

    if _should_stop(task_id):
        raise TaskCancelled()

    images = []
    kf1 = p.get("keyframe1_path")
    if kf1 and os.path.isfile(kf1):
        images.append((kf1, int(p.get("keyframe1_frame_idx", 0)),
                        float(p.get("keyframe1_strength", 1.0))))
    kf2 = p.get("keyframe2_path")
    if kf2 and os.path.isfile(kf2):
        images.append((kf2, int(p.get("keyframe2_frame_idx", 56)),
                        float(p.get("keyframe2_strength", 1.0))))

    h, w = int(p.get("height", 704)), int(p.get("width", 1280))
    nf = int(p.get("num_frames", 41))
    tiling = TilingConfig.default()
    chunks = get_video_chunks_number(nf, tiling)

    video_guider = MultiModalGuiderParams(
        cfg_scale=float(p.get("video_cfg_scale", 3.0)),
        stg_scale=float(p.get("video_stg_scale", 1.0)),
        rescale_scale=float(p.get("video_rescale_scale", 0.7)),
        modality_scale=float(p.get("modality_scale", 3.0)),
        skip_step=0, stg_blocks=[29],
    )
    audio_guider = MultiModalGuiderParams(
        cfg_scale=float(p.get("audio_cfg_scale", 7.0)),
        stg_scale=float(p.get("audio_stg_scale", 1.0)),
        rescale_scale=float(p.get("audio_rescale_scale", 0.7)),
        modality_scale=float(p.get("modality_scale", 3.0)),
        skip_step=0, stg_blocks=[29],
    )

    _phase(task_id, 0.10, f"Generating {w}x{h}, {nf}f (keyframe)...")
    with _ProgressScope(task_id, "Keyframe", (0.10, 0.85)):
        with torch.inference_mode():
            video, audio = pipeline(
                prompt=p.get("prompt", ""),
                negative_prompt=p.get("negative_prompt", ""),
                seed=int(p.get("seed", 0)),
                height=h, width=w, num_frames=nf,
                frame_rate=float(p.get("frame_rate", 25.0)),
                num_inference_steps=int(p.get("num_inference_steps", 40)),
                video_guider_params=video_guider, audio_guider_params=audio_guider,
                images=images, tiling_config=tiling,
                enhance_prompt=p.get("enhance_prompt", True),
            )

    _phase(task_id, 0.90, "Encoding video...")
    if p.get("disable_audio", True):
        audio = None
    out = _get_output_path("keyframe")
    encode_video(video=video, fps=float(p.get("frame_rate", 25.0)),
                 audio=audio, audio_sample_rate=AUDIO_SAMPLE_RATE,
                 output_path=out, video_chunks_number=chunks)
    del pipeline, video, audio
    _cleanup_vram()
    return out


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------
_PIPELINE_DISPATCH = {
    "distilled": _infer_distilled,
    "text2vid": _infer_distilled,
    "two_stage": _infer_two_stage,
    "ic_lora": _infer_ic_lora,
    "keyframe": _infer_keyframe,
}


def do_inference(task_id: str, params: dict) -> str:
    task_type = params.get("task_type", "distilled")
    fn = _PIPELINE_DISPATCH.get(task_type, _infer_distilled)
    return fn(task_id, params)


# ---------------------------------------------------------------------------
# Worker thread
# ---------------------------------------------------------------------------
def worker():
    while True:
        item = task_queue.get()
        if item is None:
            break
        task_id, params = item

        with tasks_lock:
            t = tasks.get(task_id)
            if not t:
                task_queue.task_done()
                continue
            if t.get("cancel_requested"):
                t["status"] = "CANCELLED"
                t["finished_at"] = time.time()
                t["message"] = "Cancelled before processing."
                task_queue.task_done()
                continue

        now = time.time()
        _update_task(task_id, status="PROCESSING", started_at=now,
                     progress=0.02, message="Starting...")
        task_type = params.get("task_type", "distilled")
        log(f"Task {task_id[:8]} started ({TASK_LABELS.get(task_type, task_type)})")

        try:
            _cleanup_vram()
            result_path = do_inference(task_id, params)
            elapsed = time.time() - now
            _update_task(task_id, status="DONE", progress=1.0, result=result_path,
                         finished_at=time.time(),
                         message=f"Completed in {elapsed:.1f}s")
            log(f"Task {task_id[:8]} done in {elapsed:.1f}s -> {os.path.basename(result_path)}")
            _cleanup_vram()

        except TaskCancelled:
            elapsed = time.time() - now
            timed_out = elapsed >= TASK_TIMEOUT_SECONDS
            status = "TIMEOUT" if timed_out else "CANCELLED"
            msg = f"Timed out after {elapsed:.0f}s" if timed_out else f"Cancelled ({elapsed:.1f}s)"
            _update_task(task_id, status=status, finished_at=time.time(), message=msg)
            log(f"Task {task_id[:8]} {status.lower()}: {msg}")
            _cleanup_vram()

        except Exception as e:
            elapsed = time.time() - now
            tb = traceback.format_exc()
            error_msg = str(e)
            if "OutOfMemoryError" in tb or "CUDA out of memory" in str(e):
                error_msg = (
                    "Out of GPU memory. Try reducing resolution or frame count, "
                    "disable audio, or select a lower VRAM profile."
                )
            _update_task(task_id, status="ERROR", error=error_msg,
                         finished_at=time.time(),
                         message=f"Error after {elapsed:.1f}s: {error_msg}")
            log(f"Task {task_id[:8]} error: {e}", "ERROR")
            log(tb, "ERROR")
            _cleanup_vram()

        _purge_old_tasks()
        task_queue.task_done()


worker_thread = threading.Thread(target=worker, daemon=True)
worker_thread.start()


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------
def send_json(handler, code, data):
    try:
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        handler.send_response(code)
        handler.send_header("Content-Type", "application/json; charset=utf-8")
        handler.send_header("Content-Length", str(len(body)))
        handler.send_header("Access-Control-Allow-Origin", "*")
        handler.end_headers()
        handler.wfile.write(body)
    except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError, OSError):
        pass


def _task_summary(task_id: str, t: dict, queue_position: int | None = None) -> dict:
    return {
        "task_id": task_id,
        "status": t["status"],
        "progress": t.get("progress", 0),
        "message": t.get("message", ""),
        "result": t.get("result", ""),
        "error": t.get("error", ""),
        "task_type": t.get("task_type", ""),
        "task_label": TASK_LABELS.get(t.get("task_type", ""), ""),
        "created_at": t.get("created_at", 0),
        "started_at": t.get("started_at"),
        "finished_at": t.get("finished_at"),
        "queue_position": queue_position,
    }


# ---------------------------------------------------------------------------
# HTTP handler
# ---------------------------------------------------------------------------
class _ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        """Swallow connection errors so they don't crash serve_forever."""
        try:
            _, exc_val, _ = sys.exc_info()
            if isinstance(exc_val, (ConnectionResetError, ConnectionAbortedError,
                                    BrokenPipeError, OSError)):
                return
            log(f"HTTP error from {client_address}: {exc_val}", "WARN")
        except Exception:
            pass


class RunnerHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path

        if path == "/healthz":
            send_json(self, 200 if MODEL_READY else 503, {
                "status": "ok" if MODEL_READY else "loading",
                "device": DEVICE, "gpu": GPU_NAME, "streaming": USE_STREAMING,
            })
            return

        if path.startswith("/api/status/"):
            tid = path.split("/api/status/")[-1].split("?")[0]
            with tasks_lock:
                t = tasks.get(tid)
                resp = _task_summary(tid, t) if t else None
            send_json(self, 200 if resp else 404, resp or {"error": "Not found"})
            return

        if path == "/api/tasks":
            with tasks_lock:
                active_ids = sorted(
                    [k for k, v in tasks.items() if v["status"] in ("QUEUED", "PROCESSING")],
                    key=lambda k: tasks[k].get("created_at", 0))
                pos_map = {k: i for i, k in enumerate(active_ids)}
                items = [_task_summary(k, v, pos_map.get(k))
                         for k, v in tasks.items()]
            items.sort(key=lambda x: x["created_at"], reverse=True)
            send_json(self, 200, {"tasks": items, "queue_size": task_queue.qsize(),
                                  "active_count": len(active_ids)})
            return

        if path == "/api/logs":
            with _log_lock:
                entries = list(_log_buffer)
            send_json(self, 200, {"logs": entries})
            return

        if path.startswith("/outputs/"):
            fname = path.split("/outputs/")[-1]
            fpath = str(OUTPUT_DIR / fname)
            if os.path.isfile(fpath):
                self.send_response(200)
                self.send_header("Content-Type", "video/mp4" if fname.endswith(".mp4") else "application/octet-stream")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                with open(fpath, "rb") as f:
                    self.wfile.write(f.read())
                return

        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        path = urlparse(self.path).path
        if path != "/api/generate":
            self.send_response(404)
            self.end_headers()
            return

        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        try:
            data = json.loads(body.decode("utf-8"))
        except Exception:
            send_json(self, 400, {"error": "Invalid JSON"})
            return

        action = data.get("action", "create")

        if action == "check":
            tid = data.get("task_id", "")
            with tasks_lock:
                t = tasks.get(tid)
                resp = _task_summary(tid, t) if t else None
            send_json(self, 200 if resp else 404, resp or {"error": "Not found"})
            return

        if action == "cancel":
            tid = data.get("task_id", "")
            with tasks_lock:
                t = tasks.get(tid)
                if not t:
                    send_json(self, 404, {"error": "Not found"})
                    return
                if t["status"] in ("DONE", "ERROR", "CANCELLED", "TIMEOUT"):
                    send_json(self, 200, {"message": "Already finished.", **_task_summary(tid, t)})
                    return
                t["cancel_requested"] = True
                if t["status"] == "QUEUED":
                    t["status"] = "CANCELLED"
                    t["finished_at"] = time.time()
                    t["message"] = "Cancelled while queued."
            log(f"Task {tid[:8]} cancel requested.")
            send_json(self, 200, {"message": "Cancel requested.", "task_id": tid})
            return

        if action == "create":
            task_id = uuid.uuid4().hex
            task_type = data.get("task_type", "distilled")
            now = time.time()
            with tasks_lock:
                tasks[task_id] = {
                    "status": "QUEUED", "progress": 0, "result": "", "error": "",
                    "message": "Queued.", "task_type": task_type,
                    "created_at": now, "started_at": None, "finished_at": None,
                    "cancel_requested": False,
                }
                qpos = sum(1 for v in tasks.values() if v["status"] in ("QUEUED", "PROCESSING"))
            task_queue.put((task_id, data))
            log(f"Task {task_id[:8]} queued ({TASK_LABELS.get(task_type, task_type)}, #{qpos})")
            send_json(self, 200, {"task_id": task_id, "status": "QUEUED", "queue_position": qpos})
            return

        send_json(self, 400, {"error": f"Unknown action: {action}"})

    def do_DELETE(self):
        path = urlparse(self.path).path
        if path.startswith("/api/tasks/"):
            tid = path.split("/api/tasks/")[-1].split("?")[0]
            with tasks_lock:
                t = tasks.get(tid)
                if not t:
                    send_json(self, 404, {"error": "Not found"})
                    return
                if t["status"] in ("DONE", "ERROR", "CANCELLED", "TIMEOUT"):
                    tasks.pop(tid, None)
                    send_json(self, 200, {"message": "Removed."})
                    return
                send_json(self, 400, {"error": "Cannot remove active task."})
                return
        self.send_response(404)
        self.end_headers()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    try:
        log("LTX-2 Runner starting...")
        load_model()
        log(f"Listening on http://127.0.0.1:{PORT}")
        server = _ThreadingHTTPServer(("127.0.0.1", PORT), RunnerHandler)
        server.serve_forever()
    except (KeyboardInterrupt, SystemExit):
        log("Shutting down.")
    except Exception:
        log(f"Fatal error:\n{traceback.format_exc()}", "ERROR")
        sys.exit(1)
    finally:
        task_queue.put(None)


if __name__ == "__main__":
    main()
