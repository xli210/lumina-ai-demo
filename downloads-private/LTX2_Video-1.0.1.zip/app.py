"""
LTX-2 Video Generation Studio
A comprehensive Gradio UI for all LTX-2 pipelines with LoRA support.
Supports GPUs from 8 GB to 32+ GB VRAM via automatic CPU offloading.
"""

import gc
import json
import logging
import os
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path

# Set environment variables for memory optimization
# Note: expandable_segments not needed for RTX 5090 nightly builds

import gradio as gr
import torch

# Ensure the project root is on sys.path (needed for bundled/embeddable Python)
_PROJECT_ROOT = str(Path(__file__).parent)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

# Try importing from site-packages first (product mode / BUILD.bat env).
# Fall back to development mode (LTX-2 repo checked out alongside this file).
try:
    import ltx_core  # noqa: F401 — just testing if it's importable
except ImportError:
    LTX2_ROOT = Path(__file__).parent / "LTX-2"
    sys.path.insert(0, str(LTX2_ROOT / "packages" / "ltx-core" / "src"))
    sys.path.insert(0, str(LTX2_ROOT / "packages" / "ltx-pipelines" / "src"))

from vram_management import (
    VRAMProfile,
    ALL_PROFILES,
    detect_vram_profile,
    get_profile_by_name,
    max_frames_for_resolution,
    get_prompt_cache_path,
    load_cached_prompt,
    save_prompt_cache,
    get_gpu_info_str,
    RESOLUTION_PRESETS,
    _ensure_profiles,
)


# ============================================================================
# Logging System — file + console
# ============================================================================
LOG_DIR = Path(__file__).parent / "logs"
LOG_DIR.mkdir(exist_ok=True)
LOG_FILE = LOG_DIR / f"ltx2_{datetime.now().strftime('%Y%m%d')}.log"

# Configure root logger with both file and console handlers
_log_formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
_console_handler = logging.StreamHandler()
_console_handler.setFormatter(_log_formatter)
_file_handler = logging.FileHandler(str(LOG_FILE), encoding="utf-8")
_file_handler.setFormatter(_log_formatter)
logging.basicConfig(level=logging.INFO, handlers=[_console_handler, _file_handler])
logger = logging.getLogger(__name__)

logger.info("=" * 60)
logger.info("LTX-2 Video Generation Studio starting")
logger.info(f"Python: {sys.executable}")
logger.info(f"PyTorch: {torch.__version__}")
logger.info(f"CUDA available: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    logger.info(f"GPU: {torch.cuda.get_device_name(0)}")

# Auto-detect VRAM profile at startup (also populates ALL_PROFILES)
ACTIVE_PROFILE: VRAMProfile = detect_vram_profile()
_ensure_profiles()


def get_fp8_native_quant():
    """Get a quantization policy that preserves the checkpoint's native mixed FP8/BF16 format.

    The FP8 checkpoints store blocks 1-42 as float8_e4m3fn (already quantized) and
    blocks 0, 43-47 as bfloat16 (full precision). The naive fp8_cast policy incorrectly
    downcasts ALL blocks to FP8, corrupting the boundary blocks (~18% relative error)
    and producing noisy output.

    This policy instead:
      1. Drops weight_scale/input_scale keys (all 1.0, not needed for dequantization)
      2. Preserves original dtypes (no downcast)
      3. Upcasts FP8 weights to BF16 on-the-fly during inference
    """
    from ltx_core.quantization import QuantizationPolicy
    from ltx_core.quantization.fp8_cast import UPCAST_DURING_INFERENCE
    from ltx_core.loader.sd_ops import SDOps

    def _drop_key(key, value):
        return []

    drop_scales_ops = (
        SDOps("DROP_FP8_SCALE_KEYS")
        .with_kv_operation(operation=_drop_key, key_suffix=".weight_scale")
        .with_kv_operation(operation=_drop_key, key_suffix=".input_scale")
    )

    return QuantizationPolicy(sd_ops=drop_scales_ops, module_ops=(UPCAST_DURING_INFERENCE,))

# ============================================================================
# Path Configuration
# ============================================================================
MODELS_DIR = Path(__file__).parent / "models"
LORAS_DIR = MODELS_DIR / "loras"
OUTPUTS_DIR = Path(__file__).parent / "outputs"
OUTPUTS_DIR.mkdir(exist_ok=True)

# Model paths
DISTILLED_FP8_CHECKPOINT = str(MODELS_DIR / "ltx-2-19b-distilled-fp8.safetensors")
DEV_FP8_CHECKPOINT = str(MODELS_DIR / "ltx-2-19b-dev-fp8.safetensors")
SPATIAL_UPSAMPLER = str(MODELS_DIR / "ltx-2-spatial-upscaler-x2-1.0.safetensors")
DISTILLED_LORA = str(MODELS_DIR / "ltx-2-19b-distilled-lora-384.safetensors")
GEMMA_ROOT = str(MODELS_DIR / "gemma")

# Camera Control LoRAs
CAMERA_LORAS = {
    "None": None,
    "Dolly In": "ltx-2-19b-lora-camera-control-dolly-in.safetensors",
    "Dolly Out": "ltx-2-19b-lora-camera-control-dolly-out.safetensors",
    "Dolly Left": "ltx-2-19b-lora-camera-control-dolly-left.safetensors",
    "Dolly Right": "ltx-2-19b-lora-camera-control-dolly-right.safetensors",
    "Jib Up": "ltx-2-19b-lora-camera-control-jib-up.safetensors",
    "Jib Down": "ltx-2-19b-lora-camera-control-jib-down.safetensors",
    "Static": "ltx-2-19b-lora-camera-control-static.safetensors",
}

# IC-LoRAs
IC_LORAS = {
    "Canny Control": "ltx-2-19b-ic-lora-canny-control.safetensors",
    "Depth Control": "ltx-2-19b-ic-lora-depth-control.safetensors",
    "Detailer": "ltx-2-19b-ic-lora-detailer.safetensors",
    "Pose Control": "ltx-2-19b-ic-lora-pose-control.safetensors",
}

# ============================================================================
# Model Download Registry  (mirrors launch_app.py definitions)
# ============================================================================
GEMMA_DIR = MODELS_DIR / "gemma"
GEMMA_REPO = "google/gemma-3-12b-it-qat-q4_0-unquantized"

# (repo_id, filename, destination_directory)
_MAIN_MODELS = [
    ("Lightricks/ltx-2-19b", "ltx-2-19b-distilled-fp8.safetensors", MODELS_DIR),
    ("Lightricks/ltx-2-19b", "ltx-2-19b-dev-fp8.safetensors", MODELS_DIR),
    ("Lightricks/ltx-2-19b", "ltx-2-spatial-upscaler-x2-1.0.safetensors", MODELS_DIR),
    ("Lightricks/ltx-2-19b", "ltx-2-19b-distilled-lora-384.safetensors", MODELS_DIR),
]

# (repo_id, filename) — all go to LORAS_DIR
_LORA_MODELS = [
    ("Lightricks/LTX-2-19b-IC-LoRA-Canny-Control", "ltx-2-19b-ic-lora-canny-control.safetensors"),
    ("Lightricks/LTX-2-19b-IC-LoRA-Depth-Control", "ltx-2-19b-ic-lora-depth-control.safetensors"),
    ("Lightricks/LTX-2-19b-IC-LoRA-Detailer", "ltx-2-19b-ic-lora-detailer.safetensors"),
    ("Lightricks/LTX-2-19b-IC-LoRA-Pose-Control", "ltx-2-19b-ic-lora-pose-control.safetensors"),
    ("Lightricks/LTX-2-19b-LoRA-Camera-Control-Dolly-In", "ltx-2-19b-lora-camera-control-dolly-in.safetensors"),
    ("Lightricks/LTX-2-19b-LoRA-Camera-Control-Dolly-Left", "ltx-2-19b-lora-camera-control-dolly-left.safetensors"),
    ("Lightricks/LTX-2-19b-LoRA-Camera-Control-Dolly-Out", "ltx-2-19b-lora-camera-control-dolly-out.safetensors"),
    ("Lightricks/LTX-2-19b-LoRA-Camera-Control-Dolly-Right", "ltx-2-19b-lora-camera-control-dolly-right.safetensors"),
    ("Lightricks/LTX-2-19b-LoRA-Camera-Control-Jib-Down", "ltx-2-19b-lora-camera-control-jib-down.safetensors"),
    ("Lightricks/LTX-2-19b-LoRA-Camera-Control-Jib-Up", "ltx-2-19b-lora-camera-control-jib-up.safetensors"),
    ("Lightricks/LTX-2-19b-LoRA-Camera-Control-Static", "ltx-2-19b-lora-camera-control-static.safetensors"),
]


def get_missing_models() -> list[tuple[str, str, str]]:
    """Return list of (group, repo, filename) for models not yet downloaded."""
    missing = []
    for repo, filename, dest in _MAIN_MODELS:
        if not (dest / filename).exists():
            missing.append(("main", repo, filename))
    gemma_index = GEMMA_DIR / "model.safetensors.index.json"
    if not gemma_index.exists():
        missing.append(("gemma", GEMMA_REPO, "all"))
    for repo, filename in _LORA_MODELS:
        if not (LORAS_DIR / filename).exists():
            missing.append(("lora", repo, filename))
    return missing


def download_all_models(progress=gr.Progress()):
    """Download every missing model from HuggingFace.

    Designed to be called as a Gradio event handler so the user sees
    real-time progress in the UI.  Returns a status string when done.
    """
    try:
        from huggingface_hub import hf_hub_download, snapshot_download
    except ImportError:
        raise gr.Error(
            "huggingface_hub is not installed.\n"
            "Run BUILD.bat to set up the environment, or install manually:\n"
            "  pip install huggingface-hub"
        )

    missing = get_missing_models()
    if not missing:
        return "✅ All models are already downloaded. Ready to generate!"

    # Ensure directories exist
    MODELS_DIR.mkdir(exist_ok=True)
    LORAS_DIR.mkdir(parents=True, exist_ok=True)
    GEMMA_DIR.mkdir(parents=True, exist_ok=True)

    total = len(missing)
    success = 0
    errors = []

    for i, (group, repo, filename) in enumerate(missing):
        label = filename if filename != "all" else "Gemma text encoder (~25 GB)"
        progress((i / total), desc=f"Downloading {label} ({i+1}/{total})...")
        logger.info(f"Downloading {label} from {repo}...")

        try:
            if group == "gemma":
                snapshot_download(
                    repo_id=repo,
                    local_dir=str(GEMMA_DIR),
                    local_dir_use_symlinks=False,
                )
            elif group == "main":
                hf_hub_download(
                    repo_id=repo,
                    filename=filename,
                    local_dir=str(MODELS_DIR),
                    local_dir_use_symlinks=False,
                )
            elif group == "lora":
                hf_hub_download(
                    repo_id=repo,
                    filename=filename,
                    local_dir=str(LORAS_DIR),
                    local_dir_use_symlinks=False,
                )
            success += 1
            logger.info(f"  Downloaded: {label}")
        except Exception as e:
            err = str(e)
            logger.error(f"  Failed to download {label}: {err}")
            if "401" in err or "403" in err or "gated" in err.lower():
                errors.append(
                    f"❌ {label}: AUTH REQUIRED — visit https://huggingface.co/{repo} "
                    f"to accept terms, then run:\n"
                    f"   LTX2_env\\python.exe -m huggingface_hub.cli login"
                )
            else:
                errors.append(f"❌ {label}: {err}")

    progress(1.0, desc="Download complete!")

    # Build result message
    msg = f"Downloaded {success}/{total} models.\n\n"
    if errors:
        msg += "Errors:\n" + "\n".join(errors) + "\n\n"
    if success == total:
        msg += "✅ All models ready! You can now generate videos."
    else:
        msg += "⚠️ Some models failed. Check errors above. You can retry."
    return msg


def _startup_model_banner() -> str:
    """Return a banner message about model readiness for the top of the UI."""
    missing = get_missing_models()
    if not missing:
        return ""  # All good — hide the banner
    n = len(missing)
    # Estimate total download size
    size_hint = "~80 GB"
    return (
        f"### ⚠️ {n} model file(s) not found\n"
        f"This is normal on first run. Go to the **⚙️ Status** tab and click "
        f"**📥 Download All Models** to fetch them from HuggingFace ({size_hint}).\n"
        f"Generation will not work until models are downloaded."
    )


# ============================================================================
# Global State & Cancellation
# ============================================================================
current_pipeline = {"name": None, "instance": None}
_cancel_event = threading.Event()  # Set when user requests cancellation
_generation_lock = threading.Lock()  # Prevent double-submit


def request_cancel():
    """Signal the current generation to stop."""
    _cancel_event.set()
    logger.info("Cancellation requested by user.")
    return "Cancelling... please wait for the current step to finish."


def is_cancelled() -> bool:
    """Check if cancellation was requested."""
    return _cancel_event.is_set()


def cleanup_gpu():
    """Aggressively free GPU memory.

    Deletes any pipeline stored in current_pipeline, then runs gc.collect()
    and empties the CUDA cache. Pipeline runners should assign their pipeline
    to current_pipeline["instance"] after creation so this cleanup is effective.
    """
    if current_pipeline["instance"] is not None:
        try:
            del current_pipeline["instance"]
        except Exception:
            pass
        current_pipeline["instance"] = None
        current_pipeline["name"] = None
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.synchronize()


def get_output_path(prefix="ltx2"):
    """Generate a timestamped output path."""
    ts = time.strftime("%Y%m%d_%H%M%S")
    return str(OUTPUTS_DIR / f"{prefix}_{ts}.mp4")


# ============================================================================
# Input Validation
# ============================================================================
def _validate_generation_params(height, width, num_frames, prompt, vram_profile_name):
    """Validate common generation parameters before starting expensive GPU work.

    Raises gr.Error with a user-friendly message if anything is wrong.
    """
    if not prompt or not prompt.strip():
        raise gr.Error("Please enter a prompt describing your video.")

    h, w, f = int(height), int(width), int(num_frames)

    if h < 256 or w < 256:
        raise gr.Error(f"Resolution too small: {w}x{h}. Minimum is 256x256.")
    if h > 1536 or w > 1536:
        raise gr.Error(f"Resolution too large: {w}x{h}. Maximum is 1536x1536.")
    if h % 64 != 0 or w % 64 != 0:
        raise gr.Error(f"Resolution {w}x{h} must be divisible by 64.")
    if f < 9:
        raise gr.Error(f"Need at least 9 frames (got {f}).")
    if (f - 1) % 8 != 0:
        raise gr.Error(f"Frames must be 8K+1 (e.g. 9, 17, 25, ...). Got {f}.")

    profile = get_profile_by_name(vram_profile_name)
    max_f = max_frames_for_resolution(w, h, profile)
    if f > max_f:
        raise gr.Error(
            f"Too many frames ({f}) for {w}x{h} on {profile.name}. "
            f"Maximum is {max_f}. Reduce resolution or frame count."
        )


# ============================================================================
# Generation Metadata / History
# ============================================================================
HISTORY_FILE = OUTPUTS_DIR / "generation_history.jsonl"


def _save_generation_metadata(output_path: str, pipeline_name: str, params: dict, elapsed: float):
    """Append generation metadata to history file."""
    try:
        entry = {
            "timestamp": datetime.now().isoformat(),
            "file": os.path.basename(output_path),
            "pipeline": pipeline_name,
            "elapsed_seconds": round(elapsed, 1),
            "params": {k: str(v) for k, v in params.items() if k != "progress"},
        }
        with open(HISTORY_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception as e:
        logger.warning(f"Failed to save generation metadata: {e}")


def _load_generation_history(limit: int = 50) -> list[dict]:
    """Load recent generation history."""
    if not HISTORY_FILE.exists():
        return []
    try:
        lines = HISTORY_FILE.read_text(encoding="utf-8").strip().split("\n")
        entries = [json.loads(line) for line in lines[-limit:]]
        entries.reverse()
        return entries
    except Exception:
        return []


# ============================================================================
# Safe Generation Wrapper
# ============================================================================
def safe_generate(pipeline_name: str):
    """Decorator that wraps pipeline runners with error handling, timing, and cleanup.

    Handles:
    - CUDA OOM with helpful recovery message
    - Cancellation checks
    - Automatic GPU cleanup on error
    - Generation timing and logging
    - Thread safety (prevents double-submit)
    """
    def decorator(fn):
        def wrapper(*args, **kwargs):
            if not _generation_lock.acquire(blocking=False):
                raise gr.Error(
                    "A generation is already in progress. Please wait for it to finish, "
                    "or click Cancel."
                )
            _cancel_event.clear()
            start_time = time.time()
            logger.info(f"Starting {pipeline_name} generation...")
            try:
                result = fn(*args, **kwargs)
                elapsed = time.time() - start_time
                logger.info(f"{pipeline_name} completed in {elapsed:.1f}s -> {result}")

                # Save metadata for history
                _save_generation_metadata(
                    result, pipeline_name,
                    {"prompt": args[0] if args else ""},
                    elapsed,
                )
                return result

            except (gr.Error, KeyboardInterrupt):
                raise  # Re-raise Gradio errors as-is (user-facing)

            except torch.cuda.OutOfMemoryError:
                cleanup_gpu()
                logger.error(f"{pipeline_name} failed with CUDA OOM", exc_info=True)
                raise gr.Error(
                    "Out of GPU memory! Try:\n"
                    "1. Reduce resolution or frame count\n"
                    "2. Enable 'Disable Audio' to save ~2 GB\n"
                    "3. Select a lower VRAM profile\n"
                    "4. Close other GPU applications"
                )

            except Exception as e:
                cleanup_gpu()
                error_msg = str(e)
                logger.error(f"{pipeline_name} failed: {error_msg}", exc_info=True)

                # Provide user-friendly messages for common errors
                if "No such file" in error_msg or "not found" in error_msg.lower():
                    raise gr.Error(
                        f"Model file not found. Please check the Status tab to verify "
                        f"all models are downloaded.\n\nDetails: {error_msg}"
                    )
                elif "CUDA" in error_msg or "cuda" in error_msg:
                    raise gr.Error(
                        f"GPU error. Try restarting the app.\n\nDetails: {error_msg}"
                    )
                else:
                    raise gr.Error(
                        f"Generation failed: {error_msg}\n\n"
                        f"Check the Logs tab for full details."
                    )
            finally:
                _generation_lock.release()

        return wrapper
    return decorator


def check_models_exist():
    """Check which models are available."""
    status = []
    checks = [
        ("Distilled FP8 Checkpoint", DISTILLED_FP8_CHECKPOINT),
        ("Dev FP8 Checkpoint (for LoRAs)", DEV_FP8_CHECKPOINT),
        ("Spatial Upsampler", SPATIAL_UPSAMPLER),
        ("Distilled LoRA (for Stage 2)", DISTILLED_LORA),
        ("Gemma Text Encoder", GEMMA_ROOT),
    ]
    for name, path in checks:
        exists = Path(path).exists()
        status.append(f"{'✅' if exists else '❌'} {name}: {path}")

    # Check LoRAs
    for name, filename in {**CAMERA_LORAS, **IC_LORAS}.items():
        if filename is None:
            continue
        path = LORAS_DIR / filename
        exists = path.exists()
        status.append(f"{'✅' if exists else '❌'} LoRA - {name}: {path}")

    return "\n".join(status)


# ============================================================================
# Pipeline Runners
# ============================================================================

@safe_generate("Distilled Pipeline")
def run_distilled_pipeline(
    prompt, seed, height, width, num_frames, frame_rate,
    image_path, image_frame_idx, image_strength,
    camera_lora, camera_lora_strength,
    enhance_prompt, vram_profile_name, disable_audio,
    progress=gr.Progress()
):
    """Run the DistilledPipeline - fastest inference."""
    _validate_generation_params(height, width, num_frames, prompt, vram_profile_name)

    from ltx_core.loader import LTXV_LORA_COMFY_RENAMING_MAP, LoraPathStrengthAndSDOps
    from ltx_core.model.video_vae import TilingConfig, get_video_chunks_number
    from ltx_pipelines.distilled import DistilledPipeline
    from ltx_pipelines.utils.constants import AUDIO_SAMPLE_RATE
    from ltx_pipelines.utils.media_io import encode_video

    profile = get_profile_by_name(vram_profile_name)
    cleanup_gpu()
    progress(0.05, desc=f"Loading models ({profile.name})...")

    loras = []
    if camera_lora != "None" and CAMERA_LORAS.get(camera_lora):
        lora_path = str(LORAS_DIR / CAMERA_LORAS[camera_lora])
        if Path(lora_path).exists():
            loras.append(LoraPathStrengthAndSDOps(lora_path, camera_lora_strength, LTXV_LORA_COMFY_RENAMING_MAP))

    # Use dev checkpoint when LoRAs are applied, distilled otherwise
    ckpt = DEV_FP8_CHECKPOINT if (loras and Path(DEV_FP8_CHECKPOINT).exists()) else DISTILLED_FP8_CHECKPOINT
    pipeline = DistilledPipeline(
        checkpoint_path=ckpt,
        gemma_root=GEMMA_ROOT,
        spatial_upsampler_path=SPATIAL_UPSAMPLER,
        loras=loras,
        quantization=get_fp8_native_quant(),
    )
    current_pipeline["instance"] = pipeline
    current_pipeline["name"] = "distilled"
    # Apply VRAM offloading from profile
    pipeline.model_ledger.transformer_max_memory = profile.transformer_max_memory
    pipeline.model_ledger.text_encoder_max_memory = profile.text_encoder_max_memory
    pipeline.model_ledger.upsampler_max_memory = profile.upsampler_max_memory

    images = []
    if image_path is not None and image_path != "":
        images.append((image_path, int(image_frame_idx), float(image_strength)))

    tiling_config = TilingConfig.default()
    video_chunks_number = get_video_chunks_number(int(num_frames), tiling_config)

    progress(0.2, desc="Generating video (Stage 1)...")

    with torch.inference_mode():
        video, audio = pipeline(
            prompt=prompt,
            seed=int(seed),
            height=int(height),
            width=int(width),
            num_frames=int(num_frames),
            frame_rate=float(frame_rate),
            images=images,
            tiling_config=tiling_config,
            enhance_prompt=enhance_prompt,
        )

    progress(0.9, desc="Encoding video...")
    output_path = get_output_path("distilled")

    if disable_audio:
        audio = None

    encode_video(
        video=video,
        fps=float(frame_rate),
        audio=audio,
        audio_sample_rate=AUDIO_SAMPLE_RATE,
        output_path=output_path,
        video_chunks_number=video_chunks_number,
    )

    cleanup_gpu()
    progress(1.0, desc="Done!")
    return output_path


@safe_generate("Two-Stage Pipeline")
def run_two_stage_pipeline(
    prompt, negative_prompt, seed, height, width, num_frames, frame_rate,
    num_inference_steps,
    image_path, image_frame_idx, image_strength,
    camera_lora, camera_lora_strength,
    video_cfg_scale, video_stg_scale, video_rescale_scale,
    audio_cfg_scale, audio_stg_scale, audio_rescale_scale,
    modality_scale,
    enhance_prompt, vram_profile_name, disable_audio,
    progress=gr.Progress()
):
    """Run the TI2VidTwoStagesPipeline - production quality."""
    _validate_generation_params(height, width, num_frames, prompt, vram_profile_name)

    from ltx_core.components.guiders import MultiModalGuiderParams
    from ltx_core.loader import LTXV_LORA_COMFY_RENAMING_MAP, LoraPathStrengthAndSDOps
    from ltx_core.model.video_vae import TilingConfig, get_video_chunks_number
    from ltx_pipelines.ti2vid_two_stages import TI2VidTwoStagesPipeline
    from ltx_pipelines.utils.constants import AUDIO_SAMPLE_RATE
    from ltx_pipelines.utils.media_io import encode_video

    profile = get_profile_by_name(vram_profile_name)
    cleanup_gpu()
    progress(0.05, desc=f"Loading models ({profile.name})...")

    distilled_lora_list = [
        LoraPathStrengthAndSDOps(DISTILLED_LORA, 0.8, LTXV_LORA_COMFY_RENAMING_MAP),
    ]
    loras = []
    if camera_lora != "None" and CAMERA_LORAS.get(camera_lora):
        lora_path = str(LORAS_DIR / CAMERA_LORAS[camera_lora])
        if Path(lora_path).exists():
            loras.append(LoraPathStrengthAndSDOps(lora_path, camera_lora_strength, LTXV_LORA_COMFY_RENAMING_MAP))

    # Two-stage always uses dev checkpoint (needs distilled LoRA for stage 2)
    ckpt = DEV_FP8_CHECKPOINT if Path(DEV_FP8_CHECKPOINT).exists() else DISTILLED_FP8_CHECKPOINT
    pipeline = TI2VidTwoStagesPipeline(
        checkpoint_path=ckpt,
        distilled_lora=distilled_lora_list,
        spatial_upsampler_path=SPATIAL_UPSAMPLER,
        gemma_root=GEMMA_ROOT,
        loras=loras,
        quantization=get_fp8_native_quant(),
    )
    current_pipeline["instance"] = pipeline
    current_pipeline["name"] = "twostage"
    # Apply VRAM offloading — TI2VidTwoStagesPipeline has TWO model ledgers
    for ledger in (pipeline.stage_1_model_ledger, pipeline.stage_2_model_ledger):
        ledger.transformer_max_memory = profile.transformer_max_memory
        ledger.text_encoder_max_memory = profile.text_encoder_max_memory
        ledger.upsampler_max_memory = profile.upsampler_max_memory

    images = []
    if image_path is not None and image_path != "":
        images.append((image_path, int(image_frame_idx), float(image_strength)))

    video_guider_params = MultiModalGuiderParams(
        cfg_scale=float(video_cfg_scale),
        stg_scale=float(video_stg_scale),
        rescale_scale=float(video_rescale_scale),
        modality_scale=float(modality_scale),
        skip_step=0,
        stg_blocks=[29],
    )
    audio_guider_params = MultiModalGuiderParams(
        cfg_scale=float(audio_cfg_scale),
        stg_scale=float(audio_stg_scale),
        rescale_scale=float(audio_rescale_scale),
        modality_scale=float(modality_scale),
        skip_step=0,
        stg_blocks=[29],
    )

    tiling_config = TilingConfig.default()
    video_chunks_number = get_video_chunks_number(int(num_frames), tiling_config)

    progress(0.15, desc="Generating video (Stage 1 - may take a while)...")

    with torch.inference_mode():
        video, audio = pipeline(
            prompt=prompt,
            negative_prompt=negative_prompt,
            seed=int(seed),
            height=int(height),
            width=int(width),
            num_frames=int(num_frames),
            frame_rate=float(frame_rate),
            num_inference_steps=int(num_inference_steps),
            video_guider_params=video_guider_params,
            audio_guider_params=audio_guider_params,
            images=images,
            tiling_config=tiling_config,
            enhance_prompt=enhance_prompt,
        )

    progress(0.9, desc="Encoding video...")
    output_path = get_output_path("twostage")

    if disable_audio:
        audio = None

    encode_video(
        video=video,
        fps=float(frame_rate),
        audio=audio,
        audio_sample_rate=AUDIO_SAMPLE_RATE,
        output_path=output_path,
        video_chunks_number=video_chunks_number,
    )

    cleanup_gpu()
    progress(1.0, desc="Done!")
    return output_path


@safe_generate("IC-LoRA Pipeline")
def run_ic_lora_pipeline(
    prompt, seed, height, width, num_frames, frame_rate,
    image_path, image_frame_idx, image_strength,
    video_conditioning_path, video_conditioning_strength,
    ic_lora_type, ic_lora_strength,
    auto_preprocess,
    enhance_prompt, vram_profile_name, disable_audio,
    progress=gr.Progress()
):
    """Run the ICLoraPipeline - video-to-video transformations."""
    _validate_generation_params(height, width, num_frames, prompt, vram_profile_name)

    if not video_conditioning_path and ic_lora_type != "Detailer":
        raise gr.Error("Please upload a video for IC-LoRA control.")

    from ltx_core.loader import LTXV_LORA_COMFY_RENAMING_MAP, LoraPathStrengthAndSDOps
    from ltx_core.model.video_vae import TilingConfig, get_video_chunks_number
    from ltx_pipelines.ic_lora import ICLoraPipeline
    from ltx_pipelines.utils.constants import AUDIO_SAMPLE_RATE
    from ltx_pipelines.utils.media_io import encode_video
    from video_preprocessors import preprocess_for_control

    profile = get_profile_by_name(vram_profile_name)
    cleanup_gpu()

    # Auto-preprocess the raw video into the control signal format
    if auto_preprocess and video_conditioning_path and ic_lora_type != "Detailer":
        progress(0.02, desc=f"Preprocessing video ({ic_lora_type})...")
        video_conditioning_path = preprocess_for_control(
            video_conditioning_path,
            ic_lora_type,
        )

    progress(0.05, desc=f"Loading models ({profile.name})...")

    loras = []
    if ic_lora_type in IC_LORAS:
        lora_path = str(LORAS_DIR / IC_LORAS[ic_lora_type])
        if Path(lora_path).exists():
            loras.append(LoraPathStrengthAndSDOps(lora_path, ic_lora_strength, LTXV_LORA_COMFY_RENAMING_MAP))

    # IC-LoRA always uses dev checkpoint
    ckpt = DEV_FP8_CHECKPOINT if Path(DEV_FP8_CHECKPOINT).exists() else DISTILLED_FP8_CHECKPOINT
    pipeline = ICLoraPipeline(
        checkpoint_path=ckpt,
        spatial_upsampler_path=SPATIAL_UPSAMPLER,
        gemma_root=GEMMA_ROOT,
        loras=loras,
        quantization=get_fp8_native_quant(),
    )
    current_pipeline["instance"] = pipeline
    current_pipeline["name"] = "iclora"
    # Apply VRAM offloading — ICLoraPipeline has TWO model ledgers
    for ledger in (pipeline.stage_1_model_ledger, pipeline.stage_2_model_ledger):
        ledger.transformer_max_memory = profile.transformer_max_memory
        ledger.text_encoder_max_memory = profile.text_encoder_max_memory
        ledger.upsampler_max_memory = profile.upsampler_max_memory

    images = []
    if image_path is not None and image_path != "":
        images.append((image_path, int(image_frame_idx), float(image_strength)))

    video_conditioning = []
    if video_conditioning_path is not None and video_conditioning_path != "":
        video_conditioning.append((video_conditioning_path, float(video_conditioning_strength)))

    tiling_config = TilingConfig.default()
    video_chunks_number = get_video_chunks_number(int(num_frames), tiling_config)

    progress(0.15, desc="Generating video with IC-LoRA...")

    with torch.inference_mode():
        video, audio = pipeline(
            prompt=prompt,
            seed=int(seed),
            height=int(height),
            width=int(width),
            num_frames=int(num_frames),
            frame_rate=float(frame_rate),
            images=images,
            video_conditioning=video_conditioning,
            tiling_config=tiling_config,
            enhance_prompt=enhance_prompt,
        )

    progress(0.9, desc="Encoding video...")
    output_path = get_output_path("iclora")

    if disable_audio:
        audio = None

    encode_video(
        video=video,
        fps=float(frame_rate),
        audio=audio,
        audio_sample_rate=AUDIO_SAMPLE_RATE,
        output_path=output_path,
        video_chunks_number=video_chunks_number,
    )

    cleanup_gpu()
    progress(1.0, desc="Done!")
    return output_path


@safe_generate("Keyframe Interpolation")
def run_keyframe_pipeline(
    prompt, negative_prompt, seed, height, width, num_frames, frame_rate,
    num_inference_steps,
    keyframe1_path, keyframe1_frame_idx, keyframe1_strength,
    keyframe2_path, keyframe2_frame_idx, keyframe2_strength,
    camera_lora, camera_lora_strength,
    video_cfg_scale, video_stg_scale, video_rescale_scale,
    audio_cfg_scale, audio_stg_scale, audio_rescale_scale,
    modality_scale,
    enhance_prompt, vram_profile_name, disable_audio,
    progress=gr.Progress()
):
    """Run the KeyframeInterpolationPipeline."""
    _validate_generation_params(height, width, num_frames, prompt, vram_profile_name)

    from ltx_core.components.guiders import MultiModalGuiderParams
    from ltx_core.loader import LTXV_LORA_COMFY_RENAMING_MAP, LoraPathStrengthAndSDOps
    from ltx_core.model.video_vae import TilingConfig, get_video_chunks_number
    from ltx_pipelines.keyframe_interpolation import KeyframeInterpolationPipeline
    from ltx_pipelines.utils.constants import AUDIO_SAMPLE_RATE
    from ltx_pipelines.utils.media_io import encode_video

    profile = get_profile_by_name(vram_profile_name)
    cleanup_gpu()
    progress(0.05, desc=f"Loading models ({profile.name})...")

    distilled_lora_list = [
        LoraPathStrengthAndSDOps(DISTILLED_LORA, 0.8, LTXV_LORA_COMFY_RENAMING_MAP),
    ]
    loras = []
    if camera_lora != "None" and CAMERA_LORAS.get(camera_lora):
        lora_path = str(LORAS_DIR / CAMERA_LORAS[camera_lora])
        if Path(lora_path).exists():
            loras.append(LoraPathStrengthAndSDOps(lora_path, camera_lora_strength, LTXV_LORA_COMFY_RENAMING_MAP))

    # Keyframe interpolation uses dev checkpoint (needs distilled LoRA)
    ckpt = DEV_FP8_CHECKPOINT if Path(DEV_FP8_CHECKPOINT).exists() else DISTILLED_FP8_CHECKPOINT
    pipeline = KeyframeInterpolationPipeline(
        checkpoint_path=ckpt,
        distilled_lora=distilled_lora_list,
        spatial_upsampler_path=SPATIAL_UPSAMPLER,
        gemma_root=GEMMA_ROOT,
        loras=loras,
        quantization=get_fp8_native_quant(),
    )
    current_pipeline["instance"] = pipeline
    current_pipeline["name"] = "keyframe"
    # Apply VRAM offloading — KeyframeInterpolationPipeline has TWO model ledgers
    for ledger in (pipeline.stage_1_model_ledger, pipeline.stage_2_model_ledger):
        ledger.transformer_max_memory = profile.transformer_max_memory
        ledger.text_encoder_max_memory = profile.text_encoder_max_memory
        ledger.upsampler_max_memory = profile.upsampler_max_memory

    images = []
    if keyframe1_path is not None and keyframe1_path != "":
        images.append((keyframe1_path, int(keyframe1_frame_idx), float(keyframe1_strength)))
    if keyframe2_path is not None and keyframe2_path != "":
        images.append((keyframe2_path, int(keyframe2_frame_idx), float(keyframe2_strength)))

    video_guider_params = MultiModalGuiderParams(
        cfg_scale=float(video_cfg_scale),
        stg_scale=float(video_stg_scale),
        rescale_scale=float(video_rescale_scale),
        modality_scale=float(modality_scale),
        skip_step=0,
        stg_blocks=[29],
    )
    audio_guider_params = MultiModalGuiderParams(
        cfg_scale=float(audio_cfg_scale),
        stg_scale=float(audio_stg_scale),
        rescale_scale=float(audio_rescale_scale),
        modality_scale=float(modality_scale),
        skip_step=0,
        stg_blocks=[29],
    )

    tiling_config = TilingConfig.default()
    video_chunks_number = get_video_chunks_number(int(num_frames), tiling_config)

    progress(0.15, desc="Generating keyframe interpolation...")

    with torch.inference_mode():
        video, audio = pipeline(
            prompt=prompt,
            negative_prompt=negative_prompt,
            seed=int(seed),
            height=int(height),
            width=int(width),
            num_frames=int(num_frames),
            frame_rate=float(frame_rate),
            num_inference_steps=int(num_inference_steps),
            video_guider_params=video_guider_params,
            audio_guider_params=audio_guider_params,
            images=images,
            tiling_config=tiling_config,
            enhance_prompt=enhance_prompt,
        )

    progress(0.9, desc="Encoding video...")
    output_path = get_output_path("keyframe")

    if disable_audio:
        audio = None

    encode_video(
        video=video,
        fps=float(frame_rate),
        audio=audio,
        audio_sample_rate=AUDIO_SAMPLE_RATE,
        output_path=output_path,
        video_chunks_number=video_chunks_number,
    )

    cleanup_gpu()
    progress(1.0, desc="Done!")
    return output_path


# ============================================================================
# Default Values & Template Libraries
# ============================================================================
DEFAULT_NEGATIVE_PROMPT = (
    "blurry, out of focus, overexposed, underexposed, low contrast, washed out colors, excessive noise, "
    "grainy texture, poor lighting, flickering, motion blur, distorted proportions, unnatural skin tones, "
    "deformed facial features, asymmetrical face, missing facial features, extra limbs, disfigured hands, "
    "wrong hand count, artifacts around text, inconsistent perspective, camera shake, incorrect depth of "
    "field, background too sharp, background clutter, distracting reflections, harsh shadows, inconsistent "
    "lighting direction, color banding, cartoonish rendering, 3D CGI look, unrealistic materials, uncanny "
    "valley effect"
)

# -- Aspect Ratio Presets (label -> width, height) --
# IMPORTANT: All values MUST be divisible by 64 (model requirement).
ASPECT_RATIO_PRESETS = {
    "Custom": None,
    "16:9  Cinematic (1536x896)": (1536, 896),
    "16:9  HD (1280x704)": (1280, 704),
    "9:16  Portrait (896x1536)": (896, 1536),
    "9:16  Mobile (704x1280)": (704, 1280),
    "1:1   Square (1024x1024)": (1024, 1024),
    "4:3   Classic (1024x768)": (1024, 768),
    "3:4   Portrait Classic (768x1024)": (768, 1024),
    "3:2   Photo (1536x1024)": (1536, 1024),
    "2:3   Photo Portrait (1024x1536)": (1024, 1536),
    "21:9  Ultrawide (1536x640)": (1536, 640),
}

# -- Prompt Template Library --
PROMPT_TEMPLATES = {
    "(Select a template)": "",
    "--- Nature & Landscapes ---": "",
    "Golden Hour Mountains": "A cinematic shot of a vast mountain landscape at golden hour, the camera slowly panning across snow-capped peaks, warm light casting long shadows across alpine meadows, wisps of clouds drifting between the summits, 4K, photorealistic.",
    "Ocean Waves": "Aerial drone shot of turquoise ocean waves crashing on a pristine white sand beach, crystal clear water, golden sunlight reflecting off the surface, seabirds gliding overhead, serene atmosphere.",
    "Forest Rain": "A serene forest scene during gentle rain, raindrops falling on emerald leaves, misty atmosphere, soft diffused lighting filtering through the canopy, peaceful ambient mood, slow camera dolly forward.",
    "Northern Lights": "Time-lapse of the Aurora Borealis dancing across a starry Arctic sky, vivid greens and purples reflected in a still lake below, snow-covered pine trees silhouetted in the foreground, cinematic.",
    "--- People & Characters ---": "",
    "Portrait Closeup": "A cinematic close-up portrait of a person looking directly at the camera, soft studio lighting, shallow depth of field, neutral background with subtle bokeh, natural skin tones, photorealistic detail.",
    "Street Scene": "A person walking through a neon-lit city street at night, rain-slicked pavement reflecting colorful signs, cinematic shallow depth of field, moody atmosphere, urban photography style.",
    "Dancing": "A graceful dancer performing in a grand ballroom, flowing silk dress catching the light, marble floors reflecting golden chandeliers, cinematic slow-motion, warm dramatic lighting.",
    "--- Animals ---": "",
    "Dog on Beach": "A golden retriever playing fetch on a sunny beach, waves crashing in the background, bright blue sky with fluffy white clouds, the dog runs joyfully across the sand, its fur gleaming in the sunlight.",
    "Wildlife": "A majestic eagle soaring through a mountain valley, wings spread wide, golden morning light illuminating its feathers, slow motion, cinematic aerial perspective, breathtaking scenery below.",
    "--- Abstract & Artistic ---": "",
    "Ink in Water": "Macro shot of vibrant colored inks swirling and mixing in crystal clear water, deep blues merging with rich golds, abstract fluid dynamics, mesmerizing patterns, studio lighting, slow motion.",
    "Neon Abstract": "Abstract flowing neon light trails in a dark void, vibrant electric blues and magentas intertwining, smooth organic motion, futuristic digital art style, high contrast.",
    "--- Sci-Fi & Fantasy ---": "",
    "Space Station": "A massive space station orbiting Earth, sunlight glinting off solar panels, stars twinkling in the background, Earth's curvature visible below with city lights, cinematic wide shot, photorealistic CGI.",
    "Fantasy Castle": "An enchanted castle on a floating island above the clouds, waterfalls cascading into the mist below, golden sunset light, dragons circling distant peaks, epic fantasy atmosphere, detailed matte painting style.",
}

# -- Negative Prompt Presets --
NEGATIVE_PROMPT_PRESETS = {
    "(Select a preset)": "",
    "Standard Quality": DEFAULT_NEGATIVE_PROMPT,
    "Minimal (less restrictive)": "blurry, low quality, distorted, watermark, text overlay",
    "Portrait Focus": "deformed face, extra fingers, mutated hands, bad anatomy, ugly, disfigured, poorly drawn face, extra limbs, missing arms, blurry, low resolution",
    "Cinematic": "shaky cam, low resolution, amateur, overexposed highlights, crushed blacks, lens flare, motion blur, noise, grain, color banding, CGI look",
    "Anime/Artistic": "photorealistic, photograph, 3D render, low quality, blurry, distorted, watermark, text, ugly, deformed",
}

import random as _random

def _random_seed():
    """Generate a random seed."""
    return _random.randint(0, 2**31 - 1)


# ============================================================================
# CSS Theme — Futuristic AI Aesthetic v2
# ============================================================================
CUSTOM_CSS = r"""
/* ========================================================
   0. GLOBAL SMOOTHING — everything animates
   ======================================================== */
*, *::before, *::after {
    transition-timing-function: cubic-bezier(.4,0,.2,1);
}

/* ========================================================
   1. DEEP-SPACE BACKGROUND + AURORA
   ======================================================== */
.gradio-container {
    background: #06070b !important;
    position: relative;
    overflow-x: hidden;
}
/* aurora borealis wash */
.gradio-container::before {
    content: '';
    position: fixed; inset: 0;
    background:
        radial-gradient(ellipse 120% 60% at 10% 0%, rgba(56,189,248,0.13) 0%, transparent 60%),
        radial-gradient(ellipse 100% 50% at 90% 10%, rgba(139,92,246,0.11) 0%, transparent 55%),
        radial-gradient(ellipse 80% 80% at 50% 100%, rgba(6,182,212,0.07) 0%, transparent 60%),
        radial-gradient(ellipse 60% 40% at 70% 50%, rgba(244,114,182,0.05) 0%, transparent 50%);
    pointer-events: none; z-index: 0;
    animation: auroraDrift 20s ease-in-out infinite alternate;
}
@keyframes auroraDrift {
    0%   { opacity:.65; filter:hue-rotate(0deg); }
    50%  { opacity:1;   filter:hue-rotate(12deg); }
    100% { opacity:.75; filter:hue-rotate(-8deg); }
}

/* perspective grid — slow diagonal scroll */
.gradio-container::after {
    content: '';
    position: fixed; inset: 0;
    background-image:
        linear-gradient(rgba(56,189,248,0.035) 1px, transparent 1px),
        linear-gradient(90deg, rgba(56,189,248,0.035) 1px, transparent 1px);
    background-size: 48px 48px;
    pointer-events: none; z-index: 0;
    animation: gridScroll 40s linear infinite;
    mask-image: linear-gradient(to bottom, transparent 0%, black 15%, black 85%, transparent 100%);
    -webkit-mask-image: linear-gradient(to bottom, transparent 0%, black 15%, black 85%, transparent 100%);
}
@keyframes gridScroll {
    0%   { transform: perspective(500px) rotateX(2deg); background-position: 0 0; }
    100% { transform: perspective(500px) rotateX(2deg); background-position: 48px 48px; }
}

/* ========================================================
   2. CSS-ONLY PARTICLE FIELD  (box-shadow trick)
   ======================================================== */
.particles, .particles2 {
    position: fixed; inset: 0;
    pointer-events: none; z-index: 0;
    overflow: hidden;
}
.particles::before, .particles2::before {
    content: '';
    position: absolute;
    width: 2px; height: 2px;
    border-radius: 50%;
}
.particles::before {
    /* ~40 random-looking dots via box-shadow */
    box-shadow:
        120px  80px 0 0 rgba(56,189,248,.35),  250px 160px 0 0 rgba(139,92,246,.3),
        400px  50px 0 0 rgba(244,114,182,.25),  550px 200px 0 0 rgba(56,189,248,.3),
        700px 120px 0 0 rgba(168,85,247,.3),    820px 300px 0 0 rgba(56,189,248,.25),
        960px  70px 0 0 rgba(139,92,246,.35),   1100px 250px 0 0 rgba(244,114,182,.2),
        1250px 100px 0 0 rgba(56,189,248,.3),   150px 350px 0 0 rgba(168,85,247,.25),
        300px 420px 0 0 rgba(56,189,248,.2),    480px 500px 0 0 rgba(139,92,246,.3),
        650px 380px 0 0 rgba(244,114,182,.25),  800px 470px 0 0 rgba(56,189,248,.35),
        950px 550px 0 0 rgba(168,85,247,.2),    1150px 400px 0 0 rgba(139,92,246,.25),
        80px 620px 0 0 rgba(56,189,248,.3),     350px 700px 0 0 rgba(244,114,182,.2),
        520px 650px 0 0 rgba(139,92,246,.3),    750px 720px 0 0 rgba(56,189,248,.25);
    animation: particleFloat 60s linear infinite;
}
.particles2::before {
    box-shadow:
        200px 40px 0 0 rgba(99,102,241,.2),    450px 130px 0 0 rgba(56,189,248,.15),
        680px 220px 0 0 rgba(168,85,247,.2),    900px 60px  0 0 rgba(244,114,182,.15),
        1050px 180px 0 0 rgba(56,189,248,.2),   130px 280px 0 0 rgba(139,92,246,.15),
        380px 360px 0 0 rgba(56,189,248,.2),    600px 440px 0 0 rgba(168,85,247,.15),
        870px 340px 0 0 rgba(244,114,182,.2),   1120px 480px 0 0 rgba(56,189,248,.15),
        250px 560px 0 0 rgba(139,92,246,.2),    500px 600px 0 0 rgba(56,189,248,.15),
        730px 560px 0 0 rgba(168,85,247,.2),    980px 640px 0 0 rgba(244,114,182,.15);
    animation: particleFloat2 80s linear infinite;
}
@keyframes particleFloat  { 0%{transform:translateY(0)}       100%{transform:translateY(-800px)} }
@keyframes particleFloat2 { 0%{transform:translateY(0) translateX(0)} 100%{transform:translateY(-600px) translateX(80px)} }

/* ========================================================
   3. GLOBAL DARK OVERRIDES
   ======================================================== */
.dark, body {
    --body-background-fill: #06070b !important;
    --background-fill-primary: rgba(12,14,22,0.82) !important;
    --background-fill-secondary: rgba(16,18,30,0.78) !important;
    --block-background-fill: rgba(12,14,22,0.65) !important;
    --block-border-color: rgba(56,189,248,0.10) !important;
    --block-label-background-fill: rgba(16,18,30,0.9) !important;
    --border-color-primary: rgba(56,189,248,0.12) !important;
    --input-background-fill: rgba(8,10,18,0.92) !important;
    --body-text-color: #c8d6e5 !important;
    --block-title-text-color: #e2e8f0 !important;
    --block-label-text-color: #94a3b8 !important;
}

/* ========================================================
   4. GLASSMORPHISM PANELS — smooth hover lift
   ======================================================== */
.block, .form, .panel {
    backdrop-filter: blur(20px) saturate(160%) !important;
    -webkit-backdrop-filter: blur(20px) saturate(160%) !important;
    border: 1px solid rgba(56,189,248,0.08) !important;
    border-radius: 14px !important;
    box-shadow: 0 4px 32px rgba(0,0,0,0.35), inset 0 1px 0 rgba(255,255,255,0.03) !important;
    transition: transform .35s ease, box-shadow .35s ease, border-color .35s ease !important;
}
.block:hover, .form:hover {
    border-color: rgba(56,189,248,0.18) !important;
    box-shadow: 0 8px 40px rgba(0,0,0,0.4), 0 0 20px rgba(56,189,248,0.06), inset 0 1px 0 rgba(255,255,255,0.04) !important;
}

/* ========================================================
   5. HERO HEADER — flowing gradient + neon line
   ======================================================== */
.hero-header {
    text-align: center;
    padding: 2.5rem 1rem 1rem;
    position: relative; z-index: 1;
}
.hero-header h1 {
    font-size: 3rem; font-weight: 800;
    background: linear-gradient(90deg, #38bdf8, #818cf8, #c084fc, #f472b6, #38bdf8);
    background-size: 300% 100%;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    letter-spacing: -0.02em; margin: 0;
    animation: titleFlow 6s ease-in-out infinite;
}
@keyframes titleFlow {
    0%   { background-position: 0% 50%; filter: brightness(1); }
    50%  { background-position: 100% 50%; filter: brightness(1.15); }
    100% { background-position: 0% 50%; filter: brightness(1); }
}
.hero-subtitle {
    color: #64748b; font-size: 1.05rem; margin-top: 0.4rem;
    letter-spacing: 0.12em; text-transform: uppercase; font-weight: 400;
}
.hero-badge {
    display: inline-block; margin-top: 0.75rem;
    padding: 0.3rem 1.2rem; font-size: 0.72rem; font-weight: 600;
    color: #38bdf8;
    border: 1px solid rgba(56,189,248,0.3); border-radius: 999px;
    background: rgba(56,189,248,0.06);
    letter-spacing: 0.12em; text-transform: uppercase;
    animation: badgePulse 3s ease-in-out infinite;
}
@keyframes badgePulse {
    0%,100% { box-shadow: 0 0 6px rgba(56,189,248,0.15); }
    50%     { box-shadow: 0 0 24px rgba(56,189,248,0.35), 0 0 48px rgba(56,189,248,0.1); }
}
/* neon separator line under header */
.hero-line {
    width: 220px; height: 2px; margin: 1.2rem auto 0;
    background: linear-gradient(90deg, transparent, #38bdf8, #818cf8, #38bdf8, transparent);
    border-radius: 2px;
    animation: lineGlow 3s ease-in-out infinite alternate;
}
@keyframes lineGlow {
    0%  { opacity:.5; box-shadow: 0 0 8px rgba(56,189,248,0.3); }
    100%{ opacity:1;  box-shadow: 0 0 20px rgba(56,189,248,0.5), 0 0 40px rgba(139,92,246,0.2); }
}

/* ========================================================
   6. TABS — smooth glow transitions
   ======================================================== */
.tabs > .tab-nav > button {
    color: #536179 !important; font-weight: 600 !important; font-size: 0.95rem !important;
    border-bottom: 2px solid transparent !important;
    padding: 0.75rem 1.25rem !important;
    background: transparent !important;
    transition: all .4s ease !important;
    position: relative;
}
.tabs > .tab-nav > button:hover {
    color: #7dd3fc !important;
    background: rgba(56,189,248,0.05) !important;
    text-shadow: 0 0 12px rgba(56,189,248,0.3);
}
.tabs > .tab-nav > button.selected {
    color: #38bdf8 !important;
    border-bottom: 2px solid #38bdf8 !important;
    background: rgba(56,189,248,0.07) !important;
    box-shadow: 0 4px 16px rgba(56,189,248,0.12) !important;
    text-shadow: 0 0 16px rgba(56,189,248,0.4);
}

/* ========================================================
   7. GENERATE BUTTON — animated gradient + electric sweep
   ======================================================== */
button.primary {
    background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 50%, #6366f1 100%) !important;
    background-size: 200% 200% !important;
    border: none !important; color: white !important;
    font-weight: 700 !important; font-size: 1rem !important;
    padding: 0.8rem 2rem !important; border-radius: 12px !important;
    box-shadow: 0 4px 24px rgba(99,102,241,0.35), inset 0 1px 0 rgba(255,255,255,0.1) !important;
    transition: all .4s cubic-bezier(.4,0,.2,1) !important;
    position: relative; overflow: hidden;
    animation: btnGradient 4s ease infinite;
}
@keyframes btnGradient {
    0%,100% { background-position: 0% 50%; }
    50%     { background-position: 100% 50%; }
}
button.primary::before {
    content: ''; position: absolute;
    top: -50%; left: -75%; width: 50%; height: 200%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.18), transparent);
    transform: skewX(-20deg);
    animation: btnSweep 3s ease-in-out infinite;
}
@keyframes btnSweep {
    0%   { left: -75%; }
    100% { left: 125%; }
}
button.primary:hover {
    box-shadow: 0 8px 40px rgba(124,58,237,0.5), 0 0 60px rgba(99,102,241,0.15) !important;
    transform: translateY(-2px) scale(1.02) !important;
    filter: brightness(1.1);
}

button.stop, button[variant="stop"] {
    background: linear-gradient(135deg, #dc2626, #ef4444) !important;
    border: none !important; color: white !important;
    font-weight: 600 !important; border-radius: 12px !important;
    box-shadow: 0 4px 16px rgba(220,38,38,0.25) !important;
    transition: all .35s ease !important;
}
button.stop:hover {
    box-shadow: 0 8px 32px rgba(239,68,68,0.4) !important;
    transform: translateY(-1px) !important;
}

button.secondary {
    background: rgba(20,22,38,0.8) !important;
    border: 1px solid rgba(56,189,248,0.15) !important;
    color: #94a3b8 !important; font-weight: 500 !important;
    border-radius: 10px !important;
    transition: all .35s ease !important;
}
button.secondary:hover {
    border-color: rgba(56,189,248,0.45) !important;
    color: #38bdf8 !important;
    background: rgba(56,189,248,0.07) !important;
    box-shadow: 0 0 20px rgba(56,189,248,0.12) !important;
    transform: translateY(-1px) !important;
}

/* ========================================================
   8. INPUTS — soft glow on focus
   ======================================================== */
textarea, input[type="text"], input[type="number"], .input-text {
    background: rgba(6,8,16,0.85) !important;
    border: 1px solid rgba(56,189,248,0.10) !important;
    color: #e2e8f0 !important; border-radius: 10px !important;
    transition: border-color .4s ease, box-shadow .4s ease !important;
}
textarea:focus, input:focus {
    border-color: rgba(99,102,241,0.50) !important;
    box-shadow: 0 0 0 3px rgba(99,102,241,0.08), 0 0 20px rgba(99,102,241,0.12) !important;
    outline: none !important;
}

/* ========================================================
   9. SLIDERS
   ======================================================== */
input[type="range"] { accent-color: #6366f1 !important; }

/* ========================================================
   10. ACCORDIONS — smooth expand
   ======================================================== */
.accordion {
    border: 1px solid rgba(56,189,248,0.06) !important;
    border-radius: 12px !important;
    background: rgba(10,12,20,0.45) !important;
    backdrop-filter: blur(10px) !important;
    transition: border-color .35s ease !important;
}
.accordion:hover { border-color: rgba(56,189,248,0.14) !important; }
.accordion > .label-wrap { color: #94a3b8 !important; font-weight: 500 !important; transition: color .3s ease !important; }
.accordion > .label-wrap:hover { color: #7dd3fc !important; }

/* ========================================================
   11. DROPDOWN
   ======================================================== */
.dropdown, select {
    background: rgba(10,12,20,0.92) !important;
    border: 1px solid rgba(56,189,248,0.12) !important;
    color: #e2e8f0 !important; border-radius: 10px !important;
    transition: border-color .3s ease !important;
}

/* ========================================================
   12. VIDEO OUTPUT — cinematic border glow
   ======================================================== */
.video-container, video {
    border-radius: 14px !important;
    border: 1px solid rgba(56,189,248,0.08) !important;
    box-shadow: 0 8px 40px rgba(0,0,0,0.5), 0 0 30px rgba(56,189,248,0.04) !important;
    transition: box-shadow .5s ease !important;
}
.video-container:hover, video:hover {
    box-shadow: 0 12px 48px rgba(0,0,0,0.5), 0 0 40px rgba(99,102,241,0.1) !important;
}

/* ========================================================
   13. PROGRESS BAR — animated gradient
   ======================================================== */
.progress-bar {
    background: linear-gradient(90deg, #4f46e5, #7c3aed, #38bdf8, #4f46e5) !important;
    background-size: 300% 100% !important;
    box-shadow: 0 0 16px rgba(99,102,241,0.4) !important;
    border-radius: 6px !important;
    animation: progressShimmer 2s linear infinite;
}
@keyframes progressShimmer { 0%{background-position:0% 50%} 100%{background-position:300% 50%} }

/* ========================================================
   14. MARKDOWN
   ======================================================== */
.prose, .markdown-text, .md { color: #c8d6e5 !important; }
.prose strong { color: #7dd3fc !important; }
.prose h3, .md h3 {
    background: linear-gradient(135deg, #e2e8f0 0%, #38bdf8 50%, #818cf8 100%);
    background-size: 200% 100%;
    -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
    font-weight: 700 !important; font-size: 1.3rem !important; margin-bottom: 0.5rem !important;
    animation: headerShimmer 5s ease-in-out infinite;
}
@keyframes headerShimmer { 0%,100%{background-position:0% 50%} 50%{background-position:100% 50%} }

/* ========================================================
   15. TABLES
   ======================================================== */
.prose table, .md table { border-collapse: collapse !important; width: 100% !important; margin: 0.5rem 0 !important; }
.prose th, .md th {
    background: rgba(56,189,248,0.06) !important; color: #38bdf8 !important;
    font-weight: 600 !important; padding: 0.5rem 0.75rem !important;
    border: 1px solid rgba(56,189,248,0.10) !important; text-align: left !important;
}
.prose td, .md td { padding: 0.4rem 0.75rem !important; border: 1px solid rgba(56,189,248,0.06) !important; color: #c8d6e5 !important; }
.prose tr:hover td, .md tr:hover td { background: rgba(56,189,248,0.04) !important; }

/* ========================================================
   16. CHECKBOX / GALLERY / SCROLLBAR
   ======================================================== */
input[type="checkbox"] { accent-color: #6366f1 !important; }

.gallery-item {
    border-radius: 10px !important; border: 1px solid rgba(56,189,248,0.08) !important;
    transition: all .4s cubic-bezier(.4,0,.2,1) !important;
}
.gallery-item:hover {
    border-color: rgba(139,92,246,0.35) !important;
    box-shadow: 0 8px 28px rgba(139,92,246,0.2) !important;
    transform: translateY(-3px) scale(1.02);
}

::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: rgba(6,8,16,0.4); }
::-webkit-scrollbar-thumb { background: rgba(56,189,248,0.18); border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: rgba(56,189,248,0.35); }

/* ========================================================
   17. GPU BAR / FOOTER / MISC
   ======================================================== */
footer { display: none !important; }

.gpu-bar {
    background: rgba(10,12,22,0.75) !important;
    backdrop-filter: blur(16px) !important;
    border: 1px solid rgba(56,189,248,0.08) !important;
    border-radius: 14px !important;
    padding: 0.6rem 1.5rem !important;
}

.tips-footer { color: #3e4a5e !important; font-size: 0.82rem !important;
    border-top: 1px solid rgba(56,189,248,0.06) !important;
    padding-top: 1rem !important; margin-top: 1rem !important; }
.tips-footer strong { color: #536179 !important; }

label, .label-wrap span { color: #94a3b8 !important; font-weight: 500 !important; }
.info { color: #536179 !important; font-size: 0.8rem !important; }

/* ========================================================
   18. FLOATING ORBS — more layers, smoother motion
   ======================================================== */
.orb-1,.orb-2,.orb-3,.orb-4 {
    position: fixed; border-radius: 50%;
    filter: blur(90px); pointer-events: none; z-index: 0;
}
.orb-1 { width:500px; height:500px; background:rgba(99,102,241,0.10);
    top:-120px; right:-120px; animation: oF1 22s ease-in-out infinite; }
.orb-2 { width:420px; height:420px; background:rgba(56,189,248,0.09);
    bottom:-100px; left:-100px; animation: oF2 28s ease-in-out infinite; }
.orb-3 { width:300px; height:300px; background:rgba(168,85,247,0.07);
    top:40%; left:50%; animation: oF3 20s ease-in-out infinite; }
.orb-4 { width:200px; height:200px; background:rgba(244,114,182,0.06);
    top:20%; left:20%; animation: oF4 24s ease-in-out infinite; }
@keyframes oF1 { 0%,100%{transform:translate(0,0) scale(1)} 33%{transform:translate(-80px,50px) scale(1.1)} 66%{transform:translate(40px,-60px) scale(.92)} }
@keyframes oF2 { 0%,100%{transform:translate(0,0) scale(1)} 33%{transform:translate(60px,-40px) scale(1.12)} 66%{transform:translate(-50px,70px) scale(.88)} }
@keyframes oF3 { 0%,100%{transform:translate(-50%,-50%) scale(1); opacity:.4} 50%{transform:translate(-50%,-50%) scale(1.35); opacity:.7} }
@keyframes oF4 { 0%,100%{transform:translate(0,0) scale(1); opacity:.3} 50%{transform:translate(30px,-20px) scale(1.2); opacity:.55} }

/* ========================================================
   19. MODEL DOWNLOAD BANNER
   ======================================================== */
.model-banner {
    margin: 0.5rem 1rem !important;
    padding: 14px 20px !important;
    border-radius: 12px !important;
    background: rgba(234, 179, 8, 0.08) !important;
    border: 1px solid rgba(234, 179, 8, 0.25) !important;
    backdrop-filter: blur(10px) !important;
    position: relative;
    z-index: 1;
    animation: bannerPulse 3s ease-in-out infinite alternate;
}
.model-banner h3 { color: #eab308 !important; -webkit-text-fill-color: #eab308 !important; margin: 0 0 4px !important; }
.model-banner p  { color: #d4c77a !important; margin: 0 !important; font-size: 0.9rem !important; }
@keyframes bannerPulse {
    0%   { border-color: rgba(234, 179, 8, 0.15); box-shadow: 0 0 10px rgba(234, 179, 8, 0.05); }
    100% { border-color: rgba(234, 179, 8, 0.35); box-shadow: 0 0 20px rgba(234, 179, 8, 0.10); }
}

/* ========================================================
   20. COMPONENT STYLES (Dice, Gen-info, Presets)
   ======================================================== */
/* Dice button — small & round */
button[aria-label="🎲"], button:has(> span:only-child) {
    /* fallback: any sm secondary button */
}
.gen-info {
    margin-top: 8px !important;
    padding: 10px 14px !important;
    border-radius: 10px !important;
    background: rgba(0, 255, 170, 0.05) !important;
    border: 1px solid rgba(0, 255, 170, 0.15) !important;
    backdrop-filter: blur(8px) !important;
    font-size: 0.85rem !important;
    color: #c0e8d8 !important;
    animation: fadeSlideIn 0.5s ease-out !important;
}
.gen-info p { margin: 0 !important; }
.gen-info strong { color: #00ffaa !important; }

@keyframes fadeSlideIn {
    from { opacity: 0; transform: translateY(8px); }
    to   { opacity: 1; transform: translateY(0); }
}

/* ========================================================
   20. RESPONSIVE
   ======================================================== */
@media (max-width: 768px) {
    .hero-header h1 { font-size: 1.8rem; }
    .hero-subtitle { font-size: 0.85rem; }
    .orb-1,.orb-2,.orb-3,.orb-4,.particles,.particles2 { display: none; }
}
"""

# ============================================================================
# Build Gradio UI
# ============================================================================
def _update_frame_limit(width, height, profile_name):
    """Dynamically update frame slider max based on resolution and VRAM profile."""
    profile = get_profile_by_name(profile_name)
    limit = max_frames_for_resolution(int(width), int(height), profile)
    return gr.update(maximum=limit, value=min(57, limit))


def build_ui():
    with gr.Blocks(title="LTX-2 Video Studio") as demo:
        # Atmospheric layers + hero header
        gr.HTML("""
            <div class="particles"></div>
            <div class="particles2"></div>
            <div class="orb-1"></div>
            <div class="orb-2"></div>
            <div class="orb-3"></div>
            <div class="orb-4"></div>
            <div class="hero-header">
                <h1>LTX-2 Video Studio</h1>
                <div class="hero-subtitle">Next-Generation AI Video Synthesis</div>
                <div class="hero-badge">Powered by Lightricks LTX-2 19B</div>
                <div class="hero-line"></div>
            </div>
        """)

        # =================================================================
        # Model Download Banner (shown only if models are missing)
        # =================================================================
        _banner_text = _startup_model_banner()
        if _banner_text:
            model_banner = gr.Markdown(_banner_text, elem_classes="model-banner")
        else:
            model_banner = gr.Markdown("", visible=False, elem_classes="model-banner")

        # =================================================================
        # Global VRAM Management Controls
        # =================================================================
        with gr.Row(elem_classes="gpu-bar"):
            with gr.Column(scale=2):
                gpu_name = torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'None'
                gr.Markdown(f"**GPU** &nbsp; `{gpu_name}`")
            with gr.Column(scale=2):
                vram_profile = gr.Dropdown(
                    choices=[p.name for p in ALL_PROFILES],
                    value=ACTIVE_PROFILE.name,
                    label="VRAM Profile",
                    info="Auto-detected. Override if needed.",
                )
            with gr.Column(scale=1):
                disable_audio = gr.Checkbox(
                    label="Disable Audio",
                    value=ACTIVE_PROFILE.default_disable_audio,
                    info="Saves ~2 GB VRAM",
                )

        with gr.Tabs() as tabs:
            # ================================================================
            # Tab 1: Fast Generation (Distilled)
            # ================================================================
            with gr.Tab("⚡ Fast Generation", id="distilled"):
                gr.Markdown("### ⚡ Distilled Pipeline\nFastest inference with 8 predefined steps. Perfect for rapid iteration and previews.")
                with gr.Row():
                    with gr.Column(scale=1):
                        # -- Prompt Template --
                        d_template = gr.Dropdown(
                            choices=list(PROMPT_TEMPLATES.keys()),
                            value="(Select a template)",
                            label="Prompt Templates",
                            info="Pick a starting point, then customize below.",
                        )
                        d_prompt = gr.Textbox(
                            label="Prompt",
                            placeholder="Describe your video scene in detail...",
                            lines=4,
                            value="A golden retriever playing fetch on a sunny beach, waves crashing in the background, bright blue sky with fluffy white clouds, the dog runs joyfully across the sand, its fur gleaming in the sunlight.",
                        )
                        with gr.Row():
                            d_seed = gr.Number(label="Seed", value=42, precision=0)
                            d_dice = gr.Button("🎲", variant="secondary", size="sm", min_width=42)
                            d_enhance = gr.Checkbox(label="Enhance Prompt", value=False)
                            d_batch = gr.Slider(1, 8, value=1, step=1, label="Batch", info="Generate N variations")

                        with gr.Accordion("Resolution & Frames", open=True):
                            d_aspect = gr.Dropdown(
                                choices=list(ASPECT_RATIO_PRESETS.keys()),
                                value="Custom",
                                label="Aspect Ratio Preset",
                            )
                            with gr.Row():
                                d_width = gr.Slider(256, 1536, value=1536, step=64, label="Width")
                                d_height = gr.Slider(256, 1536, value=1024, step=64, label="Height")
                            with gr.Row():
                                d_frames = gr.Slider(9, 257, value=57, step=8, label="Frames (8K+1)")
                                d_fps = gr.Slider(8, 30, value=24, step=1, label="FPS")

                        with gr.Accordion("Camera Control LoRA", open=False):
                            d_camera = gr.Dropdown(
                                choices=list(CAMERA_LORAS.keys()),
                                value="None",
                                label="Camera Movement"
                            )
                            d_camera_str = gr.Slider(0.0, 2.0, value=1.0, step=0.1, label="LoRA Strength")

                        with gr.Accordion("Image Conditioning", open=False):
                            d_image = gr.Image(type="filepath", label="Conditioning Image")
                            with gr.Row():
                                d_img_frame = gr.Number(label="Frame Index", value=0, precision=0)
                                d_img_str = gr.Slider(0.0, 1.0, value=1.0, step=0.1, label="Strength")

                        with gr.Row():
                            d_generate = gr.Button("🚀 Generate Video", variant="primary", size="lg", scale=3)
                            d_cancel = gr.Button("Cancel", variant="stop", size="lg", scale=1)

                    with gr.Column(scale=1):
                        d_output = gr.Video(label="Generated Video", height=480)
                        d_gen_info = gr.Markdown("", elem_classes="gen-info")

                # -- Wire helpers --
                d_dice.click(fn=_random_seed, outputs=[d_seed], queue=False)
                d_template.change(
                    fn=lambda t: PROMPT_TEMPLATES.get(t, "") or gr.update(),
                    inputs=[d_template], outputs=[d_prompt], queue=False,
                )

                def _apply_aspect_d(preset):
                    v = ASPECT_RATIO_PRESETS.get(preset)
                    if v is None:
                        return gr.update(), gr.update()
                    return gr.update(value=v[0]), gr.update(value=v[1])
                d_aspect.change(fn=_apply_aspect_d, inputs=[d_aspect], outputs=[d_width, d_height], queue=False)

                d_width.change(fn=_update_frame_limit, inputs=[d_width, d_height, vram_profile], outputs=[d_frames])
                d_height.change(fn=_update_frame_limit, inputs=[d_width, d_height, vram_profile], outputs=[d_frames])

                # -- Batch-aware runner --
                def _run_distilled_batch(prompt, seed, height, width, num_frames, frame_rate,
                        image_path, image_frame_idx, image_strength,
                        camera_lora, camera_lora_strength,
                        enhance_prompt, vram_profile_name, disable_audio, batch_count,
                        progress=gr.Progress()):
                    results = []
                    for i in range(int(batch_count)):
                        current_seed = int(seed) + i
                        if i > 0:
                            progress(i / int(batch_count), desc=f"Batch {i+1}/{int(batch_count)}...")
                        out = run_distilled_pipeline(
                            prompt, current_seed, height, width, num_frames, frame_rate,
                            image_path, image_frame_idx, image_strength,
                            camera_lora, camera_lora_strength,
                            enhance_prompt, vram_profile_name, disable_audio, progress,
                        )
                        results.append(out)
                    last = results[-1]
                    n = len(results)
                    if n == 1:
                        info = f"**Done** — 1 video generated. Seed: {int(seed)}"
                    else:
                        info = f"**Done** — {n} videos generated. Seeds: {int(seed)}–{int(seed)+n-1}"
                    return last, info

                d_event = d_generate.click(
                    fn=_run_distilled_batch,
                    inputs=[
                        d_prompt, d_seed, d_height, d_width, d_frames, d_fps,
                        d_image, d_img_frame, d_img_str,
                        d_camera, d_camera_str,
                        d_enhance, vram_profile, disable_audio, d_batch,
                    ],
                    outputs=[d_output, d_gen_info],
                    concurrency_limit=1,
                    concurrency_id="gpu_queue",
                )
                d_cancel.click(fn=request_cancel, cancels=[d_event], queue=False)

            # ================================================================
            # Tab 2: Production Quality (Two-Stage)
            # ================================================================
            with gr.Tab("🎬 Production Quality", id="twostage"):
                gr.Markdown("### 🎬 Two-Stage Pipeline\nBest quality with CFG + STG guidance and 2x spatial upsampling. For final renders.")
                with gr.Row():
                    with gr.Column(scale=1):
                        ts_template = gr.Dropdown(
                            choices=list(PROMPT_TEMPLATES.keys()),
                            value="(Select a template)",
                            label="Prompt Templates",
                        )
                        ts_prompt = gr.Textbox(
                            label="Prompt",
                            placeholder="Describe your video scene in detail...",
                            lines=4,
                            value="A cinematic shot of a vast mountain landscape at golden hour, the camera slowly panning across snow-capped peaks, warm light casting long shadows across alpine meadows, wisps of clouds drifting between the summits.",
                        )
                        ts_neg_preset = gr.Dropdown(
                            choices=list(NEGATIVE_PROMPT_PRESETS.keys()),
                            value="(Select a preset)",
                            label="Negative Prompt Presets",
                        )
                        ts_neg_prompt = gr.Textbox(
                            label="Negative Prompt",
                            lines=2,
                            value=DEFAULT_NEGATIVE_PROMPT,
                        )
                        with gr.Row():
                            ts_seed = gr.Number(label="Seed", value=42, precision=0)
                            ts_dice = gr.Button("🎲", variant="secondary", size="sm", min_width=42)
                            ts_steps = gr.Slider(10, 60, value=40, step=1, label="Inference Steps")
                            ts_enhance = gr.Checkbox(label="Enhance Prompt", value=False)

                        with gr.Accordion("Resolution & Frames", open=True):
                            ts_aspect = gr.Dropdown(
                                choices=list(ASPECT_RATIO_PRESETS.keys()),
                                value="Custom",
                                label="Aspect Ratio Preset",
                            )
                            with gr.Row():
                                ts_width = gr.Slider(256, 1536, value=1536, step=64, label="Width")
                                ts_height = gr.Slider(256, 1536, value=1024, step=64, label="Height")
                            with gr.Row():
                                ts_frames = gr.Slider(9, 257, value=57, step=8, label="Frames (8K+1)")
                                ts_fps = gr.Slider(8, 30, value=24, step=1, label="FPS")

                        with gr.Accordion("Guidance Parameters", open=False):
                            gr.Markdown("**Video Guidance**")
                            with gr.Row():
                                ts_v_cfg = gr.Slider(1.0, 10.0, value=3.0, step=0.5, label="Video CFG Scale")
                                ts_v_stg = gr.Slider(0.0, 3.0, value=1.0, step=0.1, label="Video STG Scale")
                                ts_v_rescale = gr.Slider(0.0, 1.0, value=0.7, step=0.1, label="Video Rescale")
                            gr.Markdown("**Audio Guidance**")
                            with gr.Row():
                                ts_a_cfg = gr.Slider(1.0, 15.0, value=7.0, step=0.5, label="Audio CFG Scale")
                                ts_a_stg = gr.Slider(0.0, 3.0, value=1.0, step=0.1, label="Audio STG Scale")
                                ts_a_rescale = gr.Slider(0.0, 1.0, value=0.7, step=0.1, label="Audio Rescale")
                            ts_modality = gr.Slider(1.0, 5.0, value=3.0, step=0.5, label="Modality Scale (A/V Sync)")

                        with gr.Accordion("Camera Control LoRA", open=False):
                            ts_camera = gr.Dropdown(
                                choices=list(CAMERA_LORAS.keys()),
                                value="None",
                                label="Camera Movement"
                            )
                            ts_camera_str = gr.Slider(0.0, 2.0, value=1.0, step=0.1, label="LoRA Strength")

                        with gr.Accordion("Image Conditioning", open=False):
                            ts_image = gr.Image(type="filepath", label="Conditioning Image")
                            with gr.Row():
                                ts_img_frame = gr.Number(label="Frame Index", value=0, precision=0)
                                ts_img_str = gr.Slider(0.0, 1.0, value=1.0, step=0.1, label="Strength")

                        with gr.Row():
                            ts_generate = gr.Button("🎬 Generate Video", variant="primary", size="lg", scale=3)
                            ts_cancel = gr.Button("Cancel", variant="stop", size="lg", scale=1)

                    with gr.Column(scale=1):
                        ts_output = gr.Video(label="Generated Video", height=480)
                        ts_gen_info = gr.Markdown("", elem_classes="gen-info")

                # -- Wire helpers --
                ts_dice.click(fn=_random_seed, outputs=[ts_seed], queue=False)
                ts_template.change(
                    fn=lambda t: PROMPT_TEMPLATES.get(t, "") or gr.update(),
                    inputs=[ts_template], outputs=[ts_prompt], queue=False,
                )
                ts_neg_preset.change(
                    fn=lambda t: NEGATIVE_PROMPT_PRESETS.get(t, "") or gr.update(),
                    inputs=[ts_neg_preset], outputs=[ts_neg_prompt], queue=False,
                )
                def _apply_aspect_ts(preset):
                    v = ASPECT_RATIO_PRESETS.get(preset)
                    if v is None:
                        return gr.update(), gr.update()
                    return gr.update(value=v[0]), gr.update(value=v[1])
                ts_aspect.change(fn=_apply_aspect_ts, inputs=[ts_aspect], outputs=[ts_width, ts_height], queue=False)

                ts_width.change(fn=_update_frame_limit, inputs=[ts_width, ts_height, vram_profile], outputs=[ts_frames])
                ts_height.change(fn=_update_frame_limit, inputs=[ts_width, ts_height, vram_profile], outputs=[ts_frames])

                def _run_twostage_wrapped(*args, progress=gr.Progress()):
                    t0 = time.time()
                    result = run_two_stage_pipeline(*args, progress=progress)
                    elapsed = time.time() - t0
                    info = f"**Done** in {elapsed:.0f}s  |  Seed: {int(args[2])}  |  {int(args[4])}x{int(args[3])} @ {int(args[6])}fps  |  {int(args[5])} frames"
                    return result, info

                ts_event = ts_generate.click(
                    fn=_run_twostage_wrapped,
                    inputs=[
                        ts_prompt, ts_neg_prompt, ts_seed, ts_height, ts_width, ts_frames, ts_fps,
                        ts_steps,
                        ts_image, ts_img_frame, ts_img_str,
                        ts_camera, ts_camera_str,
                        ts_v_cfg, ts_v_stg, ts_v_rescale,
                        ts_a_cfg, ts_a_stg, ts_a_rescale,
                        ts_modality,
                        ts_enhance, vram_profile, disable_audio,
                    ],
                    outputs=[ts_output, ts_gen_info],
                    concurrency_limit=1,
                    concurrency_id="gpu_queue",
                )
                ts_cancel.click(fn=request_cancel, cancels=[ts_event], queue=False)

            # ================================================================
            # Tab 3: IC-LoRA (Video-to-Video)
            # ================================================================
            with gr.Tab("🎨 IC-LoRA", id="iclora"):
                gr.Markdown("""### 🎨 IC-LoRA Pipeline &mdash; Video-to-Video with Structural Control

Upload any regular video and choose a control mode. The app **automatically extracts** the control signal for you:

| Mode | What it does |
|------|-------------|
| **Canny Control** | Extracts edges, generates a new video following those edges in your style |
| **Depth Control** | AI-powered depth maps, preserves the 3D structure of your scene |
| **Pose Control** | AI-powered body pose detection, generates video following the same motion |
| **Detailer** | Enhances detail and quality of your uploaded video directly |

Your prompt should describe the **desired output** (style, content, atmosphere), not the control signal.
""")
                with gr.Row():
                    with gr.Column(scale=1):
                        ic_prompt = gr.Textbox(
                            label="Prompt — describe what the output should look like",
                            placeholder="e.g. 'An oil painting of a dancer in a sunlit meadow, impressionist style, rich brushstrokes'",
                            lines=4,
                            value="A cinematic scene with dramatic lighting, smooth camera motion, photorealistic quality, detailed textures and natural movement.",
                        )
                        with gr.Row():
                            ic_seed = gr.Number(label="Seed", value=42, precision=0)
                            ic_dice = gr.Button("🎲", variant="secondary", size="sm", min_width=42)
                            ic_enhance = gr.Checkbox(label="Enhance Prompt", value=False)

                        with gr.Accordion("Resolution & Frames", open=True):
                            ic_aspect = gr.Dropdown(
                                choices=list(ASPECT_RATIO_PRESETS.keys()),
                                value="Custom",
                                label="Aspect Ratio Preset",
                            )
                            with gr.Row():
                                ic_width = gr.Slider(256, 1536, value=1536, step=64, label="Width")
                                ic_height = gr.Slider(256, 1536, value=1024, step=64, label="Height")
                            with gr.Row():
                                ic_frames = gr.Slider(9, 257, value=57, step=8, label="Frames (8K+1)")
                                ic_fps = gr.Slider(8, 30, value=24, step=1, label="FPS")

                        with gr.Accordion("IC-LoRA Control Type", open=True):
                            ic_lora_type = gr.Dropdown(
                                choices=list(IC_LORAS.keys()),
                                value="Canny Control",
                                label="Control Mode",
                                info="Choose how the input video guides the generation.",
                            )
                            ic_lora_str = gr.Slider(0.0, 2.0, value=1.0, step=0.1, label="LoRA Strength",
                                                    info="Keep at 1.0 (official recommendation).")

                        with gr.Accordion("Upload Your Video", open=True):
                            gr.Markdown("Just upload a **regular video** — the control signal is extracted automatically.")
                            ic_video = gr.Video(label="Input Video", sources=["upload"])
                            ic_video_str = gr.Slider(0.0, 1.0, value=1.0, step=0.1, label="Conditioning Strength",
                                                     info="Keep at 1.0 for best results.")
                            ic_auto_preprocess = gr.Checkbox(
                                label="Auto-preprocess video (extract control signal automatically)",
                                value=True,
                                info="Uncheck only if you already have a pre-processed control signal video.",
                            )
                            ic_preview_btn = gr.Button("👁 Preview Control Signal", variant="secondary")

                        with gr.Accordion("Image Conditioning (Optional)", open=False):
                            gr.Markdown("Optionally set a specific frame from an image (e.g., set the first frame).")
                            ic_image = gr.Image(type="filepath", label="Conditioning Image")
                            with gr.Row():
                                ic_img_frame = gr.Number(label="Frame Index", value=0, precision=0)
                                ic_img_str = gr.Slider(0.0, 1.0, value=1.0, step=0.1, label="Strength")

                        with gr.Row():
                            ic_generate = gr.Button("🎨 Generate Video", variant="primary", size="lg", scale=3)
                            ic_cancel = gr.Button("Cancel", variant="stop", size="lg", scale=1)

                    with gr.Column(scale=1):
                        ic_control_preview = gr.Video(label="Control Signal Preview", height=240)
                        ic_output = gr.Video(label="Generated Video", height=480)
                        ic_gen_info = gr.Markdown("", elem_classes="gen-info")

                # -- Wire helpers --
                ic_dice.click(fn=_random_seed, outputs=[ic_seed], queue=False)
                def _apply_aspect_ic(preset):
                    v = ASPECT_RATIO_PRESETS.get(preset)
                    if v is None:
                        return gr.update(), gr.update()
                    return gr.update(value=v[0]), gr.update(value=v[1])
                ic_aspect.change(fn=_apply_aspect_ic, inputs=[ic_aspect], outputs=[ic_width, ic_height], queue=False)

                ic_width.change(fn=_update_frame_limit, inputs=[ic_width, ic_height, vram_profile], outputs=[ic_frames])
                ic_height.change(fn=_update_frame_limit, inputs=[ic_width, ic_height, vram_profile], outputs=[ic_frames])

                def _preview_control_signal(video_path, control_type, progress=gr.Progress()):
                    """Preview the control signal extracted from the uploaded video."""
                    if not video_path:
                        raise gr.Error("Please upload a video first.")
                    from video_preprocessors import preprocess_for_control
                    progress(0.1, desc=f"Extracting {control_type} control signal...")
                    result = preprocess_for_control(video_path, control_type)
                    progress(1.0, desc="Done!")
                    return result

                ic_preview_btn.click(
                    fn=_preview_control_signal,
                    inputs=[ic_video, ic_lora_type],
                    outputs=[ic_control_preview],
                )

                def _run_iclora_wrapped(*args, progress=gr.Progress()):
                    t0 = time.time()
                    result = run_ic_lora_pipeline(*args, progress=progress)
                    elapsed = time.time() - t0
                    info = f"**Done** in {elapsed:.0f}s  |  Seed: {int(args[1])}  |  Mode: {args[11]}"
                    return result, info

                ic_event = ic_generate.click(
                    fn=_run_iclora_wrapped,
                    inputs=[
                        ic_prompt, ic_seed, ic_height, ic_width, ic_frames, ic_fps,
                        ic_image, ic_img_frame, ic_img_str,
                        ic_video, ic_video_str,
                        ic_lora_type, ic_lora_str,
                        ic_auto_preprocess,
                        ic_enhance, vram_profile, disable_audio,
                    ],
                    outputs=[ic_output, ic_gen_info],
                    concurrency_limit=1,
                    concurrency_id="gpu_queue",
                )
                ic_cancel.click(fn=request_cancel, cancels=[ic_event], queue=False)

            # ================================================================
            # Tab 4: Keyframe Interpolation
            # ================================================================
            with gr.Tab("🔀 Keyframe Interpolation", id="keyframe"):
                gr.Markdown("### 🔀 Keyframe Interpolation\nGenerate smooth cinematic transitions between two images. Set start and end frames.")
                with gr.Row():
                    with gr.Column(scale=1):
                        kf_template = gr.Dropdown(
                            choices=list(PROMPT_TEMPLATES.keys()),
                            value="(Select a template)",
                            label="Prompt Templates",
                        )
                        kf_prompt = gr.Textbox(
                            label="Prompt",
                            placeholder="Describe the transition between keyframes...",
                            lines=4,
                            value="A smooth cinematic transition between the two scenes, natural motion, consistent lighting and style.",
                        )
                        kf_neg_preset = gr.Dropdown(
                            choices=list(NEGATIVE_PROMPT_PRESETS.keys()),
                            value="(Select a preset)",
                            label="Negative Prompt Presets",
                        )
                        kf_neg_prompt = gr.Textbox(
                            label="Negative Prompt",
                            lines=2,
                            value=DEFAULT_NEGATIVE_PROMPT,
                        )
                        with gr.Row():
                            kf_seed = gr.Number(label="Seed", value=42, precision=0)
                            kf_dice = gr.Button("🎲", variant="secondary", size="sm", min_width=42)
                            kf_steps = gr.Slider(10, 60, value=40, step=1, label="Inference Steps")
                            kf_enhance = gr.Checkbox(label="Enhance Prompt", value=False)

                        with gr.Accordion("Resolution & Frames", open=True):
                            kf_aspect = gr.Dropdown(
                                choices=list(ASPECT_RATIO_PRESETS.keys()),
                                value="Custom",
                                label="Aspect Ratio Preset",
                            )
                            with gr.Row():
                                kf_width = gr.Slider(256, 1536, value=1536, step=64, label="Width")
                                kf_height = gr.Slider(256, 1536, value=1024, step=64, label="Height")
                            with gr.Row():
                                kf_frames = gr.Slider(9, 257, value=57, step=8, label="Frames (8K+1)")
                                kf_fps = gr.Slider(8, 30, value=24, step=1, label="FPS")

                        with gr.Accordion("Keyframe 1 (Start)", open=True):
                            kf1_image = gr.Image(type="filepath", label="Start Keyframe Image")
                            with gr.Row():
                                kf1_frame = gr.Number(label="Frame Index", value=0, precision=0)
                                kf1_str = gr.Slider(0.0, 1.0, value=1.0, step=0.1, label="Strength")

                        with gr.Accordion("Keyframe 2 (End)", open=True):
                            kf2_image = gr.Image(type="filepath", label="End Keyframe Image")
                            with gr.Row():
                                kf2_frame = gr.Number(label="Frame Index", value=56, precision=0)
                                kf2_str = gr.Slider(0.0, 1.0, value=1.0, step=0.1, label="Strength")

                        with gr.Accordion("Guidance Parameters", open=False):
                            gr.Markdown("**Video Guidance**")
                            with gr.Row():
                                kf_v_cfg = gr.Slider(1.0, 10.0, value=3.0, step=0.5, label="Video CFG")
                                kf_v_stg = gr.Slider(0.0, 3.0, value=1.0, step=0.1, label="Video STG")
                                kf_v_rescale = gr.Slider(0.0, 1.0, value=0.7, step=0.1, label="Video Rescale")
                            gr.Markdown("**Audio Guidance**")
                            with gr.Row():
                                kf_a_cfg = gr.Slider(1.0, 15.0, value=7.0, step=0.5, label="Audio CFG")
                                kf_a_stg = gr.Slider(0.0, 3.0, value=1.0, step=0.1, label="Audio STG")
                                kf_a_rescale = gr.Slider(0.0, 1.0, value=0.7, step=0.1, label="Audio Rescale")
                            kf_modality = gr.Slider(1.0, 5.0, value=3.0, step=0.5, label="Modality Scale")

                        with gr.Accordion("Camera Control LoRA", open=False):
                            kf_camera = gr.Dropdown(
                                choices=list(CAMERA_LORAS.keys()),
                                value="None",
                                label="Camera Movement"
                            )
                            kf_camera_str = gr.Slider(0.0, 2.0, value=1.0, step=0.1, label="LoRA Strength")

                        with gr.Row():
                            kf_generate = gr.Button("🔀 Generate Interpolation", variant="primary", size="lg", scale=3)
                            kf_cancel = gr.Button("Cancel", variant="stop", size="lg", scale=1)

                    with gr.Column(scale=1):
                        kf_output = gr.Video(label="Generated Video", height=480)
                        kf_gen_info = gr.Markdown("", elem_classes="gen-info")

                # -- Wire helpers --
                kf_dice.click(fn=_random_seed, outputs=[kf_seed], queue=False)
                kf_template.change(
                    fn=lambda t: PROMPT_TEMPLATES.get(t, "") or gr.update(),
                    inputs=[kf_template], outputs=[kf_prompt], queue=False,
                )
                kf_neg_preset.change(
                    fn=lambda t: NEGATIVE_PROMPT_PRESETS.get(t, "") or gr.update(),
                    inputs=[kf_neg_preset], outputs=[kf_neg_prompt], queue=False,
                )
                def _apply_aspect_kf(preset):
                    v = ASPECT_RATIO_PRESETS.get(preset)
                    if v is None:
                        return gr.update(), gr.update()
                    return gr.update(value=v[0]), gr.update(value=v[1])
                kf_aspect.change(fn=_apply_aspect_kf, inputs=[kf_aspect], outputs=[kf_width, kf_height], queue=False)

                kf_width.change(fn=_update_frame_limit, inputs=[kf_width, kf_height, vram_profile], outputs=[kf_frames])
                kf_height.change(fn=_update_frame_limit, inputs=[kf_width, kf_height, vram_profile], outputs=[kf_frames])

                def _run_keyframe_wrapped(*args, progress=gr.Progress()):
                    t0 = time.time()
                    result = run_keyframe_pipeline(*args, progress=progress)
                    elapsed = time.time() - t0
                    info = f"**Done** in {elapsed:.0f}s  |  Seed: {int(args[2])}  |  {int(args[4])}x{int(args[3])} @ {int(args[6])}fps  |  {int(args[5])} frames"
                    return result, info

                kf_event = kf_generate.click(
                    fn=_run_keyframe_wrapped,
                    inputs=[
                        kf_prompt, kf_neg_prompt, kf_seed, kf_height, kf_width, kf_frames, kf_fps,
                        kf_steps,
                        kf1_image, kf1_frame, kf1_str,
                        kf2_image, kf2_frame, kf2_str,
                        kf_camera, kf_camera_str,
                        kf_v_cfg, kf_v_stg, kf_v_rescale,
                        kf_a_cfg, kf_a_stg, kf_a_rescale,
                        kf_modality,
                        kf_enhance, vram_profile, disable_audio,
                    ],
                    outputs=[kf_output, kf_gen_info],
                    concurrency_limit=1,
                    concurrency_id="gpu_queue",
                )
                kf_cancel.click(fn=request_cancel, cancels=[kf_event], queue=False)

            # ================================================================
            # Tab 5: Gallery / History
            # ================================================================
            with gr.Tab("🖼 Gallery", id="gallery"):
                gr.Markdown("### Generation History — Browse previous outputs")

                def _refresh_gallery():
                    """Get list of output videos for the gallery."""
                    videos = sorted(OUTPUTS_DIR.glob("*.mp4"), key=os.path.getmtime, reverse=True)
                    if not videos:
                        return "No videos generated yet.", [], ""

                    history = _load_generation_history()
                    history_text = ""
                    for entry in history[:20]:
                        ts = entry.get("timestamp", "")[:19].replace("T", " ")
                        pipe = entry.get("pipeline", "?")
                        elapsed = entry.get("elapsed_seconds", "?")
                        fname = entry.get("file", "?")
                        history_text += f"{ts}  |  {pipe}  |  {elapsed}s  |  {fname}\n"

                    if not history_text:
                        history_text = "No generation metadata recorded yet."

                    # Disk usage
                    total_size = sum(f.stat().st_size for f in videos) / (1024 ** 2)
                    summary = f"{len(videos)} videos  |  {total_size:.0f} MB total"

                    return summary, [str(v) for v in videos[:20]], history_text

                with gr.Row():
                    gallery_refresh = gr.Button("🔄 Refresh", variant="secondary")
                    gallery_open_folder = gr.Button("📂 Open Output Folder", variant="secondary")
                gallery_summary = gr.Markdown("Click Refresh to load gallery.")
                gallery_videos = gr.Gallery(label="Recent Videos", columns=4, object_fit="contain", height=400)
                gallery_history = gr.Textbox(label="Generation Log (recent first)", lines=10, interactive=False)

                def _open_outputs_folder():
                    """Open the outputs folder in the system file explorer."""
                    folder = str(OUTPUTS_DIR)
                    try:
                        if sys.platform == "win32":
                            os.startfile(folder)
                        elif sys.platform == "darwin":
                            subprocess.Popen(["open", folder])
                        else:
                            subprocess.Popen(["xdg-open", folder])
                    except Exception:
                        pass
                    return f"Opened: {folder}"

                gallery_refresh.click(fn=_refresh_gallery, outputs=[gallery_summary, gallery_videos, gallery_history])
                gallery_open_folder.click(fn=_open_outputs_folder, outputs=[gallery_summary])

            # ================================================================
            # Tab 6: Logs
            # ================================================================
            with gr.Tab("📋 Logs", id="logs"):
                gr.Markdown("### Application Logs — For troubleshooting")

                def _read_logs(num_lines=200):
                    """Read the last N lines of the log file."""
                    if not LOG_FILE.exists():
                        return "No log file found."
                    try:
                        lines = LOG_FILE.read_text(encoding="utf-8").split("\n")
                        return "\n".join(lines[-num_lines:])
                    except Exception as e:
                        return f"Error reading logs: {e}"

                def _get_log_file_info():
                    """Get log file path and size."""
                    if not LOG_FILE.exists():
                        return "No log file yet."
                    size = LOG_FILE.stat().st_size / 1024
                    return f"Log file: {LOG_FILE}  ({size:.0f} KB)"

                with gr.Row():
                    log_refresh = gr.Button("🔄 Refresh Logs", variant="secondary")
                    log_clear = gr.Button("🗑 Clear Logs", variant="secondary")
                log_info = gr.Markdown("")
                log_output = gr.Textbox(label="Log Output", lines=25, interactive=False, max_lines=50)

                def _clear_logs():
                    try:
                        LOG_FILE.write_text("", encoding="utf-8")
                        logger.info("Logs cleared by user.")
                        return "Logs cleared.", ""
                    except Exception as e:
                        return f"Error: {e}", ""

                log_refresh.click(fn=_read_logs, outputs=[log_output])
                log_refresh.click(fn=_get_log_file_info, outputs=[log_info])
                log_clear.click(fn=_clear_logs, outputs=[log_info, log_output])

            # ================================================================
            # Tab 7: Model Status & Settings
            # ================================================================
            with gr.Tab("⚙️ Status", id="status"):
                gr.Markdown("### Model Status & GPU Info")

                # --- Download Section ---
                with gr.Group():
                    gr.Markdown("#### 📥 Model Downloads")
                    gr.Markdown(
                        "Models are downloaded from HuggingFace (~80 GB total on first run). "
                        "This is automatic — just click the button below. "
                        "**Note:** The Gemma text encoder may require a HuggingFace account. "
                        "If prompted, visit the link in the error message to accept terms, then run:\n"
                        "`LTX2_env\\python.exe -m huggingface_hub.cli login`"
                    )
                    with gr.Row():
                        download_btn = gr.Button(
                            "📥 Download All Models",
                            variant="primary",
                            size="lg",
                            scale=2,
                        )
                        status_btn = gr.Button("🔄 Refresh Status", variant="secondary", scale=1)
                        cleanup_btn = gr.Button("🧹 Free GPU Memory", variant="secondary", scale=1)
                    download_output = gr.Markdown("", elem_classes="gen-info")

                status_output = gr.Textbox(label="Model Status", lines=20, interactive=False)
                gpu_output = gr.Textbox(label="GPU Info", lines=10, interactive=False)

                def get_extended_gpu_info():
                    info = get_gpu_info_str()
                    profile = ACTIVE_PROFILE
                    info += f"\n\nActive Profile: {profile.name}\n"
                    info += f"Description: {profile.description}\n"
                    info += f"Max frames @1080p: {profile.max_frames_1080p}\n"
                    info += f"Max frames @720p: {profile.max_frames_720p}\n"
                    info += f"CPU offload transformer: {'Yes' if profile.transformer_max_memory else 'No'}\n"
                    info += f"CPU offload text encoder: {'Yes' if profile.text_encoder_max_memory else 'No'}\n"
                    info += f"\nLog file: {LOG_FILE}\n"
                    info += f"Output dir: {OUTPUTS_DIR}\n"
                    return info

                def _cleanup_and_report():
                    cleanup_gpu()
                    return get_extended_gpu_info()

                def _download_and_refresh(progress=gr.Progress()):
                    result = download_all_models(progress)
                    # After download, refresh model status and banner
                    return result, check_models_exist(), _startup_model_banner()

                download_btn.click(
                    fn=_download_and_refresh,
                    outputs=[download_output, status_output, model_banner],
                )
                status_btn.click(fn=check_models_exist, outputs=[status_output])
                status_btn.click(fn=get_extended_gpu_info, outputs=[gpu_output])
                cleanup_btn.click(fn=_cleanup_and_report, outputs=[gpu_output])

                # Auto-load on page load
                demo.load(fn=check_models_exist, outputs=[status_output])
                demo.load(fn=get_extended_gpu_info, outputs=[gpu_output])

        # Update frame limits on ALL tabs when VRAM profile changes
        vram_profile.change(fn=_update_frame_limit, inputs=[d_width, d_height, vram_profile], outputs=[d_frames])
        vram_profile.change(fn=_update_frame_limit, inputs=[ts_width, ts_height, vram_profile], outputs=[ts_frames])
        vram_profile.change(fn=_update_frame_limit, inputs=[ic_width, ic_height, vram_profile], outputs=[ic_frames])
        vram_profile.change(fn=_update_frame_limit, inputs=[kf_width, kf_height, vram_profile], outputs=[kf_frames])

        gr.Markdown("""
**Quick Reference** &mdash;
**Distilled** = fastest (~8 steps) &bull;
**Two-Stage** = best quality (~40 steps) &bull;
**IC-LoRA** = video-to-video control &bull;
**Cancel** to abort &bull;
**Gallery** for history &bull;
**Logs** for troubleshooting
        """, elem_classes="tips-footer")

    return demo


# ============================================================================
# Main
# ============================================================================
if __name__ == "__main__":
    theme = gr.themes.Base(
        primary_hue=gr.themes.colors.indigo,
        secondary_hue=gr.themes.colors.slate,
        neutral_hue=gr.themes.colors.slate,
        font=gr.themes.GoogleFont("Inter"),
    ).set(
        body_background_fill="#08090d",
        body_background_fill_dark="#08090d",
        block_background_fill="rgba(15, 17, 25, 0.7)",
        block_background_fill_dark="rgba(15, 17, 25, 0.7)",
        block_border_color="rgba(56, 189, 248, 0.1)",
        block_border_color_dark="rgba(56, 189, 248, 0.1)",
        block_label_background_fill="rgba(20, 22, 35, 0.9)",
        block_label_background_fill_dark="rgba(20, 22, 35, 0.9)",
        block_label_text_color="#94a3b8",
        block_label_text_color_dark="#94a3b8",
        block_title_text_color="#e2e8f0",
        block_title_text_color_dark="#e2e8f0",
        body_text_color="#c8d6e5",
        body_text_color_dark="#c8d6e5",
        border_color_primary="rgba(56, 189, 248, 0.12)",
        border_color_primary_dark="rgba(56, 189, 248, 0.12)",
        input_background_fill="rgba(12, 14, 22, 0.9)",
        input_background_fill_dark="rgba(12, 14, 22, 0.9)",
        button_primary_background_fill="*primary_500",
        button_primary_text_color="white",
        shadow_drop="0 4px 24px rgba(0, 0, 0, 0.3)",
    )
    demo = build_ui()
    demo.queue(
        default_concurrency_limit=1,  # GPU-bound: one generation at a time
        max_size=10,                  # Reject if >10 requests queued
    )
    demo.launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False,
        inbrowser=True,
        theme=theme,
        css=CUSTOM_CSS,
    )
