# ============================================================
# FLUX.2 Klein — First-Time Setup (no Python required)
#
# Shows a license key dialog, validates against the server,
# downloads FLUX_env.zip from HuggingFace, extracts it,
# then hands off to the normal launcher.
# ============================================================

param([string]$InstallDir)

$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

if (-not $InstallDir) { $InstallDir = $PSScriptRoot }

$ENV_URL  = "https://huggingface.co/NancyWu1234/image-crescent/resolve/main/FLUX_env.zip"
$ENV_ZIP  = Join-Path $InstallDir "FLUX_env.zip"
$SERVER   = "https://lumina-ai-demo.vercel.app"
$KEY_FILE = Join-Path $InstallDir ".key_validated"

# ── Hardware fingerprint (mirrors machine_lock.py) ──────────
function Get-MachineId {
    $parts = @()

    # Motherboard UUID
    try {
        $mb = (Get-CimInstance Win32_ComputerSystemProduct).UUID
        if ($mb) { $parts += "mb:$mb" }
    } catch {}

    # CPU ID
    try {
        $cpu = (Get-CimInstance Win32_Processor).ProcessorId
        if ($cpu) { $parts += "cpu:$($cpu.Trim())" }
    } catch {}

    # Disk serial
    try {
        $disk = (Get-CimInstance Win32_DiskDrive | Select-Object -First 1).SerialNumber
        if ($disk) { $parts += "disk:$($disk.Trim())" }
    } catch {}

    # Hostname
    $parts += "host:$([System.Net.Dns]::GetHostName())"

    if ($parts.Count -eq 0) {
        $raw = "fallback:$([System.Net.Dns]::GetHostName()):$($env:USERNAME)"
    } else {
        $raw = $parts -join "|"
    }

    $sha = [System.Security.Cryptography.SHA256]::Create()
    $hash = $sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($raw))
    return ($hash | ForEach-Object { $_.ToString("x2") }) -join ""
}

function Get-MachineLabel {
    $name = [System.Net.Dns]::GetHostName()
    $os = [System.Environment]::OSVersion.Platform
    $arch = [System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture
    return "$name (Windows $arch)"
}

# ── Server API call ─────────────────────────────────────────
function Invoke-LicenseApi {
    param([string]$Endpoint, [hashtable]$Body)

    $url = "$SERVER$Endpoint"
    $json = $Body | ConvertTo-Json -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)

    try {
        $req = [System.Net.HttpWebRequest]::Create($url)
        $req.Method = "POST"
        $req.ContentType = "application/json"
        $req.Timeout = 30000
        $stream = $req.GetRequestStream()
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Close()

        $resp = $req.GetResponse()
        $reader = New-Object System.IO.StreamReader($resp.GetResponseStream())
        $body = $reader.ReadToEnd()
        $reader.Close()
        $resp.Close()
        return @{ Code = [int]$resp.StatusCode; Body = ($body | ConvertFrom-Json) }
    } catch [System.Net.WebException] {
        $ex = $_.Exception
        if ($ex.Response) {
            $reader = New-Object System.IO.StreamReader($ex.Response.GetResponseStream())
            $body = $reader.ReadToEnd()
            $reader.Close()
            $code = [int]$ex.Response.StatusCode
            try { $parsed = $body | ConvertFrom-Json } catch { $parsed = @{ error = $body } }
            return @{ Code = $code; Body = $parsed }
        }
        return @{ Code = 0; Body = @{ error = $ex.Message } }
    } catch {
        return @{ Code = 0; Body = @{ error = $_.Exception.Message } }
    }
}

# ── WinForms GUI ────────────────────────────────────────────
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

function Show-SetupForm {
    $form = New-Object System.Windows.Forms.Form
    $form.Text = "FLUX.2 Klein — Setup"
    $form.Size = New-Object System.Drawing.Size(520, 420)
    $form.StartPosition = "CenterScreen"
    $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false
    $form.BackColor = [System.Drawing.Color]::FromArgb(26, 27, 38)
    $form.ForeColor = [System.Drawing.Color]::FromArgb(192, 202, 245)
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 10)

    $iconPath = Join-Path $InstallDir "flux_engine.ico"
    if (Test-Path $iconPath) {
        try { $form.Icon = New-Object System.Drawing.Icon($iconPath) } catch {}
    }

    # Title
    $titleLabel = New-Object System.Windows.Forms.Label
    $titleLabel.Text = "FLUX.2 Klein — First-Time Setup"
    $titleLabel.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
    $titleLabel.ForeColor = [System.Drawing.Color]::FromArgb(122, 162, 247)
    $titleLabel.AutoSize = $true
    $titleLabel.Location = New-Object System.Drawing.Point(30, 20)
    $form.Controls.Add($titleLabel)

    # Subtitle
    $subLabel = New-Object System.Windows.Forms.Label
    $subLabel.Text = "Enter your license key to begin installation."
    $subLabel.AutoSize = $true
    $subLabel.Location = New-Object System.Drawing.Point(30, 55)
    $form.Controls.Add($subLabel)

    # Key entry
    $keyLabel = New-Object System.Windows.Forms.Label
    $keyLabel.Text = "License Key:"
    $keyLabel.AutoSize = $true
    $keyLabel.Location = New-Object System.Drawing.Point(30, 95)
    $form.Controls.Add($keyLabel)

    $keyBox = New-Object System.Windows.Forms.TextBox
    $keyBox.Font = New-Object System.Drawing.Font("Consolas", 13)
    $keyBox.Location = New-Object System.Drawing.Point(30, 120)
    $keyBox.Size = New-Object System.Drawing.Size(440, 30)
    $keyBox.BackColor = [System.Drawing.Color]::FromArgb(36, 40, 59)
    $keyBox.ForeColor = [System.Drawing.Color]::FromArgb(192, 202, 245)
    $keyBox.BorderStyle = "FixedSingle"
    $keyBox.TextAlign = "Center"
    $form.Controls.Add($keyBox)

    # Status label
    $statusLabel = New-Object System.Windows.Forms.Label
    $statusLabel.Text = ""
    $statusLabel.Location = New-Object System.Drawing.Point(30, 160)
    $statusLabel.Size = New-Object System.Drawing.Size(440, 40)
    $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(192, 202, 245)
    $form.Controls.Add($statusLabel)

    # Progress bar
    $progressBar = New-Object System.Windows.Forms.ProgressBar
    $progressBar.Location = New-Object System.Drawing.Point(30, 210)
    $progressBar.Size = New-Object System.Drawing.Size(440, 25)
    $progressBar.Style = "Continuous"
    $progressBar.Visible = $false
    $form.Controls.Add($progressBar)

    # Progress detail label
    $progressLabel = New-Object System.Windows.Forms.Label
    $progressLabel.Text = ""
    $progressLabel.Location = New-Object System.Drawing.Point(30, 240)
    $progressLabel.Size = New-Object System.Drawing.Size(440, 25)
    $progressLabel.ForeColor = [System.Drawing.Color]::FromArgb(150, 160, 200)
    $progressLabel.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $progressLabel.Visible = $false
    $form.Controls.Add($progressLabel)

    # Buttons
    $activateBtn = New-Object System.Windows.Forms.Button
    $activateBtn.Text = "Activate && Install"
    $activateBtn.Size = New-Object System.Drawing.Size(160, 38)
    $activateBtn.Location = New-Object System.Drawing.Point(130, 280)
    $activateBtn.BackColor = [System.Drawing.Color]::FromArgb(122, 162, 247)
    $activateBtn.ForeColor = [System.Drawing.Color]::FromArgb(26, 27, 38)
    $activateBtn.FlatStyle = "Flat"
    $activateBtn.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
    $form.Controls.Add($activateBtn)

    $quitBtn = New-Object System.Windows.Forms.Button
    $quitBtn.Text = "Quit"
    $quitBtn.Size = New-Object System.Drawing.Size(90, 38)
    $quitBtn.Location = New-Object System.Drawing.Point(310, 280)
    $quitBtn.BackColor = [System.Drawing.Color]::FromArgb(50, 55, 75)
    $quitBtn.ForeColor = [System.Drawing.Color]::FromArgb(192, 202, 245)
    $quitBtn.FlatStyle = "Flat"
    $form.Controls.Add($quitBtn)

    # Bottom status
    $bottomLabel = New-Object System.Windows.Forms.Label
    $bottomLabel.Text = ""
    $bottomLabel.Location = New-Object System.Drawing.Point(30, 335)
    $bottomLabel.Size = New-Object System.Drawing.Size(440, 40)
    $bottomLabel.ForeColor = [System.Drawing.Color]::FromArgb(150, 160, 200)
    $bottomLabel.Font = New-Object System.Drawing.Font("Segoe UI", 8.5)
    $form.Controls.Add($bottomLabel)

    $result = @{ Success = $false }

    $quitBtn.Add_Click({ $form.Close() })

    $keyBox.Add_KeyDown({
        if ($_.KeyCode -eq "Return") { $activateBtn.PerformClick() }
    })

    $activateBtn.Add_Click({
        $key = $keyBox.Text.Trim()
        if (-not $key) {
            $statusLabel.Text = "Please enter a license key."
            $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(247, 118, 142)
            return
        }

        $activateBtn.Enabled = $false
        $quitBtn.Enabled = $false
        $keyBox.Enabled = $false
        $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(224, 175, 104)
        $statusLabel.Text = "Validating license key..."
        $form.Refresh()

        # ── Step 1: Validate key with server ──
        $machineId = Get-MachineId
        $machineLabel = Get-MachineLabel

        $resp = Invoke-LicenseApi -Endpoint "/api/license/activate" -Body @{
            license_key   = $key
            machine_id    = $machineId
            machine_label = $machineLabel
            force_takeover = $false
        }

        if ($resp.Code -eq 200 -and $resp.Body.status -eq "activated") {
            $statusLabel.Text = "License validated!"
            $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(158, 206, 106)
            $form.Refresh()

            # Save validated key + encrypted data for Python to complete activation
            @{
                license_key          = $key.ToUpper()
                machine_id           = $machineId
                license_id           = $resp.Body.license_id
                product_id           = $resp.Body.product_id
                encrypted_master_key = $resp.Body.encrypted_master_key
                validated_at         = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
            } | ConvertTo-Json | Set-Content -Path $KEY_FILE -Encoding UTF8

        } elseif ($resp.Code -eq 409) {
            # Activation limit — ask about force takeover
            $msg = if ($resp.Body.message) { $resp.Body.message } else { "Activation limit reached." }
            $answer = [System.Windows.Forms.MessageBox]::Show(
                "$msg`n`nDo you want to deactivate all other machines and bind this one?",
                "Activation Limit",
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Question
            )
            if ($answer -eq "Yes") {
                $statusLabel.Text = "Force takeover in progress..."
                $form.Refresh()
                $resp2 = Invoke-LicenseApi -Endpoint "/api/license/activate" -Body @{
                    license_key    = $key
                    machine_id     = $machineId
                    machine_label  = $machineLabel
                    force_takeover = $true
                }
                if ($resp2.Code -eq 200 -and $resp2.Body.status -eq "activated") {
                    $statusLabel.Text = "License validated (previous machines deactivated)!"
                    $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(158, 206, 106)
                    $form.Refresh()

                    @{
                        license_key          = $key.ToUpper()
                        machine_id           = $machineId
                        license_id           = $resp2.Body.license_id
                        product_id           = $resp2.Body.product_id
                        encrypted_master_key = $resp2.Body.encrypted_master_key
                        validated_at         = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
                    } | ConvertTo-Json | Set-Content -Path $KEY_FILE -Encoding UTF8
                } else {
                    $errMsg = if ($resp2.Body.message) { $resp2.Body.message } elseif ($resp2.Body.error) { $resp2.Body.error } else { "Force takeover failed." }
                    $statusLabel.Text = $errMsg
                    $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(247, 118, 142)
                    $activateBtn.Enabled = $true
                    $quitBtn.Enabled = $true
                    $keyBox.Enabled = $true
                    return
                }
            } else {
                $statusLabel.Text = "Activation cancelled."
                $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(247, 118, 142)
                $activateBtn.Enabled = $true
                $quitBtn.Enabled = $true
                $keyBox.Enabled = $true
                return
            }
        } elseif ($resp.Code -eq 404) {
            $statusLabel.Text = "Invalid license key."
            $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(247, 118, 142)
            $activateBtn.Enabled = $true
            $quitBtn.Enabled = $true
            $keyBox.Enabled = $true
            return
        } elseif ($resp.Code -eq 0) {
            $statusLabel.Text = "Cannot reach activation server. Check your internet."
            $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(247, 118, 142)
            $activateBtn.Enabled = $true
            $quitBtn.Enabled = $true
            $keyBox.Enabled = $true
            return
        } else {
            $errMsg = if ($resp.Body.error) { $resp.Body.error } elseif ($resp.Body.message) { $resp.Body.message } else { "Server returned $($resp.Code)" }
            $statusLabel.Text = $errMsg
            $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(247, 118, 142)
            $activateBtn.Enabled = $true
            $quitBtn.Enabled = $true
            $keyBox.Enabled = $true
            return
        }

        # ── Step 2: Download FLUX_env.zip ──
        Start-Sleep -Milliseconds 500
        $statusLabel.Text = "Downloading Python environment from HuggingFace..."
        $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(224, 175, 104)
        $progressBar.Visible = $true
        $progressBar.Value = 0
        $progressLabel.Visible = $true
        $progressLabel.Text = "Connecting..."
        $bottomLabel.Text = "This is a one-time download (~2.5 GB). Please keep this window open."
        $form.Refresh()

        try {
            $webClient = New-Object System.Net.WebClient
            $uri = New-Object System.Uri($ENV_URL)
            $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

            $webClient.add_DownloadProgressChanged({
                param($sender, $e)
                $form.Invoke([Action]{
                    $progressBar.Value = $e.ProgressPercentage
                    $receivedMB = [math]::Round($e.BytesReceived / 1MB, 0)
                    $totalMB = [math]::Round($e.TotalBytesToReceive / 1MB, 0)
                    $elapsed = $stopwatch.Elapsed.ToString("hh\:mm\:ss")
                    if ($e.BytesReceived -gt 0 -and $stopwatch.Elapsed.TotalSeconds -gt 2) {
                        $speed = [math]::Round($e.BytesReceived / $stopwatch.Elapsed.TotalSeconds / 1MB, 1)
                        $progressLabel.Text = "$receivedMB MB / $totalMB MB  |  $speed MB/s  |  $elapsed"
                    } else {
                        $progressLabel.Text = "$receivedMB MB / $totalMB MB  |  $elapsed"
                    }
                    $statusLabel.Text = "Downloading... $($e.ProgressPercentage)%"
                })
            })

            $downloadDone = $false
            $downloadError = $null
            $webClient.add_DownloadFileCompleted({
                param($sender, $e)
                if ($e.Error) { $script:downloadError = $e.Error.Message }
                $script:downloadDone = $true
            })

            $webClient.DownloadFileAsync($uri, $ENV_ZIP)

            while (-not $script:downloadDone) {
                [System.Windows.Forms.Application]::DoEvents()
                Start-Sleep -Milliseconds 100
            }
            $stopwatch.Stop()

            if ($script:downloadError) { throw $script:downloadError }
            if (-not (Test-Path $ENV_ZIP)) { throw "Download completed but file not found." }

            $sizeMB = [math]::Round((Get-Item $ENV_ZIP).Length / 1MB, 0)
            $statusLabel.Text = "Download complete ($sizeMB MB)"
            $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(158, 206, 106)
            $form.Refresh()

        } catch {
            $statusLabel.Text = "Download failed: $($_.Exception.Message)"
            $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(247, 118, 142)
            $progressBar.Visible = $false
            $progressLabel.Visible = $false
            $bottomLabel.Text = "You can retry by running Launch FLUX.bat again."
            $activateBtn.Enabled = $true
            $quitBtn.Enabled = $true
            $keyBox.Enabled = $true
            return
        }

        # ── Step 3: Extract ──
        Start-Sleep -Milliseconds 500
        $statusLabel.Text = "Extracting environment (this takes a few minutes)..."
        $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(224, 175, 104)
        $progressBar.Value = 0
        $progressLabel.Text = "Opening archive..."
        $bottomLabel.Text = "Extracting files. Please wait..."
        $form.Refresh()

        try {
            Add-Type -AssemblyName System.IO.Compression.FileSystem
            $archive = [System.IO.Compression.ZipFile]::OpenRead($ENV_ZIP)
            $total = $archive.Entries.Count
            $count = 0
            $lastPct = -1

            foreach ($entry in $archive.Entries) {
                $count++
                $pct = [math]::Floor($count * 100 / $total)
                if ($pct -ne $lastPct) {
                    $lastPct = $pct
                    $progressBar.Value = $pct
                    $progressLabel.Text = "$count / $total files  ($pct%)"
                    $statusLabel.Text = "Extracting... $pct%"
                    [System.Windows.Forms.Application]::DoEvents()
                }

                $targetPath = Join-Path $InstallDir $entry.FullName
                $targetDir = Split-Path $targetPath -Parent
                if (-not (Test-Path $targetDir)) {
                    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
                }
                if ($entry.Name -ne "") {
                    [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $targetPath, $true)
                }
            }
            $archive.Dispose()

            $statusLabel.Text = "Extraction complete!"
            $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(158, 206, 106)
            $progressBar.Value = 100
            $form.Refresh()

        } catch {
            $statusLabel.Text = "Extraction failed: $($_.Exception.Message)"
            $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(247, 118, 142)
            $bottomLabel.Text = "Try deleting FLUX_env.zip and running Launch FLUX.bat again."
            $activateBtn.Enabled = $true
            $quitBtn.Enabled = $true
            $keyBox.Enabled = $true
            return
        }

        # ── Step 4: Cleanup & finish ──
        Remove-Item $ENV_ZIP -Force -ErrorAction SilentlyContinue

        if (-not (Test-Path (Join-Path $InstallDir "python312.exe"))) {
            $statusLabel.Text = "Error: python312.exe not found after extraction."
            $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(247, 118, 142)
            $bottomLabel.Text = "The FLUX_env.zip may have an unexpected structure."
            $activateBtn.Enabled = $true
            $quitBtn.Enabled = $true
            $keyBox.Enabled = $true
            return
        }

        $statusLabel.Text = "Setup complete! Launching FLUX.2 Klein..."
        $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(158, 206, 106)
        $progressBar.Visible = $false
        $progressLabel.Visible = $false
        $bottomLabel.Text = ""
        $form.Refresh()
        Start-Sleep -Seconds 2

        $result.Success = $true
        $form.Close()
    })

    $form.Add_Shown({ $keyBox.Focus() })
    [void]$form.ShowDialog()
    return $result.Success
}

# ── Main ────────────────────────────────────────────────────
$ok = Show-SetupForm
if ($ok) {
    exit 0
} else {
    exit 1
}
