"""
Developer-only tool: Encrypt the .engine model folder → .engine_enc
with obfuscated filenames (f001.dat, f002.dat, ...).

Usage:
    python encrypt_engine.py                      # generates random license key
    python encrypt_engine.py --key MY_SECRET      # use a specific key
    python encrypt_engine.py --delete-source       # remove .engine after encrypting
"""
from __future__ import annotations

import argparse
import json
import os
import secrets
import shutil
import sys
import time

from engine_crypto import (
    encrypt_file,
    encrypt_bytes,
    VERIFY_PLAINTEXT,
    VERIFY_FILE,
    MANIFEST_FILE,
)

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ENGINE_DIR = os.path.join(SCRIPT_DIR, ".engine")
ENC_DIR = os.path.join(SCRIPT_DIR, ".engine_enc")
LICENSE_FILE = os.path.join(SCRIPT_DIR, ".license")


def generate_license_key() -> str:
    return secrets.token_hex(16)


def main() -> None:
    parser = argparse.ArgumentParser(description="Encrypt OCR engine model weights")
    parser.add_argument("--key", type=str, default=None,
                        help="License key. Random if omitted.")
    parser.add_argument("--delete-source", action="store_true",
                        help="Delete plaintext .engine after encrypting.")
    args = parser.parse_args()

    if not os.path.isdir(ENGINE_DIR):
        print(f"Error: {ENGINE_DIR} not found. Download the model first.", file=sys.stderr)
        sys.exit(1)

    license_key = args.key or generate_license_key()

    # Collect all source files
    all_files: list[str] = []
    for root, _dirs, files in os.walk(ENGINE_DIR):
        for fname in files:
            all_files.append(os.path.join(root, fname))

    total = len(all_files) + 2  # +1 manifest, +1 verify
    print(f"Encrypting {len(all_files)} files with AES-256-GCM (obfuscated names) ...")
    print(f"License key: {license_key}")
    print()

    if os.path.isdir(ENC_DIR):
        shutil.rmtree(ENC_DIR)
    os.makedirs(ENC_DIR, exist_ok=True)

    # Build manifest: obfuscated name → original relative path
    manifest: dict[str, str] = {}

    t0 = time.time()
    for i, src in enumerate(all_files, 1):
        rel = os.path.relpath(src, ENGINE_DIR)
        obfuscated = f"f{i:04d}.dat"
        manifest[obfuscated] = rel.replace("\\", "/")  # normalize to forward slash
        dst = os.path.join(ENC_DIR, obfuscated)
        encrypt_file(src, dst, license_key)
        pct = int(i / total * 100)
        print(f"\r  [{pct:3d}%] {i}/{total}", end="", flush=True)

    # Encrypt the manifest itself
    manifest_json = json.dumps(manifest, ensure_ascii=False).encode("utf-8")
    encrypt_bytes(manifest_json, os.path.join(ENC_DIR, MANIFEST_FILE), license_key)
    print(f"\r  [{int((len(all_files)+1)/total*100):3d}%] {len(all_files)+1}/{total}  manifest", end="", flush=True)

    # Encrypt the verification token
    encrypt_bytes(VERIFY_PLAINTEXT, os.path.join(ENC_DIR, VERIFY_FILE), license_key)
    print(f"\r  [100%] {total}/{total}  verify   ")

    elapsed = time.time() - t0
    print(f"\nDone in {elapsed:.1f}s.  ({len(manifest)} files encrypted)")
    print(f"Encrypted folder: {ENC_DIR}")

    # Save license key
    with open(LICENSE_FILE, "w") as f:
        f.write(license_key)
    print(f"License saved to: {LICENSE_FILE}")

    # Hide on Windows
    if sys.platform == "win32":
        import ctypes
        ctypes.windll.kernel32.SetFileAttributesW(ENC_DIR, 0x02)

    if args.delete_source:
        print(f"Deleting plaintext: {ENGINE_DIR}")
        shutil.rmtree(ENGINE_DIR)
        print("Plaintext removed.")
    else:
        print(f"\nPlaintext still at: {ENGINE_DIR}")
        print("Run with --delete-source to remove it.")


if __name__ == "__main__":
    main()
