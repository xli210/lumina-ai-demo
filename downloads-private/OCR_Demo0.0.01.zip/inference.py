"""OCR Engine – CLI inference (supports encrypted model weights)."""
from __future__ import annotations

import atexit
import os
import shutil
import sys
import tempfile
import warnings
import logging

# Suppress all library chatter
warnings.filterwarnings("ignore")
os.environ["TRANSFORMERS_NO_ADVISORY_WARNINGS"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"
os.environ["TRANSFORMERS_VERBOSITY"] = "error"
logging.disable(logging.WARNING)

import io as _io
_real_stderr = sys.stderr
sys.stderr = _io.StringIO()

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_ENGINE_DIR = os.path.join(SCRIPT_DIR, ".engine")
_ENC_DIR = os.path.join(SCRIPT_DIR, ".engine_enc")
_LICENSE_FILE = os.path.join(SCRIPT_DIR, ".license")

# ---- Settings ----
image_path = os.path.join(SCRIPT_DIR, "test.png")
task = "ocr"  # Options: 'ocr' | 'table' | 'chart' | 'formula' | 'spotting' | 'seal'
# ------------------

_DEMO_URL = "https://paddle-model-ecology.bj.bcebos.com/paddlex/imgs/demo_image/paddleocr_vl_demo.png"
_temp_model_dir: str | None = None


def _cleanup_temp():
    global _temp_model_dir
    if _temp_model_dir and os.path.isdir(_temp_model_dir):
        shutil.rmtree(_temp_model_dir, ignore_errors=True)
        _temp_model_dir = None

atexit.register(_cleanup_temp)


def _read_license() -> str | None:
    if os.path.isfile(_LICENSE_FILE):
        with open(_LICENSE_FILE, "r") as f:
            key = f.read().strip()
        return key if key else None
    return None


def _resolve_engine() -> str:
    """Resolve model path: encrypted → plaintext → remote."""
    global _temp_model_dir

    if os.path.isdir(_ENC_DIR):
        from engine_crypto import verify_license, decrypt_engine
        license_key = _read_license()
        if not license_key:
            sys.stderr = _real_stderr
            print("[RESULT] Error: .license file not found.", file=sys.stderr)
            sys.exit(1)
        if not verify_license(_ENC_DIR, license_key):
            sys.stderr = _real_stderr
            print("[RESULT] Error: Invalid license key.", file=sys.stderr)
            sys.exit(1)
        _temp_model_dir = tempfile.mkdtemp(prefix="ocr_engine_")
        decrypt_engine(_ENC_DIR, _temp_model_dir, license_key)
        return _temp_model_dir

    if os.path.isdir(_ENGINE_DIR):
        return _ENGINE_DIR
    return "PaddlePaddle/PaddleOCR-VL-1.5"


def _ensure_image(path: str) -> str:
    if os.path.isfile(path):
        return path
    try:
        import urllib.request
        urllib.request.urlretrieve(_DEMO_URL, path)
        return path
    except Exception as e:
        sys.stderr = _real_stderr
        print(f"[RESULT] Error: could not load image ({e})", file=sys.stderr)
        sys.exit(1)


def main() -> None:
    from PIL import Image
    import torch
    from transformers import AutoProcessor, AutoModelForImageTextToText

    engine_path = _resolve_engine()

    image_file = _ensure_image(image_path)
    image = Image.open(image_file).convert("RGB")
    orig_w, orig_h = image.size

    if task == "spotting" and orig_w < 1500 and orig_h < 1500:
        try:
            resample = Image.Resampling.LANCZOS
        except AttributeError:
            resample = Image.LANCZOS
        image = image.resize((orig_w * 2, orig_h * 2), resample)

    max_pixels = 2048 * 28 * 28 if task == "spotting" else 1280 * 28 * 28
    device = "cuda" if torch.cuda.is_available() else "cpu"
    prompts = {
        "ocr": "OCR:", "table": "Table Recognition:",
        "formula": "Formula Recognition:", "chart": "Chart Recognition:",
        "spotting": "Spotting:", "seal": "Seal Recognition:",
    }

    model = AutoModelForImageTextToText.from_pretrained(
        engine_path, torch_dtype=torch.bfloat16, low_cpu_mem_usage=True
    ).to(device).eval()
    processor = AutoProcessor.from_pretrained(engine_path)
    _cleanup_temp()

    messages = [{"role": "user", "content": [
        {"type": "image", "image": image},
        {"type": "text", "text": prompts[task]},
    ]}]
    inputs = processor.apply_chat_template(
        messages, add_generation_prompt=True, tokenize=True,
        return_dict=True, return_tensors="pt",
        images_kwargs={"size": {
            "shortest_edge": processor.image_processor.min_pixels,
            "longest_edge": max_pixels,
        }},
    ).to(model.device)

    outputs = model.generate(**inputs, max_new_tokens=512)
    result = processor.decode(outputs[0][inputs["input_ids"].shape[-1] : -1])
    sys.stderr = _real_stderr
    print(f"[RESULT] {result}")


if __name__ == "__main__":
    main()
