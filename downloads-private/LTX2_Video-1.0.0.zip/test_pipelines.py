"""
End-to-end test for all LTX-2 pipelines.
Tests each pipeline with minimal settings to verify they work without OOM.
"""

import gc
import os
import sys
import time
import traceback
from pathlib import Path

# Note: expandable_segments not needed for RTX 5090 nightly builds

import torch

# Try importing from site-packages first (product mode / BUILD.bat env).
# Fall back to development mode (LTX-2 repo checked out alongside this file).
try:
    import ltx_core  # noqa: F401
except ImportError:
    LTX2_ROOT = Path(__file__).parent / "LTX-2"
    sys.path.insert(0, str(LTX2_ROOT / "packages" / "ltx-core" / "src"))
    sys.path.insert(0, str(LTX2_ROOT / "packages" / "ltx-pipelines" / "src"))

def get_fp8_native_quant():
    """Get a quantization policy that preserves the checkpoint's native mixed FP8/BF16 format.

    The FP8 checkpoints store blocks 1-42 as float8_e4m3fn and blocks 0, 43-47
    as bfloat16. This policy preserves those original dtypes (no naive downcast)
    and drops the weight_scale/input_scale keys (all 1.0) to ensure correct LoRA fusion.
    """
    from ltx_core.quantization import QuantizationPolicy
    from ltx_core.quantization.fp8_cast import UPCAST_DURING_INFERENCE
    from ltx_core.loader.sd_ops import SDOps

    def _drop_key(key, value):
        return []

    drop_scales_ops = (
        SDOps("DROP_FP8_SCALE_KEYS")
        .with_kv_operation(operation=_drop_key, key_suffix=".weight_scale")
        .with_kv_operation(operation=_drop_key, key_suffix=".input_scale")
    )

    return QuantizationPolicy(sd_ops=drop_scales_ops, module_ops=(UPCAST_DURING_INFERENCE,))

MODELS_DIR = Path(__file__).parent / "models"
LORAS_DIR = MODELS_DIR / "loras"
OUTPUTS_DIR = Path(__file__).parent / "outputs"
OUTPUTS_DIR.mkdir(exist_ok=True)

DISTILLED_CHECKPOINT = str(MODELS_DIR / "ltx-2-19b-distilled-fp8.safetensors")
DEV_CHECKPOINT = str(MODELS_DIR / "ltx-2-19b-dev-fp8.safetensors")
UPSAMPLER = str(MODELS_DIR / "ltx-2-spatial-upscaler-x2-1.0.safetensors")
DISTILLED_LORA = str(MODELS_DIR / "ltx-2-19b-distilled-lora-384.safetensors")
GEMMA_ROOT = str(MODELS_DIR / "gemma")
# Use dev checkpoint for LoRA pipelines, distilled for non-LoRA distilled pipeline
CHECKPOINT = DISTILLED_CHECKPOINT  # Default for distilled
LORA_CHECKPOINT = DEV_CHECKPOINT if Path(DEV_CHECKPOINT).exists() else DISTILLED_CHECKPOINT

# Test settings - reduced for memory safety
TEST_HEIGHT = 1024
TEST_WIDTH = 1536
TEST_FRAMES = 57  # 8*7+1
TEST_FPS = 24.0
TEST_SEED = 42
TEST_STEPS = 40
TEST_PROMPT = "A majestic eagle soaring over a vast mountain range at sunset, golden light illuminating the peaks, the eagle's wings spread wide as it glides through wisps of clouds, camera slowly following from below."


def cleanup():
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.synchronize()


def gpu_memory_info():
    if torch.cuda.is_available():
        allocated = torch.cuda.memory_allocated(0) / (1024**3)
        reserved = torch.cuda.memory_reserved(0) / (1024**3)
        total = torch.cuda.get_device_properties(0).total_memory / (1024**3)
        return f"GPU: {allocated:.1f}GB allocated, {reserved:.1f}GB reserved, {total:.1f}GB total"
    return "No CUDA"


def test_distilled_pipeline():
    """Test 1: DistilledPipeline - fastest, no guidance needed."""
    print("\n" + "="*70)
    print("TEST 1: DistilledPipeline (Fast Generation)")
    print("="*70)
    print(f"Settings: {TEST_HEIGHT}x{TEST_WIDTH}, {TEST_FRAMES} frames")
    print(f"Memory before: {gpu_memory_info()}")

    from ltx_core.model.video_vae import TilingConfig, get_video_chunks_number
    from ltx_pipelines.distilled import DistilledPipeline
    from ltx_pipelines.utils.constants import AUDIO_SAMPLE_RATE
    from ltx_pipelines.utils.media_io import encode_video

    cleanup()
    start = time.time()

    pipeline = DistilledPipeline(
        checkpoint_path=DISTILLED_CHECKPOINT,
        gemma_root=GEMMA_ROOT,
        spatial_upsampler_path=UPSAMPLER,
        loras=[],
        quantization=get_fp8_native_quant(),
    )

    tiling_config = TilingConfig.default()
    video_chunks_number = get_video_chunks_number(TEST_FRAMES, tiling_config)

    with torch.inference_mode():
        video, audio = pipeline(
            prompt=TEST_PROMPT,
            seed=TEST_SEED,
            height=TEST_HEIGHT,
            width=TEST_WIDTH,
            num_frames=TEST_FRAMES,
            frame_rate=TEST_FPS,
            images=[],
            tiling_config=tiling_config,
        )

    output_path = str(OUTPUTS_DIR / "test_distilled.mp4")
    encode_video(
        video=video,
        fps=TEST_FPS,
        audio=audio,
        audio_sample_rate=AUDIO_SAMPLE_RATE,
        output_path=output_path,
        video_chunks_number=video_chunks_number,
    )

    elapsed = time.time() - start
    size_mb = Path(output_path).stat().st_size / (1024*1024)
    print(f"SUCCESS: {output_path} ({size_mb:.1f} MB, {elapsed:.1f}s)")
    print(f"Memory after: {gpu_memory_info()}")
    del pipeline
    cleanup()
    return True


def test_distilled_with_camera_lora():
    """Test 2: DistilledPipeline with Camera Control LoRA."""
    print("\n" + "="*70)
    print("TEST 2: DistilledPipeline + Camera LoRA (Dolly In)")
    print("="*70)

    from ltx_core.loader import LTXV_LORA_COMFY_RENAMING_MAP, LoraPathStrengthAndSDOps
    from ltx_core.model.video_vae import TilingConfig, get_video_chunks_number
    from ltx_pipelines.distilled import DistilledPipeline
    from ltx_pipelines.utils.constants import AUDIO_SAMPLE_RATE
    from ltx_pipelines.utils.media_io import encode_video

    cleanup()
    start = time.time()

    lora_path = str(LORAS_DIR / "ltx-2-19b-lora-camera-control-dolly-in.safetensors")
    loras = [LoraPathStrengthAndSDOps(lora_path, 1.0, LTXV_LORA_COMFY_RENAMING_MAP)]

    pipeline = DistilledPipeline(
        checkpoint_path=LORA_CHECKPOINT,
        gemma_root=GEMMA_ROOT,
        spatial_upsampler_path=UPSAMPLER,
        loras=loras,
        quantization=get_fp8_native_quant(),
    )

    tiling_config = TilingConfig.default()
    video_chunks_number = get_video_chunks_number(TEST_FRAMES, tiling_config)

    with torch.inference_mode():
        video, audio = pipeline(
            prompt=TEST_PROMPT,
            seed=TEST_SEED,
            height=TEST_HEIGHT,
            width=TEST_WIDTH,
            num_frames=TEST_FRAMES,
            frame_rate=TEST_FPS,
            images=[],
            tiling_config=tiling_config,
        )

    output_path = str(OUTPUTS_DIR / "test_distilled_camera_dolly_in.mp4")
    encode_video(
        video=video,
        fps=TEST_FPS,
        audio=audio,
        audio_sample_rate=AUDIO_SAMPLE_RATE,
        output_path=output_path,
        video_chunks_number=video_chunks_number,
    )

    elapsed = time.time() - start
    size_mb = Path(output_path).stat().st_size / (1024*1024)
    print(f"SUCCESS: {output_path} ({size_mb:.1f} MB, {elapsed:.1f}s)")
    print(f"Memory after: {gpu_memory_info()}")
    del pipeline
    cleanup()
    return True


def test_two_stage_pipeline():
    """Test 3: TI2VidTwoStagesPipeline - production quality."""
    print("\n" + "="*70)
    print("TEST 3: TI2VidTwoStagesPipeline (Production Quality)")
    print("="*70)
    print(f"Settings: {TEST_HEIGHT}x{TEST_WIDTH}, {TEST_FRAMES} frames, {TEST_STEPS} steps")
    print(f"Memory before: {gpu_memory_info()}")

    from ltx_core.components.guiders import MultiModalGuiderParams
    from ltx_core.loader import LTXV_LORA_COMFY_RENAMING_MAP, LoraPathStrengthAndSDOps
    from ltx_core.model.video_vae import TilingConfig, get_video_chunks_number
    from ltx_pipelines.ti2vid_two_stages import TI2VidTwoStagesPipeline
    from ltx_pipelines.utils.constants import AUDIO_SAMPLE_RATE
    from ltx_pipelines.utils.media_io import encode_video

    cleanup()
    start = time.time()

    distilled_lora = [
        LoraPathStrengthAndSDOps(DISTILLED_LORA, 0.8, LTXV_LORA_COMFY_RENAMING_MAP),
    ]

    pipeline = TI2VidTwoStagesPipeline(
        checkpoint_path=LORA_CHECKPOINT,
        distilled_lora=distilled_lora,
        spatial_upsampler_path=UPSAMPLER,
        gemma_root=GEMMA_ROOT,
        loras=[],
        quantization=get_fp8_native_quant(),
    )

    video_guider = MultiModalGuiderParams(
        cfg_scale=3.0, stg_scale=1.0, rescale_scale=0.7,
        modality_scale=3.0, skip_step=0, stg_blocks=[29],
    )
    audio_guider = MultiModalGuiderParams(
        cfg_scale=7.0, stg_scale=1.0, rescale_scale=0.7,
        modality_scale=3.0, skip_step=0, stg_blocks=[29],
    )

    tiling_config = TilingConfig.default()
    video_chunks_number = get_video_chunks_number(TEST_FRAMES, tiling_config)

    with torch.inference_mode():
        video, audio = pipeline(
            prompt=TEST_PROMPT,
            negative_prompt="blurry, low quality, distorted",
            seed=TEST_SEED,
            height=TEST_HEIGHT,
            width=TEST_WIDTH,
            num_frames=TEST_FRAMES,
            frame_rate=TEST_FPS,
            num_inference_steps=TEST_STEPS,
            video_guider_params=video_guider,
            audio_guider_params=audio_guider,
            images=[],
            tiling_config=tiling_config,
        )

    output_path = str(OUTPUTS_DIR / "test_twostage.mp4")
    encode_video(
        video=video,
        fps=TEST_FPS,
        audio=audio,
        audio_sample_rate=AUDIO_SAMPLE_RATE,
        output_path=output_path,
        video_chunks_number=video_chunks_number,
    )

    elapsed = time.time() - start
    size_mb = Path(output_path).stat().st_size / (1024*1024)
    print(f"SUCCESS: {output_path} ({size_mb:.1f} MB, {elapsed:.1f}s)")
    print(f"Memory after: {gpu_memory_info()}")
    del pipeline
    cleanup()
    return True


def test_two_stage_with_camera_lora():
    """Test 4: TI2VidTwoStagesPipeline + Camera LoRA (Static)."""
    print("\n" + "="*70)
    print("TEST 4: TI2VidTwoStagesPipeline + Camera LoRA (Static)")
    print("="*70)

    from ltx_core.components.guiders import MultiModalGuiderParams
    from ltx_core.loader import LTXV_LORA_COMFY_RENAMING_MAP, LoraPathStrengthAndSDOps
    from ltx_core.model.video_vae import TilingConfig, get_video_chunks_number
    from ltx_pipelines.ti2vid_two_stages import TI2VidTwoStagesPipeline
    from ltx_pipelines.utils.constants import AUDIO_SAMPLE_RATE
    from ltx_pipelines.utils.media_io import encode_video

    cleanup()
    start = time.time()

    distilled_lora = [
        LoraPathStrengthAndSDOps(DISTILLED_LORA, 0.8, LTXV_LORA_COMFY_RENAMING_MAP),
    ]
    camera_lora = str(LORAS_DIR / "ltx-2-19b-lora-camera-control-static.safetensors")
    loras = [LoraPathStrengthAndSDOps(camera_lora, 1.0, LTXV_LORA_COMFY_RENAMING_MAP)]

    pipeline = TI2VidTwoStagesPipeline(
        checkpoint_path=LORA_CHECKPOINT,
        distilled_lora=distilled_lora,
        spatial_upsampler_path=UPSAMPLER,
        gemma_root=GEMMA_ROOT,
        loras=loras,
        quantization=get_fp8_native_quant(),
    )

    video_guider = MultiModalGuiderParams(
        cfg_scale=3.0, stg_scale=1.0, rescale_scale=0.7,
        modality_scale=3.0, skip_step=0, stg_blocks=[29],
    )
    audio_guider = MultiModalGuiderParams(
        cfg_scale=7.0, stg_scale=1.0, rescale_scale=0.7,
        modality_scale=3.0, skip_step=0, stg_blocks=[29],
    )

    tiling_config = TilingConfig.default()
    video_chunks_number = get_video_chunks_number(TEST_FRAMES, tiling_config)

    with torch.inference_mode():
        video, audio = pipeline(
            prompt=TEST_PROMPT,
            negative_prompt="blurry, low quality",
            seed=TEST_SEED,
            height=TEST_HEIGHT,
            width=TEST_WIDTH,
            num_frames=TEST_FRAMES,
            frame_rate=TEST_FPS,
            num_inference_steps=TEST_STEPS,
            video_guider_params=video_guider,
            audio_guider_params=audio_guider,
            images=[],
            tiling_config=tiling_config,
        )

    output_path = str(OUTPUTS_DIR / "test_twostage_camera_static.mp4")
    encode_video(
        video=video,
        fps=TEST_FPS,
        audio=audio,
        audio_sample_rate=AUDIO_SAMPLE_RATE,
        output_path=output_path,
        video_chunks_number=video_chunks_number,
    )

    elapsed = time.time() - start
    size_mb = Path(output_path).stat().st_size / (1024*1024)
    print(f"SUCCESS: {output_path} ({size_mb:.1f} MB, {elapsed:.1f}s)")
    del pipeline
    cleanup()
    return True


def test_ic_lora_pipeline():
    """Test 5: ICLoraPipeline with Detailer LoRA (no video conditioning - just image)."""
    print("\n" + "="*70)
    print("TEST 5: ICLoraPipeline + Detailer LoRA")
    print("="*70)

    from ltx_core.loader import LTXV_LORA_COMFY_RENAMING_MAP, LoraPathStrengthAndSDOps
    from ltx_core.model.video_vae import TilingConfig, get_video_chunks_number
    from ltx_pipelines.ic_lora import ICLoraPipeline
    from ltx_pipelines.utils.constants import AUDIO_SAMPLE_RATE
    from ltx_pipelines.utils.media_io import encode_video

    cleanup()
    start = time.time()

    detailer_lora = str(LORAS_DIR / "ltx-2-19b-ic-lora-detailer.safetensors")
    loras = [LoraPathStrengthAndSDOps(detailer_lora, 1.0, LTXV_LORA_COMFY_RENAMING_MAP)]

    pipeline = ICLoraPipeline(
        checkpoint_path=LORA_CHECKPOINT,
        spatial_upsampler_path=UPSAMPLER,
        gemma_root=GEMMA_ROOT,
        loras=loras,
        quantization=get_fp8_native_quant(),
    )

    # Use a generated video from test 1 as conditioning (if it exists)
    video_cond_path = str(OUTPUTS_DIR / "test_distilled.mp4")
    video_conditioning = []
    if Path(video_cond_path).exists():
        video_conditioning = [(video_cond_path, 1.0)]
        print(f"Using video conditioning: {video_cond_path}")
    else:
        print("No video conditioning available, running without")

    tiling_config = TilingConfig.default()
    video_chunks_number = get_video_chunks_number(TEST_FRAMES, tiling_config)

    with torch.inference_mode():
        video, audio = pipeline(
            prompt="A detailed, enhanced version of the scene with sharper textures and richer colors, cinematic quality.",
            seed=TEST_SEED,
            height=TEST_HEIGHT,
            width=TEST_WIDTH,
            num_frames=TEST_FRAMES,
            frame_rate=TEST_FPS,
            images=[],
            video_conditioning=video_conditioning,
            tiling_config=tiling_config,
        )

    output_path = str(OUTPUTS_DIR / "test_iclora_detailer.mp4")
    encode_video(
        video=video,
        fps=TEST_FPS,
        audio=audio,
        audio_sample_rate=AUDIO_SAMPLE_RATE,
        output_path=output_path,
        video_chunks_number=video_chunks_number,
    )

    elapsed = time.time() - start
    size_mb = Path(output_path).stat().st_size / (1024*1024)
    print(f"SUCCESS: {output_path} ({size_mb:.1f} MB, {elapsed:.1f}s)")
    del pipeline
    cleanup()
    return True


def test_all_camera_loras():
    """Test 6: Quick test of all camera LoRAs with distilled pipeline."""
    print("\n" + "="*70)
    print("TEST 6: All Camera LoRAs (Quick)")
    print("="*70)

    from ltx_core.loader import LTXV_LORA_COMFY_RENAMING_MAP, LoraPathStrengthAndSDOps
    from ltx_core.model.video_vae import TilingConfig, get_video_chunks_number
    from ltx_pipelines.distilled import DistilledPipeline
    from ltx_pipelines.utils.constants import AUDIO_SAMPLE_RATE
    from ltx_pipelines.utils.media_io import encode_video

    camera_loras = {
        "dolly-in": "ltx-2-19b-lora-camera-control-dolly-in.safetensors",
        "dolly-out": "ltx-2-19b-lora-camera-control-dolly-out.safetensors",
        "dolly-left": "ltx-2-19b-lora-camera-control-dolly-left.safetensors",
        "dolly-right": "ltx-2-19b-lora-camera-control-dolly-right.safetensors",
        "jib-up": "ltx-2-19b-lora-camera-control-jib-up.safetensors",
        "jib-down": "ltx-2-19b-lora-camera-control-jib-down.safetensors",
        "static": "ltx-2-19b-lora-camera-control-static.safetensors",
    }

    # Use smaller frames for quick testing
    quick_frames = 25  # 8*3+1
    results = {}

    for name, filename in camera_loras.items():
        cleanup()
        print(f"\n  Testing camera LoRA: {name}...")
        start = time.time()

        try:
            lora_path = str(LORAS_DIR / filename)
            loras = [LoraPathStrengthAndSDOps(lora_path, 1.0, LTXV_LORA_COMFY_RENAMING_MAP)]

            pipeline = DistilledPipeline(
                checkpoint_path=LORA_CHECKPOINT,
                gemma_root=GEMMA_ROOT,
                spatial_upsampler_path=UPSAMPLER,
                loras=loras,
                quantization=get_fp8_native_quant(),
            )

            tiling_config = TilingConfig.default()
            video_chunks_number = get_video_chunks_number(quick_frames, tiling_config)

            with torch.inference_mode():
                video, audio = pipeline(
                    prompt=TEST_PROMPT,
                    seed=TEST_SEED,
                    height=TEST_HEIGHT,
                    width=TEST_WIDTH,
                    num_frames=quick_frames,
                    frame_rate=TEST_FPS,
                    images=[],
                    tiling_config=tiling_config,
                )

            output_path = str(OUTPUTS_DIR / f"test_camera_{name}.mp4")
            encode_video(
                video=video,
                fps=TEST_FPS,
                audio=audio,
                audio_sample_rate=AUDIO_SAMPLE_RATE,
                output_path=output_path,
                video_chunks_number=video_chunks_number,
            )

            elapsed = time.time() - start
            results[name] = f"OK ({elapsed:.0f}s)"
            print(f"  OK: {name} - {elapsed:.0f}s")
            del pipeline

        except Exception as e:
            results[name] = f"FAIL: {e}"
            print(f"  FAIL: {name} - {e}")
            traceback.print_exc()

    cleanup()
    print("\n  Camera LoRA Results:")
    for name, result in results.items():
        print(f"    {name}: {result}")

    return all("OK" in r for r in results.values())


def test_all_ic_loras():
    """Test 7: Quick test of all IC-LoRAs with ICLoraPipeline."""
    print("\n" + "="*70)
    print("TEST 7: All IC-LoRAs (Quick)")
    print("="*70)

    from ltx_core.loader import LTXV_LORA_COMFY_RENAMING_MAP, LoraPathStrengthAndSDOps
    from ltx_core.model.video_vae import TilingConfig, get_video_chunks_number
    from ltx_pipelines.ic_lora import ICLoraPipeline
    from ltx_pipelines.utils.constants import AUDIO_SAMPLE_RATE
    from ltx_pipelines.utils.media_io import encode_video

    ic_loras = {
        "canny": "ltx-2-19b-ic-lora-canny-control.safetensors",
        "depth": "ltx-2-19b-ic-lora-depth-control.safetensors",
        "detailer": "ltx-2-19b-ic-lora-detailer.safetensors",
        "pose": "ltx-2-19b-ic-lora-pose-control.safetensors",
    }

    quick_frames = 25
    results = {}

    # Use a video from previous tests as conditioning
    video_cond_path = str(OUTPUTS_DIR / "test_distilled.mp4")
    video_conditioning = []
    if Path(video_cond_path).exists():
        video_conditioning = [(video_cond_path, 1.0)]

    for name, filename in ic_loras.items():
        cleanup()
        print(f"\n  Testing IC-LoRA: {name}...")
        start = time.time()

        try:
            lora_path = str(LORAS_DIR / filename)
            loras = [LoraPathStrengthAndSDOps(lora_path, 1.0, LTXV_LORA_COMFY_RENAMING_MAP)]

            pipeline = ICLoraPipeline(
                checkpoint_path=LORA_CHECKPOINT,
                spatial_upsampler_path=UPSAMPLER,
                gemma_root=GEMMA_ROOT,
                loras=loras,
                quantization=get_fp8_native_quant(),
            )

            tiling_config = TilingConfig.default()
            video_chunks_number = get_video_chunks_number(quick_frames, tiling_config)

            with torch.inference_mode():
                video, audio = pipeline(
                    prompt=f"A high-quality video processed with {name} control, cinematic look.",
                    seed=TEST_SEED,
                    height=TEST_HEIGHT,
                    width=TEST_WIDTH,
                    num_frames=quick_frames,
                    frame_rate=TEST_FPS,
                    images=[],
                    video_conditioning=video_conditioning,
                    tiling_config=tiling_config,
                )

            output_path = str(OUTPUTS_DIR / f"test_iclora_{name}.mp4")
            encode_video(
                video=video,
                fps=TEST_FPS,
                audio=audio,
                audio_sample_rate=AUDIO_SAMPLE_RATE,
                output_path=output_path,
                video_chunks_number=video_chunks_number,
            )

            elapsed = time.time() - start
            results[name] = f"OK ({elapsed:.0f}s)"
            print(f"  OK: {name} - {elapsed:.0f}s")
            del pipeline

        except Exception as e:
            results[name] = f"FAIL: {e}"
            print(f"  FAIL: {name} - {e}")
            traceback.print_exc()

    cleanup()
    print("\n  IC-LoRA Results:")
    for name, result in results.items():
        print(f"    {name}: {result}")

    return all("OK" in r for r in results.values())


if __name__ == "__main__":
    print("="*70)
    print("LTX-2 Pipeline End-to-End Test Suite")
    print(f"GPU: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'None'}")
    print(f"VRAM: {torch.cuda.get_device_properties(0).total_memory / (1024**3):.1f} GB" if torch.cuda.is_available() else "")
    print("="*70)

    tests = [
        ("Distilled Pipeline", test_distilled_pipeline),
        ("Distilled + Camera LoRA", test_distilled_with_camera_lora),
        ("Two-Stage Pipeline", test_two_stage_pipeline),
        ("Two-Stage + Camera LoRA", test_two_stage_with_camera_lora),
        ("IC-LoRA Pipeline (Detailer)", test_ic_lora_pipeline),
        ("All Camera LoRAs", test_all_camera_loras),
        ("All IC-LoRAs", test_all_ic_loras),
    ]

    results = {}
    for name, test_fn in tests:
        try:
            success = test_fn()
            results[name] = "PASS" if success else "FAIL"
        except torch.cuda.OutOfMemoryError:
            results[name] = "OOM"
            print(f"\n  !!! OUT OF MEMORY in {name} !!!")
            cleanup()
        except Exception as e:
            results[name] = f"ERROR: {e}"
            print(f"\n  !!! ERROR in {name}: {e}")
            traceback.print_exc()
            cleanup()

    print("\n" + "="*70)
    print("FINAL RESULTS")
    print("="*70)
    for name, result in results.items():
        emoji = "✅" if result == "PASS" else "❌"
        print(f"  {emoji} {name}: {result}")

    passed = sum(1 for r in results.values() if r == "PASS")
    total = len(results)
    print(f"\n  {passed}/{total} tests passed")
    print("="*70)
