"""
OCR Engine – Gradio Web App.

Decrypts model ONCE on startup → loads into GPU → deletes temp files.
Model stays in memory for all subsequent requests. No re-decryption needed.
"""
from __future__ import annotations

import atexit
import os
import shutil
import sys
import tempfile
import warnings
import logging

# Suppress library noise
warnings.filterwarnings("ignore")
os.environ["TRANSFORMERS_NO_ADVISORY_WARNINGS"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"
os.environ["TRANSFORMERS_VERBOSITY"] = "error"
logging.disable(logging.WARNING)

import io as _io
_real_stderr = sys.stderr
sys.stderr = _io.StringIO()

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_ENGINE_DIR = os.path.join(SCRIPT_DIR, ".engine")
_ENC_DIR = os.path.join(SCRIPT_DIR, ".engine_enc")
_LICENSE_FILE = os.path.join(SCRIPT_DIR, ".license")

_temp_model_dir: str | None = None


def _cleanup_temp():
    global _temp_model_dir
    if _temp_model_dir and os.path.isdir(_temp_model_dir):
        shutil.rmtree(_temp_model_dir, ignore_errors=True)
        _temp_model_dir = None

atexit.register(_cleanup_temp)


def _read_license() -> str | None:
    if os.path.isfile(_LICENSE_FILE):
        with open(_LICENSE_FILE, "r") as f:
            key = f.read().strip()
        return key if key else None
    return None


def _resolve_engine() -> str:
    global _temp_model_dir
    if os.path.isdir(_ENC_DIR):
        from engine_crypto import verify_license, decrypt_engine
        license_key = _read_license()
        if not license_key:
            sys.stderr = _real_stderr
            raise RuntimeError("License file (.license) not found.")
        if not verify_license(_ENC_DIR, license_key):
            sys.stderr = _real_stderr
            raise RuntimeError("Invalid license key.")
        _temp_model_dir = tempfile.mkdtemp(prefix="ocr_engine_")
        decrypt_engine(_ENC_DIR, _temp_model_dir, license_key)
        return _temp_model_dir
    if os.path.isdir(_ENGINE_DIR):
        return _ENGINE_DIR
    return "PaddlePaddle/PaddleOCR-VL-1.5"


# ── Load model once at startup ──────────────────────────────

print("Loading OCR engine ...", file=_real_stderr, flush=True)

import torch
from PIL import Image
from transformers import AutoProcessor, AutoModelForImageTextToText

engine_path = _resolve_engine()
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

MODEL = AutoModelForImageTextToText.from_pretrained(
    engine_path, torch_dtype=torch.bfloat16, low_cpu_mem_usage=True
).to(DEVICE).eval()
PROCESSOR = AutoProcessor.from_pretrained(engine_path)

# Model is in GPU memory → wipe temp decrypted files
_cleanup_temp()

sys.stderr = _real_stderr
# Re-enable logging so Gradio/uvicorn can show the server URL
logging.disable(logging.NOTSET)
logging.getLogger().setLevel(logging.WARNING)
print(f"OCR engine ready on {DEVICE.upper()}.", flush=True)


# ── Inference function ───────────────────────────────────────

PROMPTS = {
    "OCR (general text)": "OCR:",
    "Table recognition": "Table Recognition:",
    "Formula recognition": "Formula Recognition:",
    "Chart recognition": "Chart Recognition:",
    "Text spotting (localize + read)": "Spotting:",
    "Seal / stamp recognition": "Seal Recognition:",
}


def run_ocr(image: Image.Image | None, task_name: str) -> str:
    """Run OCR on an uploaded image. Called by Gradio."""
    if image is None:
        return "Please upload an image."

    image = image.convert("RGB")
    orig_w, orig_h = image.size

    is_spotting = "spotting" in task_name.lower()
    if is_spotting and orig_w < 1500 and orig_h < 1500:
        try:
            resample = Image.Resampling.LANCZOS
        except AttributeError:
            resample = Image.LANCZOS
        image = image.resize((orig_w * 2, orig_h * 2), resample)

    max_pixels = 2048 * 28 * 28 if is_spotting else 1280 * 28 * 28
    prompt_text = PROMPTS.get(task_name, "OCR:")

    messages = [{"role": "user", "content": [
        {"type": "image", "image": image},
        {"type": "text", "text": prompt_text},
    ]}]

    inputs = PROCESSOR.apply_chat_template(
        messages, add_generation_prompt=True, tokenize=True,
        return_dict=True, return_tensors="pt",
        images_kwargs={"size": {
            "shortest_edge": PROCESSOR.image_processor.min_pixels,
            "longest_edge": max_pixels,
        }},
    ).to(MODEL.device)

    with torch.inference_mode():
        outputs = MODEL.generate(**inputs, max_new_tokens=4096)

    result = PROCESSOR.decode(outputs[0][inputs["input_ids"].shape[-1] : -1])
    return result


# ── Gradio UI ────────────────────────────────────────────────

import gradio as gr

TASK_CHOICES = list(PROMPTS.keys())

with gr.Blocks(
    title="OCR Engine",
    theme=gr.themes.Soft(),
    css="""
        .main-title { text-align: center; margin-bottom: 0.5em; }
        .subtitle   { text-align: center; color: #666; margin-bottom: 1.5em; }
    """,
) as demo:
    gr.Markdown("<h1 class='main-title'>OCR Engine</h1>")
    gr.Markdown("<p class='subtitle'>Upload an image and choose a recognition task.</p>")

    with gr.Row():
        with gr.Column(scale=1):
            img_input = gr.Image(type="pil", label="Upload Image")
            task_dropdown = gr.Dropdown(
                choices=TASK_CHOICES,
                value=TASK_CHOICES[0],
                label="Task",
            )
            run_btn = gr.Button("Run OCR", variant="primary", size="lg")

        with gr.Column(scale=1):
            result_box = gr.Textbox(
                label="Result",
                lines=20,
                interactive=False,
            )

    run_btn.click(fn=run_ocr, inputs=[img_input, task_dropdown], outputs=result_box)
    img_input.upload(fn=run_ocr, inputs=[img_input, task_dropdown], outputs=result_box)

if __name__ == "__main__":
    demo.launch(
        server_name="0.0.0.0",
        server_port=7860,
        inbrowser=True,
        share=False,
    )
