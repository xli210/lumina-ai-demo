# ============================================================
# OCR Engine – Setup, download, and run.
# All technical details go to log only. Console shows clean UI.
# ============================================================

$ErrorActionPreference = "Continue"
$ProjectRoot = $PSScriptRoot
Set-Location $ProjectRoot

# ---- Logging (hidden from user) ----
$LogDir = Join-Path $ProjectRoot ".logs"
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$LogFile = Join-Path $LogDir "setup_$Timestamp.log"
if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
    (Get-Item $LogDir).Attributes = "Hidden"
}

function Log {
    param([string]$Message, [string]$Level = "INFO")
    $Line = "[{0:yyyy-MM-dd HH:mm:ss}] [{1}] {2}" -f (Get-Date), $Level, $Message
    Add-Content -Path $LogFile -Value $Line
}

# ---- Console UI helpers ----
$AppName = "OCR Engine"
$TotalSteps = 7

function Show-Banner {
    Write-Host ""
    Write-Host "  ============================================" -ForegroundColor Cyan
    Write-Host "       $AppName  -  Installer & Runner" -ForegroundColor White
    Write-Host "  ============================================" -ForegroundColor Cyan
    Write-Host ""
}

function Show-Step {
    param([int]$Step, [string]$Label)
    $pct = [math]::Round($Step / $TotalSteps * 100)
    $barLen = 30
    $filled = [math]::Round($barLen * $Step / $TotalSteps)
    $empty = $barLen - $filled
    $bar = ("#" * $filled) + ("-" * $empty)
    Write-Host ""
    Write-Host "  [$bar]  $pct%  ($Step/$TotalSteps)" -ForegroundColor Green
    Write-Host "  $Label" -ForegroundColor White
    Write-Host ""
    Log "STEP $Step/$TotalSteps - $Label"
}

function Show-Done {
    Write-Host ""
    Write-Host "  ============================================" -ForegroundColor Green
    Write-Host "       $AppName  -  Complete!" -ForegroundColor White
    Write-Host "  ============================================" -ForegroundColor Green
    Write-Host ""
}

function Show-Error {
    param([string]$Msg)
    Write-Host ""
    Write-Host "  [ERROR] $Msg" -ForegroundColor Red
    Write-Host "  Check logs for details." -ForegroundColor Yellow
    Write-Host ""
    Log $Msg "ERROR"
}

# ---- Start ----
Show-Banner
Log "========== Setup started =========="
Log "Project root: $ProjectRoot"

# ============================================================
# STEP 1 – Detect hardware
# ============================================================
Show-Step 1 "Detecting hardware ..."

$os = Get-CimInstance Win32_OperatingSystem
$totalRAM = [math]::Round($os.TotalVisibleMemorySize / 1MB, 2)
$freeRAM = [math]::Round($os.FreePhysicalMemory / 1MB, 2)
Log "RAM: Total ${totalRAM} GB, Free ${freeRAM} GB"

$CudaVersion = $null
try {
    $nvidiaOut = & nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader 2>&1 | Out-String
    $nvidiaFull = & nvidia-smi 2>&1 | Out-String
    Log "nvidia-smi:`n$nvidiaFull"
    if ($LASTEXITCODE -eq 0 -and $nvidiaOut) {
        $parts = $nvidiaOut.Trim().Split(",")
        if ($parts.Count -ge 2) { Log "GPU: $($parts[0].Trim()), VRAM: $($parts[1].Trim())" }
        if ($nvidiaFull -match "CUDA Version:\s*(\d+)\.(\d+)") {
            $CudaVersion = "$($Matches[1]).$($Matches[2])"
            Log "CUDA: $CudaVersion"
        }
    }
} catch {
    Log "nvidia-smi unavailable: $_" "WARN"
}

$TorchIndex = "cpu"
if ($CudaVersion) {
    $major = [int]($CudaVersion.Split(".")[0])
    $minor = [int]($CudaVersion.Split(".")[1])
    if ($major -ge 12) {
        if ($minor -ge 6) { $TorchIndex = "cu126" }
        elseif ($minor -ge 4) { $TorchIndex = "cu124" }
        else { $TorchIndex = "cu121" }
    } elseif ($major -eq 11 -and $minor -ge 8) { $TorchIndex = "cu118" }
    Log "Torch index: $TorchIndex"
    Write-Host "    GPU acceleration available." -ForegroundColor Green
} else {
    Log "No CUDA. CPU only."
    Write-Host "    No GPU detected. Will use CPU mode." -ForegroundColor Yellow
}

# ============================================================
# STEP 2 – Prepare environment
# ============================================================
Show-Step 2 "Preparing environment ..."

$VenvPath = Join-Path $ProjectRoot ".venv"
$PythonExe = Join-Path $VenvPath "Scripts\python.exe"
$PipExe = Join-Path $VenvPath "Scripts\pip.exe"

if (-not (Test-Path $PythonExe)) {
    $sysPy = Get-Command python -ErrorAction SilentlyContinue
    if (-not $sysPy) { $sysPy = Get-Command py -ErrorAction SilentlyContinue }
    if (-not $sysPy) {
        Show-Error "Python not found. Please install Python 3.10+ and add to PATH."
        exit 1
    }
    & $sysPy.Source -m venv $VenvPath 2>&1 | ForEach-Object { Log $_ }
    if (-not (Test-Path $PythonExe)) {
        Show-Error "Failed to create environment."
        exit 1
    }
    Log "Venv created."
} else {
    Log "Venv exists."
}
& $PythonExe -m pip install --upgrade pip --quiet 2>&1 | ForEach-Object { Log $_ }

# ============================================================
# STEP 3 – Install core components
# ============================================================
Show-Step 3 "Installing core components (this may take a few minutes) ..."

if ($TorchIndex -eq "cpu") {
    & $PipExe install torch torchvision --quiet 2>&1 | ForEach-Object { Log $_ }
} else {
    $TorchUrl = "https://download.pytorch.org/whl/$TorchIndex"
    & $PipExe install torch torchvision --index-url $TorchUrl --quiet 2>&1 | ForEach-Object { Log $_ }
}
Log "Torch install done."

# ============================================================
# STEP 4 – Install additional components
# ============================================================
Show-Step 4 "Installing additional components ..."

& $PipExe install "transformers>=5.0.0" "Pillow" "huggingface_hub" "accelerate" "cryptography" "gradio" --quiet 2>&1 | ForEach-Object { Log $_ }
Log "Additional packages done."

# ============================================================
# STEP 5 – Download OCR engine data
# ============================================================
$ModelDir = Join-Path $ProjectRoot ".engine"
$EncDir = Join-Path $ProjectRoot ".engine_enc"
$LicenseFile = Join-Path $ProjectRoot ".license"

# Skip download if encrypted engine already exists
$needDownload = (-not (Test-Path (Join-Path $EncDir "v.dat"))) -and (-not (Test-Path (Join-Path $ModelDir "config.json")))

if ($needDownload) {
    Show-Step 5 "Downloading OCR engine data (first time only, ~2 GB) ..."
    $DownloadScript = @"
import os, sys, warnings
warnings.filterwarnings('ignore')
os.environ['HF_HUB_DISABLE_PROGRESS_BARS'] = '0'
from huggingface_hub import snapshot_download
snapshot_download(
    repo_id='PaddlePaddle/PaddleOCR-VL-1.5',
    local_dir=r'$ModelDir',
    local_dir_use_symlinks=False,
)
"@
    $DownloadScript | & $PythonExe 2>&1 | ForEach-Object {
        if ($_ -match '\d+%') {
            Write-Host "`r    $($_)" -NoNewline -ForegroundColor DarkGray
        }
        Log $_
    }
    Write-Host ""
    if (-not (Test-Path (Join-Path $ModelDir "config.json"))) {
        Show-Error "Engine data download may have failed. Please check your network and retry."
        exit 1
    }
    Log "Engine data saved."
} else {
    Show-Step 5 "Engine data present. Skipping download."
    Write-Host "    Already available." -ForegroundColor DarkGray
}

# ============================================================
# STEP 6 – Secure engine data (encrypt & remove plaintext)
# ============================================================
Show-Step 6 "Securing engine data ..."

if (Test-Path (Join-Path $EncDir "v.dat")) {
    Write-Host "    Already secured." -ForegroundColor DarkGray
    Log "Engine already encrypted."
} elseif (Test-Path (Join-Path $ModelDir "config.json")) {
    # Encrypt with auto-generated or existing license key
    $encryptArgs = "--delete-source"
    if (Test-Path $LicenseFile) {
        $existingKey = (Get-Content $LicenseFile -Raw).Trim()
        if ($existingKey) { $encryptArgs = "--key $existingKey --delete-source" }
    }
    $encryptCmd = "& '$PythonExe' '$(Join-Path $ProjectRoot "encrypt_engine.py")' $encryptArgs"
    Invoke-Expression $encryptCmd 2>&1 | ForEach-Object { Log $_ }

    if (Test-Path (Join-Path $EncDir "v.dat")) {
        Write-Host "    Engine data secured." -ForegroundColor Green
        Log "Encryption done. Plaintext removed."
    } else {
        Show-Error "Encryption may have failed."
    }
} else {
    Show-Error "No engine data found to secure."
}

# Verify license file exists
if (-not (Test-Path $LicenseFile)) {
    Show-Error "License file not found. Check logs."
    exit 1
}

# ============================================================
# STEP 7 – Launch OCR Web App
# ============================================================
Show-Step 7 "Launching OCR web app ..."
Write-Host "    The app will open in your browser at http://localhost:7860" -ForegroundColor Cyan
Write-Host "    Press Ctrl+C in this window to stop the server." -ForegroundColor DarkGray
Write-Host ""

Show-Done

# Launch Gradio — this blocks until user stops it
& $PythonExe (Join-Path $ProjectRoot "app.py") 2>&1 | ForEach-Object {
    # Forward server status lines to console, log everything
    if ($_ -match 'Running on|localhost|http://|Loading|ready|ERROR|Error|Traceback') {
        Write-Host "    $_" -ForegroundColor White
    }
    Log $_
}
$appExit = if ($LASTEXITCODE -ne $null) { $LASTEXITCODE } else { 0 }
Log "========== App stopped (exit $appExit) =========="
exit $appExit
